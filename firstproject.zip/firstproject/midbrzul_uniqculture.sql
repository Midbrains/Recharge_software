-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2021 at 08:19 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `midbrzul_uniqculture`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_bank`
--

CREATE TABLE `add_bank` (
  `id` int(50) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(20) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `holder_name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_bank`
--

INSERT INTO `add_bank` (`id`, `bank_name`, `account_number`, `ifsc_code`, `branch_name`, `holder_name`) VALUES
(4, 'SBI', '455545595655', 'SBI0343434', 'Pune', 'Jhn');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Chintan Admin', 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `amount_api`
--

CREATE TABLE `amount_api` (
  `id` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `api_name` varchar(80) NOT NULL,
  `operator_name` varchar(80) NOT NULL,
  `amount` varchar(80) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `amount_api`
--

INSERT INTO `amount_api` (`id`, `add_date`, `api_name`, `operator_name`, `amount`, `status`) VALUES
(5, '2021-03-17', 'Pay1express', 'AIRTEL', '15', 'Active'),
(6, '2021-03-31', 'Ambika', 'JIO', '15', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `api_setting`
--

CREATE TABLE `api_setting` (
  `api_id` int(11) NOT NULL,
  `api_name` varchar(500) NOT NULL,
  `username` text NOT NULL,
  `password` varchar(100) NOT NULL DEFAULT '1' COMMENT '1- show, 0 - not',
  `json_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `api_setting`
--

INSERT INTO `api_setting` (`api_id`, `api_name`, `username`, `password`, `json_data`) VALUES
(7, 'mrobotics', 'Dattakrupa2019@gmail.com', '123', '{\"api_name\":\"mrobotics\",\"username\":\"Dattakrupa2019@gmail.com\",\"password\":\"pass@123\"}'),
(8, 'Ambika', 'Chintan Admin', '1234', '{\"api_name\":\"ambika\",\"username\":\"Chintan Admin\",\"password\":\"123\"}'),
(9, 'Pay1express', 'Chintan Admin', '123', '{\"api_name\":\"api.pay1express\",\"username\":\"Chintan Admin\",\"password\":\"123\"}');

-- --------------------------------------------------------

--
-- Table structure for table `balance_trans`
--

CREATE TABLE `balance_trans` (
  `id` int(100) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `branch_name` text NOT NULL,
  `account_holder` varchar(10) NOT NULL,
  `ifsc_code` varchar(11) NOT NULL,
  `cash_diposit` varchar(25) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `company_toll_free`
--

CREATE TABLE `company_toll_free` (
  `id` int(11) NOT NULL,
  `company_operator_name` varchar(25) NOT NULL,
  `company_operator_number` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_toll_free`
--

INSERT INTO `company_toll_free` (`id`, `company_operator_name`, `company_operator_number`) VALUES
(2, 'IDEA', '1800458555');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `id` int(50) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `username` varchar(25) NOT NULL,
  `complain` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`id`, `user_id`, `username`, `complain`, `status`) VALUES
(2, '', 'makha', 'Hello there', 'Send'),
(5, '18', 'Demo', 'Need A api', 'Send');

-- --------------------------------------------------------

--
-- Table structure for table `costomer`
--

CREATE TABLE `costomer` (
  `id` int(25) NOT NULL,
  `costomer_name` varchar(50) NOT NULL,
  `costomer_number` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `costomer`
--

INSERT INTO `costomer` (`id`, `costomer_name`, `costomer_number`) VALUES
(2, 'rohit', '7344875774');

-- --------------------------------------------------------

--
-- Table structure for table `ladger`
--

CREATE TABLE `ladger` (
  `id` int(100) NOT NULL,
  `user_id` varchar(25) NOT NULL,
  `transaction_id` varchar(35) NOT NULL,
  `datetime` text NOT NULL,
  `description` text NOT NULL,
  `debit` varchar(30) NOT NULL,
  `credit` varchar(30) NOT NULL,
  `current_bal` varchar(30) NOT NULL,
  `remark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ladger`
--

INSERT INTO `ladger` (`id`, `user_id`, `transaction_id`, `datetime`, `description`, `debit`, `credit`, `current_bal`, `remark`) VALUES
(1, '19', 'TR1100549', '2021-05-31 14:05:49', 'Paid for JIO  account no 8299545869 amount 10', '10', '00', '', 'Ok'),
(2, '19', 'TR1100514', '2021-05-31 14:05:14', 'Paid for JIO  account no 8299545869 amount 10', '10', '00', '', 'Ok'),
(3, '19', 'TR1100558', '2021-05-31 14:05:58', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '', 'Ok'),
(4, '19', 'TR1100520', '2021-05-31 14:05:20', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '', 'Ok'),
(5, '19', 'TR1100530', '2021-05-31 14:05:30', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '', 'Ok'),
(6, '19', 'TR1100535', '2021-05-31 14:05:35', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '', 'Ok'),
(7, '19', 'TR1100504', '2021-05-31 14:05:04', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '', 'Ok'),
(8, '19', '', '', '', '11', '00', '150', 'Ok'),
(9, '19', 'TR1100510', '2021-05-31 14:05:10', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '9', 'Ok'),
(10, '19', '', '', '', '11', '00', '50', 'Ok'),
(11, '19', 'TR1100518', '2021-05-31 14:05:18', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '39', 'Ok'),
(12, '19', 'TR1100542', '2021-05-31 14:05:42', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '28', 'Ok'),
(13, '19', '', '', '', '11', '00', '17', 'Ok'),
(14, '19', 'TR1090656', '2021-06-01 13:06:56', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '50', 'Ok'),
(15, '19', 'TR1090610', '2021-06-01 13:06:10', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '39', 'Ok'),
(16, '19', 'TR1090644', '2021-06-01 13:06:44', 'Paid for JIO account no 8299545869 amount ', '', '00', '28', 'Ok'),
(17, '19', 'TR1090657', '210601090657', 'Paid for  account no 82995458698299545869 amount 10', '10', '00', '18', 'Ok'),
(18, '19', 'TR1100640', '210601100640', 'Paid for JIO account no 8299545869 amount 7', '7', '00', '8', 'Ok'),
(19, '19', 'TR1100604', '2021-06-01 13:06:04', 'Paid for  account no 8299545869 amount 11', '11', '00', '50', 'Ok'),
(20, '19', 'TR1100655', '2021-06-01 13:06:55', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '39', 'Ok'),
(21, '19', 'TR1100643', '2021-06-01 13:06:43', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '28', 'Ok'),
(22, '19', 'TR1100616', '2021-06-01 13:06:16', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '17', 'Ok'),
(23, '19', 'TR1100630', '2021-06-01 14:06:30', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '150', 'Ok'),
(24, '19', 'TR2080649', '2021-06-02 12:06:49', 'Paid for JIO  account no 8299545869 amount 15', '15', '00', '124', 'Ok'),
(25, '19', 'TR2120644', '2021-06-02 16:06:44', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '113', 'Ok'),
(26, '19', 'TR2120654', '2021-06-02 16:06:54', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '102', 'Ok'),
(27, '19', 'TR2120618', '2021-06-02 16:06:18', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '91', 'Ok'),
(28, '19', 'TR2120624', '2021-06-02 16:06:24', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '80', 'Ok'),
(29, '19', 'TR3070615', '2021-06-03 11:06:15', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '69', 'Ok'),
(30, '19', 'TR5120646', '2021-06-05 16:06:46', 'Paid for JIO  account no 8299545869 amount 11', '11', '00', '58', 'Ok');

-- --------------------------------------------------------

--
-- Table structure for table `operator`
--

CREATE TABLE `operator` (
  `id` int(11) NOT NULL,
  `operator_name` varchar(500) NOT NULL,
  `api_name` varchar(15) NOT NULL,
  `api_commision` int(50) NOT NULL,
  `sd_commision` int(11) NOT NULL,
  `md_commision` int(11) NOT NULL,
  `dis_commision` int(15) NOT NULL,
  `rt_commision` int(11) NOT NULL,
  `commision_type` varchar(20) NOT NULL,
  `operator_code` varchar(20) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `amount_not_allowed` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `operator`
--

INSERT INTO `operator` (`id`, `operator_name`, `api_name`, `api_commision`, `sd_commision`, `md_commision`, `dis_commision`, `rt_commision`, `commision_type`, `operator_code`, `service_name`, `amount_not_allowed`, `status`) VALUES
(2, 'BSNL', 'Ambika', 12, 0, 0, 0, 0, '0', 'BS', 'POST-PAID', '55', 'Cancel'),
(3, 'IDEA', 'Ambika', 0, 10, 0, 0, 0, '0', 'ID', 'PRE-PAID', '25', 'Down'),
(4, 'AIRTEL', 'Ambika', 0, 0, 11, 0, 0, '0', 'AT', 'POST-PAID', '52', 'Down'),
(5, 'VODAFONE', 'Ambika', 0, 0, 0, 0, 0, 'Flat Commision', 'VF', 'POST-PAID', '50', 'Down'),
(6, 'JIO ', 'Ambika', 0, 0, 0, 0, 0, 'Flat Commision', 'JP', 'PRE-PAID', '49', 'Active'),
(7, 'Airtel', 'Pay1express', 0, 0, 0, 0, 0, '', 'AR', 'POST-PAID', '', 'Cancel'),
(8, 'BSNL', 'Pay1express', 0, 0, 0, 0, 0, '', 'BS', 'POST-PAID', '', 'Down'),
(9, 'IDEA', 'Pay1express', 0, 0, 0, 0, 0, '', 'ID', 'POST-PAID', '', 'Down'),
(10, 'Jio ', 'Pay1express', 0, 0, 0, 0, 0, '', 'RJ', 'DATA-CARD', '', 'Down'),
(11, 'AIRCEL', 'Pay1express', 0, 0, 0, 0, 0, '', 'AI', 'POST-PAID', '', 'Down'),
(12, 'Vodafone ', 'Mrobotics', 0, 0, 0, 0, 0, '', '1', 'POST-PAID', '', 'Down'),
(13, 'Airtel', 'Mrobotics', 0, 0, 0, 0, 0, '', '2', 'PRE-PAID', '', 'Down'),
(14, 'Idea', 'Mrobotics', 0, 0, 0, 0, 0, '', '3', 'PRE-PAID', '', 'Down'),
(15, 'BSNL', 'Mrobotics', 0, 0, 0, 0, 0, '', '4', 'PRE-PAID', '', 'Down'),
(16, 'JIO', 'Mrobotics', 0, 0, 0, 0, 0, '', '5', 'PRE-PAID', '', 'Cancel');

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateway`
--

CREATE TABLE `payment_gateway` (
  `id` int(11) NOT NULL,
  `payment_charge` varchar(50) NOT NULL,
  `charge_type` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_gateway`
--

INSERT INTO `payment_gateway` (`id`, `payment_charge`, `charge_type`, `payment_status`) VALUES
(1, '150', 'Rupees', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `quantity` double NOT NULL,
  `image` text NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1- enable, 0 - disable',
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recharge`
--

CREATE TABLE `recharge` (
  `id` int(100) NOT NULL,
  `order_id` text NOT NULL,
  `user_id` text NOT NULL,
  `user_role` text NOT NULL,
  `api_name` text NOT NULL,
  `trans_id` text NOT NULL,
  `operator_id` text NOT NULL,
  `service` text NOT NULL,
  `website_order` text NOT NULL,
  `error_code` text NOT NULL,
  `myapibalance` text NOT NULL,
  `closing` varchar(20) NOT NULL,
  `myapiprofit` text NOT NULL,
  `operator` text NOT NULL,
  `mobile_no` text NOT NULL,
  `commision` int(25) NOT NULL,
  `date` datetime NOT NULL,
  `updated_at` text NOT NULL,
  `created_at` text NOT NULL,
  `response` text NOT NULL,
  `api_response` text NOT NULL,
  `mode` varchar(15) NOT NULL,
  `total_hits` text NOT NULL,
  `success_hits` text NOT NULL,
  `success_amount` text NOT NULL,
  `failed_amount` text NOT NULL,
  `failed_hits` text NOT NULL,
  `success_status` text NOT NULL,
  `failed_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recharge`
--

INSERT INTO `recharge` (`id`, `order_id`, `user_id`, `user_role`, `api_name`, `trans_id`, `operator_id`, `service`, `website_order`, `error_code`, `myapibalance`, `closing`, `myapiprofit`, `operator`, `mobile_no`, `commision`, `date`, `updated_at`, `created_at`, `response`, `api_response`, `mode`, `total_hits`, `success_hits`, `success_amount`, `failed_amount`, `failed_hits`, `success_status`, `failed_status`) VALUES
(179, '1', '19', 'distributor', 'Mrobotics', 'TR1090657', '\r\n\r\nBR00067N9NRY', '10', '', '', '4316.01', '', '', '', '82995458698299545869', 0, '2021-06-01 09:06:57', '2021-06-01T07:59:58.649Z', '2021-06-01T07:59:48.321Z210601090657', 'Success|2|||066201668914021100001|066201668914021504542|066201668914021900001||066201668914021100000', '', '', '1', '1', '10', '', '', 'Success', ''),
(180, '1', '19', 'distributor', 'Mrobotics', 'TR1100640', '\r\n\r\nBR00067NB2TL', '7', '', '', '4316.01', '', '', 'JIO', '8299545869', 0, '2021-06-01 10:06:40', '2021-06-01T08:08:39.957Z', '2021-06-01T08:08:36.719Z210601100640', 'No Plans Found with this Amount', '', '', '1', '', '', '7', '1', '', 'Failed'),
(185, '1', '19', 'distributor', 'Ambika', 'TR1100630', '\r\nBR00067NF3DY\r\n', '11', '', '', '38.42', '', '', 'JIO ', '8299545869', 0, '2021-06-01 14:06:30', '2021-06-01 02:06:30pm', '2021-06-01 14:06:30', '', '', '', '1', '1', '11', '', '', 'Success', ''),
(186, '1', '19', 'distributor', 'Ambika', 'TR2120624', '\r\n \r\n', '11', '', '', '0', '80', '', 'JIO ', '8299545869', 0, '2021-06-02 16:06:24', '2021-06-02 04:21:24pm', '2021-06-02 16:06:24', 'Invalid IP Address!47.15.109.174', '', 'Web', '1', '', '', '11', '1', '', 'Failed'),
(187, '1', '19', 'distributor', 'Ambika', 'TR3070615', '\r\n \r\n', '11', '', '', '0', '69', '', 'JIO ', '8299545869', 0, '2021-06-03 11:06:15', '2021-06-03 11:21:15am', '2021-06-03 11:06:15', 'Invalid IP Address!47.8.56.77', '{\"ACCOUNT\":\"8299545869\",\"AMOUNT\":11.0,\"RPID\":\" \",\"AGENTID\":\"3307897395\",\"OPID\":\" \",\"STATUS\":\"FAILED\",\"MSG\":\"Invalid IP Address!47.8.56.77\",\"BAL\":0.0}', 'Web', '1', '', '', '11', '1', '', 'Failed'),
(188, '1', '19', 'distributor', 'Ambika', 'TR5120646', '\r\n \r\n', '11', '', '', '0', '58', '', 'JIO ', '8299545869', 0, '2021-06-05 16:06:46', '2021-06-05 04:23:46pm', '2021-06-05 16:06:46', 'Invalid IP Address!47.9.189.157', '{\"ACCOUNT\":\"8299545869\",\"AMOUNT\":11.0,\"RPID\":\" \",\"AGENTID\":\"2179209548\",\"OPID\":\" \",\"STATUS\":\"FAILED\",\"MSG\":\"Invalid IP Address!47.9.189.157\",\"BAL\":0.0}', 'Web', '1', '', '', '11', '1', '', 'Failed');

-- --------------------------------------------------------

--
-- Table structure for table `recharge_api`
--

CREATE TABLE `recharge_api` (
  `id` int(100) NOT NULL,
  `user_id` varchar(25) NOT NULL,
  `transfer_role` varchar(20) NOT NULL,
  `api_name` varchar(100) NOT NULL,
  `operator_code` varchar(20) NOT NULL,
  `package_name` varchar(25) NOT NULL,
  `api_url` text NOT NULL,
  `status` text NOT NULL,
  `response_log` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recharge_api`
--

INSERT INTO `recharge_api` (`id`, `user_id`, `transfer_role`, `api_name`, `operator_code`, `package_name`, `api_url`, `status`, `response_log`) VALUES
(4, '1', 'Admin', 'Pay1express', 'RJ', 'demo package', 'https://api.pay1express.com/POEAPI/RechargeAPI.aspx?MobileNo=9595847575&APIKey=72JOc1wa85mpcpUJqRjVeMoMRikMwgyaC3D&REQTYPE=RECH&REFNO=4542&SERCODE=ID&CUSTNO=56455&REFMOBILENO=8299545869&AMT=11&STV=0&RESPTYPE=JSON', 'Deactive', 'Non-Response'),
(5, '1', 'Admin', 'Ambika', 'JP', 'demo package Name', 'https://ambikaecom.net/API/TransactionAPI?UserID=10431&Token=fef118a2f5758de1130282fde17365b1&SPKey=$operator&Account=$mobile&Amount=$amount&APIRequestID=$uniqueorderid&OutletID=Janheet%20Recharge%20Solution&format=1', 'Active', 'Response'),
(6, '1', 'Admin', 'Mrobotics', '5', 'Demo', 'https://mrobotics.in/api/recharge_get?api_token=589be6bc-3aa1-4f0a-bb9c-2fcb6b51991d&mobile_no=$mobile&amount=$amount&company_id=5&OpCode=5&order_id=$uniqueorderid&is_stv=true', 'Deactive', 'Response');

-- --------------------------------------------------------

--
-- Table structure for table `recharge_package`
--

CREATE TABLE `recharge_package` (
  `package_id` int(11) NOT NULL,
  `package_name` varchar(500) NOT NULL,
  `package_description` varchar(50) NOT NULL,
  `package_amount` varchar(10) NOT NULL,
  `package_commision_type` text NOT NULL,
  `package_status` varchar(10) NOT NULL,
  `response_log` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recharge_package`
--

INSERT INTO `recharge_package` (`package_id`, `package_name`, `package_description`, `package_amount`, `package_commision_type`, `package_status`, `response_log`) VALUES
(1, 'demo package', 'Demo Package', '30', 'Flat Commision', 'Active', 'Response'),
(2, 'Demo', 'Demo', '20', 'commision', 'Deactive', 'Response'),
(3, 'demo package Name', 'Demo Package', '300', 'operator wise Commision', 'Deactive', 'Non-Response');

-- --------------------------------------------------------

--
-- Table structure for table `recharge_service`
--

CREATE TABLE `recharge_service` (
  `recharge_id` int(11) NOT NULL,
  `recharge_service` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recharge_service`
--

INSERT INTO `recharge_service` (`recharge_id`, `recharge_service`) VALUES
(3, 'GAS'),
(4, 'DTH'),
(5, 'WATER'),
(6, 'PRE-PAID'),
(7, 'POST-PAID'),
(8, 'DATA-CARD'),
(9, 'LAND LINE'),
(10, 'MONEY TRANSFER'),
(11, 'ELECTRICITY');

-- --------------------------------------------------------

--
-- Table structure for table `rech_member_reg`
--

CREATE TABLE `rech_member_reg` (
  `id` int(90) NOT NULL,
  `service_type` varchar(50) NOT NULL COMMENT 'service_type',
  `name` varchar(50) NOT NULL COMMENT 'name',
  `username` varchar(50) NOT NULL COMMENT 'username',
  `mobile_no` varchar(12) NOT NULL COMMENT 'mobile_no',
  `parent_user` varchar(30) NOT NULL COMMENT 'parent_user',
  `commision_type` varchar(25) NOT NULL COMMENT 'commision_type',
  `commision_package` varchar(30) NOT NULL COMMENT 'commision_package',
  `email` text NOT NULL COMMENT 'enter_email',
  `company_name` varchar(100) NOT NULL COMMENT 'company_name',
  `pin` int(10) NOT NULL COMMENT 'pin',
  `aadhar_pan_no` varchar(12) NOT NULL COMMENT 'aadhar_pan_no',
  `aadhar_pan_img` text NOT NULL COMMENT 'aadhar_pan_img',
  `member_id` varchar(16) NOT NULL COMMENT 'memeber_id',
  `balance` varchar(15) NOT NULL,
  `balance_limit` int(15) NOT NULL,
  `recharge_limit` int(15) NOT NULL,
  `reg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rech_member_reg`
--

INSERT INTO `rech_member_reg` (`id`, `service_type`, `name`, `username`, `mobile_no`, `parent_user`, `commision_type`, `commision_package`, `email`, `company_name`, `pin`, `aadhar_pan_no`, `aadhar_pan_img`, `member_id`, `balance`, `balance_limit`, `recharge_limit`, `reg_date`) VALUES
(10, 'super distributor', 'demo demo', 'Asish', '7348487570', 'trtr', 'Flat_commission', '34', 'demo@gmail.com', 'recharge', 221454, '4542354235', 'WhatsApp Image 2021-03-31 at 11.42.49 AM.jpeg', '148299', '', 50, 100, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `request_balance`
--

CREATE TABLE `request_balance` (
  `id` int(100) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `bank_name` varchar(250) NOT NULL,
  `deposit_account` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `payment_mode` varchar(50) NOT NULL,
  `transaction_id` varchar(30) NOT NULL,
  `req_amount` varchar(25) NOT NULL,
  `req_date` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_balance`
--

INSERT INTO `request_balance` (`id`, `user_id`, `user_name`, `user_type`, `bank_name`, `deposit_account`, `phone`, `payment_mode`, `transaction_id`, `req_amount`, `req_date`, `status`) VALUES
(25, '12', 'Kishor0594', 'retailer', 'SBI', '554568544588', '8299545869', 'neft', 'ds545454', '150', '2021-05-18', 'Approved'),
(26, '19', 'demo', 'distributor', 'SBI', '545855545855', '8299545869', 'tpt', 'Tr54545454', '58', '2021-05-22', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `stop_operator`
--

CREATE TABLE `stop_operator` (
  `id` int(50) NOT NULL,
  `member_name` varchar(200) NOT NULL,
  `operator_name` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stop_operator`
--

INSERT INTO `stop_operator` (`id`, `member_name`, `operator_name`, `status`) VALUES
(16, 'makha', 'AT', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` text NOT NULL,
  `user_type` enum('user_api','retailer','distributor','super','master') DEFAULT NULL,
  `mobile` varchar(15) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_by` varchar(15) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(10) NOT NULL COMMENT '1- actieve, 0- deactiv, 2- deleted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_id`, `username`, `email`, `user_type`, `mobile`, `reg_date`, `reg_by`, `password`, `status`) VALUES
(10, '', 'Demo', 'Demo@gmail.com', 'master', '8299545869', '2021-01-30', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(12, '', 'Kishor0594', 'Kishor0594@gmail.com', 'retailer', '2147483647', '2021-02-24', 'Web', 'f91e15dbec69fc40f81f0876e7009648', 'Active'),
(19, '18', 'demo', 'demo@gmail.com', 'distributor', '8299545869', '2021-05-19', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(20, '10', 'hello', 'hello@gmail.com', 'super', '8299545866', '2021-05-19', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(21, '20', 'Rohit', 'rohit@gmail.com', 'distributor', '8299545869', '2021-05-19', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(22, '20', 'Niraj', 'niraj@gmail.com', 'distributor', '7348485757', '2021-05-19', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(23, '20', 'balu', 'balu@gmail.com', 'retailer', '7348487577', '2021-05-19', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(24, '', 'hhello', 'demo@gmail.com', 'master', '7348487570', '2021-05-20', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active'),
(25, '19', 'helllo', 'helllo@gmail.com', 'retailer', '8299545869', '2021-05-21', 'Web', 'dc06698f0e2e75751545455899adccc3', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `white_label`
--

CREATE TABLE `white_label` (
  `white_id` int(10) NOT NULL,
  `from1` varchar(100) NOT NULL,
  `to1` varchar(100) NOT NULL,
  `provide1` varchar(100) NOT NULL,
  `from2` varchar(100) NOT NULL,
  `to2` varchar(100) NOT NULL,
  `provide2` varchar(100) NOT NULL,
  `from3` varchar(100) NOT NULL,
  `to3` varchar(100) NOT NULL,
  `provide3` varchar(100) NOT NULL,
  `from4` varchar(100) NOT NULL,
  `to4` varchar(100) NOT NULL,
  `provide4` varchar(100) NOT NULL,
  `from5` varchar(100) NOT NULL,
  `to5` varchar(100) NOT NULL,
  `provide5` varchar(100) NOT NULL,
  `from6` varchar(100) NOT NULL,
  `to6` varchar(100) NOT NULL,
  `provide6` varchar(100) NOT NULL,
  `commision_role` varchar(50) NOT NULL,
  `update_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `white_label`
--

INSERT INTO `white_label` (`white_id`, `from1`, `to1`, `provide1`, `from2`, `to2`, `provide2`, `from3`, `to3`, `provide3`, `from4`, `to4`, `provide4`, `from5`, `to5`, `provide5`, `from6`, `to6`, `provide6`, `commision_role`, `update_date`) VALUES
(5, '1000', '10', '10', '10', '10', '10', '10', '10', '10', '1', '10', '10', '10', '10', '10', '10', '10', '10', 'White Label', '0000-00-00'),
(6, '12', '10', '10', '10', '10', '10', '10', '10', '10', '1', '10', '45', '10', '10', ' 10', '10', '10', '10', 'Master Dealer', '0000-00-00'),
(7, '1000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Distributor', '0000-00-00'),
(8, '12', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Retailer', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_bank`
--
ALTER TABLE `add_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `amount_api`
--
ALTER TABLE `amount_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_setting`
--
ALTER TABLE `api_setting`
  ADD PRIMARY KEY (`api_id`);

--
-- Indexes for table `balance_trans`
--
ALTER TABLE `balance_trans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_toll_free`
--
ALTER TABLE `company_toll_free`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costomer`
--
ALTER TABLE `costomer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ladger`
--
ALTER TABLE `ladger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `operator`
--
ALTER TABLE `operator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateway`
--
ALTER TABLE `payment_gateway`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `recharge`
--
ALTER TABLE `recharge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recharge_api`
--
ALTER TABLE `recharge_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recharge_package`
--
ALTER TABLE `recharge_package`
  ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `recharge_service`
--
ALTER TABLE `recharge_service`
  ADD PRIMARY KEY (`recharge_id`);

--
-- Indexes for table `rech_member_reg`
--
ALTER TABLE `rech_member_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request_balance`
--
ALTER TABLE `request_balance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stop_operator`
--
ALTER TABLE `stop_operator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `white_label`
--
ALTER TABLE `white_label`
  ADD PRIMARY KEY (`white_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_bank`
--
ALTER TABLE `add_bank`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `amount_api`
--
ALTER TABLE `amount_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `api_setting`
--
ALTER TABLE `api_setting`
  MODIFY `api_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `balance_trans`
--
ALTER TABLE `balance_trans`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_toll_free`
--
ALTER TABLE `company_toll_free`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `costomer`
--
ALTER TABLE `costomer`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ladger`
--
ALTER TABLE `ladger`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `operator`
--
ALTER TABLE `operator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `payment_gateway`
--
ALTER TABLE `payment_gateway`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recharge`
--
ALTER TABLE `recharge`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT for table `recharge_api`
--
ALTER TABLE `recharge_api`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `recharge_package`
--
ALTER TABLE `recharge_package`
  MODIFY `package_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `recharge_service`
--
ALTER TABLE `recharge_service`
  MODIFY `recharge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `rech_member_reg`
--
ALTER TABLE `rech_member_reg`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `request_balance`
--
ALTER TABLE `request_balance`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `stop_operator`
--
ALTER TABLE `stop_operator`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `white_label`
--
ALTER TABLE `white_label`
  MODIFY `white_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
