<?php 
session_destroy();
session_unset();
redirect('logout');
?>