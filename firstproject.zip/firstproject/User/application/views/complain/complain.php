    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Amount Api</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
    <div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Amount API</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/complain_enquiry/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Complain</label>
  
    <select name="user_name" id="" class="form-control">
      <option value="">Select User</option>
      <option value="Admin">Admin</option>
       <?php
         foreach($user as $row)
         {  
        ?>
        <option value="<?=$row->username?>"><?=$row->username ." (". $row->user_type.")"?></option>
        <?php } ?>
    </select>
    </div> 
    
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Complains: </label>
         <textarea name="complain" class="form-control" type="text" required placeholder="Complains.."></textarea>
   
   
    </div> 
    </div>                                                   
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i></button>
    <button class="btn btn-primary" type="submit" name="add_complain"><i class="fa fa-check"></i></button>
    </div>
    </form>
    </div>
    </div>
    </div>        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">
    <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Add</a>
    </div>  
    </div>      
    <div class="card-body">

    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>To Complain</th>
    <th>Complains</th>                               
    <th>Status</th>                               
    <th>Action</th>                               
  
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($comp){
    $i = 1;
    foreach($comp as $row){
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?= $row->username?>  </td>                          
    <td><?= $row->complain ?></td> 
    <td><span style="color:white;" class="bg-success p-2"><?= $row->status ?></span></td> 
    <td>
       <a data-toggle="modal" data-target="#status_<?= $row->id?>"> <i class="fa fa-trash btn tooltips " style="background-color:#E66B6B;color:white"></i></a>
          <div class="modal fade" id="status_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are you sure to Delete?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/delete_complain/').$row->id;?>" enctype="multipart/form-data" method="post">


    <input name="delete" class="form-control" type="hidden" value="<?=$row->id; ?>" require>


    <div class="modal-footer">

    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-secondary" type="submit" name="active">Ok</button>
    </div>
    </form>
    </div>
    </div>
    </td>
    </tr>
    <?php
    }
    }
    ?> 
    </tbody>
    </table>
        
    </div>

    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>