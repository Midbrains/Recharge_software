<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Balance Request</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>   
        <?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 
    </div>
    </div>
    </div>
    </div>   

      
        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">
<!--    <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Add</a>-->
    </div>  
    </div>      
    <div class="card-body">
     <div class="modal-content">
                                            
 <form class="form-horizontal auth-form" method="post" action="#" >
 
<div class="form-group">

</div>
<table>
<tr>
<td>
<div class="form-group col-md-12" style="float:left">
<input  name="mobile_no" type="text" class="form-control" maxlength="10" minlength="10"  placeholder="Mobile Number" id="exampleInputEmail1" autocomplete="off" required>

</div>
    </td>
    <td>
 <div class="form-group col-md-6" style="float:left">
            <a  class="btn btn-primary" style="color:white" id="search">Search</a>  
 </div>
    </td>
    </tr>

         </table>
</form>
    </div>
<script>
$(document).ready(function(){
    $('#search').on('click',function(){
       
        var mobile = $('#exampleInputEmail1').val();
     
        if(mobile == 0)
            {
                 $('#record').show();
            }else{
                 $('#transfer').modal('show');
                $('#phone_no').val(mobile);
               
            }
    });
});
   
        </script>
        <h4 id="record" style="display:none;color:red">Record Not found!</h4>
        
        
          <div class="modal fade" id="transfer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel"> Request balance</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/request_balance/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Bank Name:</label>
    <select name="bank_name" class="form-control" type="text" required id="country">
    <option value="">Select Bank Name </option>
    <?php
        foreach($bank as $row)
        {

        ?>
    <option value="<?php echo ucwords($row->bank_name) ?>">
      <?=ucwords($row->bank_name) ?></option>
    <?php } ?>

        </select>
    </div>
    <div class="form-group" id="state">
    </div>
<div class="form-group">
<input  name="account_no" type="text" class="form-control"  maxlength="20" minlength="10"  placeholder="Account" id=""  autocomplete="off" required value="">

</div>
<div class="form-group">
<input  name="mobile_no" type="text" class="form-control"  maxlength="10" minlength="10"  placeholder="Mobile Number" id="phone_no"  autocomplete="off" required value="">

</div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Payment Mode</label>
    <select name="pay_mode" class="form-control" required onchange="payment_mode()" id="pay_mode">
    <option value="">:: Payment Mode ::</option>
       <option value="neft">NEFT</option>
       <option value="rtgs">RTGS</option>
       <option value="tpt">Third Party Transfer</option>
       <option value="cheque">Cheque</option>
       <option value="imps">IMPS</option><option value="exchange">EC-Exchange</option>
       <option value="cash-deposit">Cash Deposit</option>
       <option value="GCC">GCC (Green Channel Card)</option>
        </select>

    </div>
    <div class="form-group " style="display:none" id="transaction">
    <label for="validationCustom01" class="mb-1">Transaction Id</label>
    <input name="trans_id" class="form-control" type="text" value="" >

    </div>

     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Requested Amount</label>
    <input name="req_amount" class="form-control" type="text" value="" required>

    </div> 
     <div class="form-group">
  <?php 
         foreach($user as $row)
         ?>
    <input name="user_type" class="form-control" type="hidden" value="<?php echo $row->user_type ?>" required>

    </div>
      <div class="form-group">
  <?php 
         foreach($user as $row)
         ?>
    <input name="username" class="form-control" type="hidden" value="<?php echo $row->username ?>" required>

    </div>


    </div>
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="payment_req">Add</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>
        
        <script>
        function payment_mode()
        {
           pay_mode = document.getElementById('pay_mode').value;
           if(pay_mode == "neft") {document.getElementById('transaction').style.display = "block";
            document.getElementById('account_holder').style.display = "block";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "none";
        }
            if(pay_mode == "rtgs") {document.getElementById('transaction').style.display = "block";
            document.getElementById('account_holder').style.display = "block";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "none";
        }

            if(pay_mode == "tpt") {document.getElementById('transaction').style.display = "block";
            document.getElementById('account_holder').style.display = "block";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "none";
        }
            if(pay_mode == "cheque") {document.getElementById('transaction').style.display = "block";
            document.getElementById('account_holder').style.display = "block";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "block";
            document.getElementById('card').style.display = "none";
        }

            if(pay_mode == "imps") {
                document.getElementById('transaction').style.display = "block";
            document.getElementById('account_holder').style.display = "block";
            document.getElementById('mobile').style.display = "block";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "none";
        }
            if(pay_mode == "exchange") {
                document.getElementById('transaction').style.display = "none";
            document.getElementById('account_holder').style.display = "none";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "none";
        }
            if(pay_mode == "cash-deposit") {
                document.getElementById('transaction').style.display = "none";
            document.getElementById('account_holder').style.display = "none";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "none";
        }
            if(pay_mode == "GCC") {
                document.getElementById('transaction').style.display = "block";
            document.getElementById('account_holder').style.display = "block";
            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
            document.getElementById('card').style.display = "block";
        }
        }
        </script>
        
<!--
    <div class="modal fade" id="transfer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Balance Request</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
 <form class="form-horizontal auth-form" method="post" action="<?= base_url('user_api/recharge');?>" onSubmit = "return checkPassword(this)">
 
<div class="form-group">
<input  name="name" type="text" class="form-control"   placeholder="Name" id="name"  autocomplete="off" required value="">
</div>
<div class="form-group">
<input  name="mobile_no" type="text" class="form-control"  maxlength="10" minlength="10"  placeholder="Mobile Number" id="phone_no"  autocomplete="off" required value="">

</div>
<div class="form-group">
<input  name="pin_code" type="text" class="form-control" placeholder="Pin Code" id="exampleInputpassword" value="" required>

</div> 

    <div class="form-group">
<input  name="amount" type="text" class="form-control" placeholder="Amount" id="amount" value="" required>

</div>    

 <div class="modal-footer">
     <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    <button class="btn btn-primary" type="submit" name="add">Register</button>

    </div>

</form>
    </div>
    </div>
    </div>    
-->

    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>

