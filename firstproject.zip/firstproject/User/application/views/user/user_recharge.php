<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="page-body">
<!-- Container-fluid starts-->
<div class="container-fluid">
<div class="page-header">
<div class="row">
<div class="col-lg-6">
<div class="page-header-left">
<h3>Mobile Recharge</h3>
</div>

</div>
<div class="col-lg-6">
<?php
if($this->session->flashdata('success_message'))
{
echo '
<div class="alert alert-success" role="alert">
'.$this->session->flashdata("success_message").'
</div>
';
}
?>   
<?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 


</div>
 <center>
<div class="col-md-12" style="float:left">
   
<a href="recharge_table" class="btn btn-primary"  style="background-color:#0093BF !important">Mobile</a>

    <a href="dth" class="btn btn-primary" >DTH</a>
    <a href="data_card" class="btn btn-primary" >Data Card</a>
    <a href="gas_bill" class="btn btn-primary" >Gas Bill</a>
    <a href="water_bill" class="btn btn-primary" >Water Bill</a>
    <a href="electricity" class="btn btn-primary"  data->Electricity Bill</a>
      <a href="post_paid" class="btn btn-primary">Post Paid Bill</a>
</div>

    </center>
</div>
</div>
</div>  

  
<div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <??> Recharge</h5>
<button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>                                               
<form class="form-horizontal auth-form" method="post" action="#" onSubmit = "return checkPassword(this)" autocomplete="off">

<div class="form-group">
<select name="operator" id="" class="form-control"  value="<?=set_value('user_type')?>" required>
<option value="">Select Operator</option>
<?php
foreach($opt_code as $row)
{
?>
<option value="<?php echo $row->operator_code;
?>"><?php echo $row->operator_name;
?></option>
<?php } ?>
</select>
<?=form_error('operator');?>
<?php
foreach($opt_code as $row)
{
?>
<input type="hidden" name="service_type" value="<?php echo $row->service_name ?>">

<?php 
 
} ?>
</div>
<div class="form-group">
<input  name="mobile_no" type="text" class="form-control" min="0" max="10"  placeholder="Mobile Number" id="exampleInputEmail1" <?=set_value('mobile')?> autocomplete="off" required >
<?=form_error('mobile_no');?>
</div>
<div class="form-group">
<input  name="re_amount" type="text" class="form-control" placeholder="Amount" id="exampleInputpassword" value="<?=set_value('re_amount')?>" required>
<?=form_error('re_amount');?>
</div>    

<div class="modal-footer">
<button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
<button class="btn btn-primary" type="submit" name="add">Recharge</button>

</div>
</form>
</div>
</div>
</div> 



<?php
error_reporting(E_ALL ^ E_WARNING); 
    
$conn = mysqli_connect('localhost','root','','midbrzul_uniqculture');
?>  
<?php

if(isset($_POST['add']))
{
    $user_role = $_SESSION['login_id'];
    $fetch_user = mysqli_query($conn,"select * from user where id='$user_role'");
    
    $user = mysqli_fetch_assoc($fetch_user);
    $user_email = $user['email'];
    $operator = mysqli_query($conn,"select * from stop_operator where member_name='$user_email'");
    
    $member = mysqli_fetch_assoc($operator);
    $operator_name = $member['operator_name'];
$user_role_name = $user['user_type'];
$mobile = $_POST['mobile_no'];
//$mobile1 = $_POST['mobile_no'];
//$operators = $_POST['operator'];
$operators1 = $_POST['operator'];
$amount = $_POST['re_amount'];

$uniqueorderid = substr(number_format(time() * rand(),0,'',''),0,10);

$ch = curl_init();
$timeout = 60;
/*Recharge api Table Start */
$select_api = mysqli_query($conn,"select * from recharge_api where status='Active'");
$row = mysqli_fetch_assoc($select_api);

        $status =  $row['status'];
    $rech_api= $row['api_name'];
    /*Rechaarge api table end */
    
    /*Api setting table */
    $second_api = mysqli_query($conn,"select * from api_setting where api_name='$api_name'");
    $api = mysqli_fetch_assoc($second_api);
    $pass = $api['password'];
    /*Api setting table end*/
    
    /*Admin Table start */
    $select_amd = mysqli_query($conn,"select * from admin ");
    $amd = mysqli_fetch_assoc($select_amd);
   $admin = $amd['password'];
    $status = $row['status'];
    /*Admin Table end */
    
    /*Operator Table start*/
    $select_opt = mysqli_query($conn,"select * from operator where status ='$status'");
    $stts = mysqli_fetch_assoc($select_opt);
    $api_name = $stts['api_name'];
    //Operator Table end 
     $service_name = $stts['service_name'];
//    
    $select_amnt = mysqli_query($conn,"select * from amount_api where api_name ='$api_name'");
    $stop_operator = mysqli_fetch_assoc($select_amnt);
    
    $amount_stop_op = $stop_operator['amount'];
   $session =$_SESSION['login_id'];
    $get_wallet = mysqli_query($conn,"select * from request_balance where user_id ='$session'");
    
    $row_w = mysqli_fetch_assoc($get_wallet);
    
     $req_bal = $row_w['req_amount'];
    
    $total_wallet = $req_bal-$amount;
    
  if($amount>$req_bal){
      echo "You Have insuficiant Balance in wallet ";
  }else{
      
    if($operator_name!== $operator){
//    if($pass == $admin)
//    {
        if($amount_stop_op !== $amount){
/*Api setup Here */
if($status == "Active" AND $rech_api == "Pay1express" AND $api_name == "Pay1express"){
 $myHTTurl = "https://api.pay1express.com/POEAPI/RechargeAPI.aspx?MobileNo=9595847575&APIKey=72JOc1wa85mpcpUJqRjVeMoMRikMwgyaC3D&REQTYPE=RECH&REFNO=$uniqueorderid&SERCODE=$operators&CUSTNO=$uniqueorderid&REFMOBILENO=$mobile&AMT=$amount&STV=[IsSTV]&RESPTYPE=JSON";
 $rech_api_name = $rech_api;
}else if($status == "Active" AND $rech_api == "Ambika" AND $api_name == "Ambika") {
$myHTTurl = "https://ambikaecom.net/API/TransactionAPI?UserID=10431&Token=fef118a2f5758de1130282fde17365b1&SPKey=$operators1&Account=$mobile&Amount=$amount&APIRequestID=$uniqueorderid&OutletID=Janheet%20Recharge%20Solution&Format=JSON";
  $rech_api_name = $rech_api;
    }else if($status == "Active" AND $rech_api == "Mrobotics" AND $api_name == "Mrobotics"){
 $myHTTurl = "https://mrobotics.in/api/recharge_get?api_token=589be6bc-3aa1-4f0a-bb9c-2fcb6b51991d&mobile_no=$mobile&amount=$amount&company_id=5&OpCode=5&order_id=$uniqueorderid&is_stv=true";
$rech_api_name = $rech_api;
}

//        else{
//            echo "<span style='color:red'>Operator and Api Deactive !</span>";
//        }
        }
        else
        {
            echo "Failed Operator Amount";
        }
        /*Api setup Completed */

curl_setopt ($ch,CURLOPT_URL, $myHTTurl);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt( $ch, CURLOPT_TIMEOUT,$timeout);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT,$timeout);
$file_contents = curl_exec($ch);
$curl_error= curl_errno($ch);
curl_close($ch);

   $api_response = $file_contents;

$content = json_decode($file_contents, true);
//    print_r($content);
//  echo $std_id = $content['AGENTID'];

//    $maindata = explode(",",$file_contents);
$countdatas = count($content);
if($countdatas > 2)
{
    // Ambika Api Array form Here  
$order_id1 = $content[ORDERID];
$txnstatus1 = $content[STATUS];
$statuscode1 = $content[STATUSCODE];
 $agent1 = $content[AGENTID];
$amount1 = $content[AMOUNT];
$mywebsiteorderid1 = $content[5];
$msg = $content[MSG];
$operatorid1 = $content[OPID];
$myapibalance1 = $content[BAL];
$myapiprofit1 = $content[TRNID];
$txntime1 = $content[DT];


    
// Mrobotic Api array Form Here 
    $lapu_no = $content[lapu_no];
    $order_id = $content[order_id];
    $myapibalance = $content[balance];
    $roffer = $content[roffer];
    $txnstatus = $content[status];
    $recharge_date = $content[recharge_date];
    $id = $content[id];
    $lapu_id = $content[lapu_id];
    $user_id = $content[user_id];
    $operators = $content[company_id];
    $mobile3 = $content[mobile_no];
    $amount = $content[amount];
    $updatedAt = $content[updatedAt];
    $createdAt = $content[createdAt];
    $response = $content[response];
    $tnx_id = $content[tnx_id];
//echo "Hello There Howo ".$errorcode;
}
else{

$errorcode = $maindata[MSG];
}
if($curl_error =='28')
{
$txnstatus = "PENDING";
}
if($txnstatus1 == 'SUCCESS' OR $txnstatus=="success" )
{
//echo "Your Recharge Success";
    $success_status = "Success";
    $success_a = $amount."".$amount1;
    $success_hits = "1";
}
if($txnstatus1 == 'PENDING' OR $txnstatus == 'pending')
{
//echo "Your Recharge Pending";
        $success_status = "Success";
     $success_hits = "1";
        $success_a = $amount."".$amount1;
}
if($txnstatus1 == 'FAILED' OR $txnstatus == 'failure')
{
//echo "Your Recharge Failed";
        $failed_status = "Failed";
    $failed_a = $amount."".$amount1;
     $failed_hit = "1";
}
//dispaly the result to customer 
//echo "<br>";
//  echo "joloapi order ID: $operatorid ";
//    
//   echo "Recharge Status : $req_bal";
//    
//  echo "Number : $service";
//
//  echo "Amount : $amount";
//    
//   echo "My order id : $mywebsiteorderid";

//   echo "Operator Txn ID : $operatorid";
       echo $txnstatus;   
if($txnstatus1 == "PENDING" OR $txnstatus1 == "FAILED" OR $txnstatus == "failure" OR $txnstatus=="pending")
{
$operator_id = $operatorid;
}else{
$operator_id = $operatorid;
}
$date = date(ymdhms);
$sub_star = substr($date,5);
$transaction_id = "TR$sub_star";
        $session = $_SESSION['login_id'];
        
        if(empty($updatedAt) AND empty($createdAt)){
        $d=strtotime("+2 minute");
date_default_timezone_set("Asia/Calcutta"); 
            
            //India time (GMT+5:30)
$responce_date = date("Y-m-d h:i:sa", $d);
        
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d H:m:s');
        }else{
            $updat = $updatedAt;
            $create_at = $createdAt;
        }
        
        $query = mysqli_query($conn,"select * from operator where operator_code ='$operators$operators1'");
        
        $row_op = mysqli_fetch_assoc($query);
        
       $operator_name = $row_op['operator_name'] ;   

        $description = "Paid for $operator_name account no $mobile$mobile1 amount $amount$amount1";
            
if($txnstatus1 == "SUCCESS" OR $txnstatus1 == "PENDING" OR  $txnstatus1=="FAILED" OR $txnstatus == "failure" OR $txnstatus=="success"){

    
    $query  = mysqli_query($conn,"INSERT INTO `recharge`( `order_id`, `user_id`, `user_role`, `api_name`, `trans_id`, `operator_id`, `service`, `website_order`, `error_code`, `myapibalance`,`closing`, `myapiprofit`, `operator`, `mobile_no`, `commision`, `date`, `updated_at`, `created_at`, `response`,`api_response`, `mode`, `total_hits`, `success_hits`, `success_amount`, `failed_amount`, `failed_hits`, `success_status`, `failed_status`) VALUES ('1','$session','$user_role_name','$rech_api_name','$transaction_id','
$operatorid1
$tnx_id','$amount$amount1','','','$myapibalance$myapibalance1','$total_wallet','','$operator_name','$mobile$mobile1','','$date','$updat$responce_date','$create_at$date','$response$msg','$api_response','Web', '1','$success_hits','$success_a','$failed_a','$failed_hit','$success_status','$failed_status')");

   
    
    $query = mysqli_query($conn);
   print_r($query);
    if($query)
    {
        echo "SUccessfully Insert !";
    }else{
       
    }
   
    

//echo $query;
    if($query){
echo "<script>

swal({
  title: 'Good job!',
  text: '$txnstatus',
  icon: 'success',
  button: 'Ok',
}).then(function() {
window.location = 'recharge_table';
});

</script>";
    }else{
      echo mysqli_error($conn);
    }
}
else{

}
//}
//    else{
//       echo "<div class='alert alert-danger'>
//<strong>Recharge api Not Active !</strong>
//</div>";
//    }
    }
    else{
//   echo "<div class='alert alert-danger'>
//<strong>Your Operator Stop !</strong>
//</div>";
    }
  }
    
}
    
   if(isset($_POST['add'])) {
       
       $amount_for_wallet = $_POST['re_amount'];
       $session = $_SESSION['login_id'];
         $select_wallet = mysqli_query($conn,"select * from request_balance where user_id = '$session'");
    $wallet_row = mysqli_fetch_assoc($select_wallet);
    $wallet_amount = $wallet_row['req_amount'];
       if($amount_stop_op !== $amount){
    if($wallet_amount > $amount_for_wallet OR $txnstatus1 == "PENDING" OR  $txnstatus1=="FAILED" OR $txnstatus == "failure"){
        
      $total_wallet = $wallet_amount -  $amount_for_wallet;
    $upd_wallet = mysqli_query($conn,"update request_balance set req_amount = '$total_wallet' where user_id ='$session' "); 
        
        
        $query = mysqli_query($conn,"INSERT INTO `ladger`(`user_id`, `transaction_id`, `datetime`, `description`, `debit`, `credit`, `current_bal`, `remark`) VALUES ('$session','$transaction_id','$date','$description','$amount$amount1','00','$total_wallet','Ok')");
    }else{
        echo "<script>alert('You Can not Add amount in wallet')</script>";
        echo "<script>window.open('recharge_table','_self')</script>";
    }
       }else{
           
       }
   }

?>
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>  
<div class="container-fluid">
<div class="card">

<div class="card-header-right" style="padding:10px;">

<div class="col-md-4" style="float:left">
<ul class="list-unstyled card-option">
<!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
<!--                                <li><i class="view-html fa fa-code"></i></li>-->
<li><i class="icofont icofont-maximize full-card"></i></li>
<li><i class="icofont icofont-minus minimize-card"></i></li>
<li><i class="icofont icofont-refresh reload-card"></i></li>
<li><i class="icofont icofont-error close-card"></i></li>
</ul>
</div> 
  <div class="col-md-4" style="float:right">
      <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Mobile Recharge</a>
  </div>

</div>      
<div  class="table-responsive">

<table  class="table table-bordered table-striped">
  <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Transaction Id</th>  
    <th>Operator Id</th>
    <th>Operator Name </th> 
    <th>Api Name</th>                       
    <th>Mobile No. </th>
    <th>Amount</th>
    <th>Crosing</th>
    <th>Req Date</th>
    <th>Mode</th>
    <th>Status</th>

    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
    $i = 1;
 
    foreach($user as $row)
    {
      
    
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?php echo $row->trans_id;?>  </td> 
    <td><?php echo $row->operator_id?></td>   
    <td><?php echo  $row->operator ?></td>   
    <td><?php echo $row->api_name?></td>           
    <td><?php echo $row->mobile_no; ?></td> 
    <td><?php echo $row->service ?></td> 
    <td><?php echo $row->closing?></td>
    <td><?php echo  $row->created_at ?></td> 
        <td><?php echo  $row->mode ?></td> 

    
    <td><?php echo  $row->success_status ."". $row->failed_status ?></td> 
    

    </tr>
    <?php
    }
    }
    ?> 
</table>


</div>
</div>
<!-- Container-fluid Ends-->
</div>
</div>