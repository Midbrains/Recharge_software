
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

            <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Recharge Search</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>   
        <?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 
    </div>
    </div>
    </div>
    </div>   
    <div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit Recharge</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
 <form class="form-horizontal auth-form" method="post" action="<?= base_url('user_api/recharge');?>" onSubmit = "return checkPassword(this)">
 
<div class="form-group">

</div>
<div class="form-group">
<input  name="mobile_no" type="text" class="form-control" min="0" max="10"  placeholder="Mobile Number" id="exampleInputEmail1" <?=set_value('mobile')?> autocomplete="off" required>
<?=form_error('mobile_no');?>
</div>
<div class="form-group">
<input  name="re_amount" type="text" class="form-control" placeholder="Amount" id="exampleInputpassword" value="<?=set_value('re_amount')?>" required>
<?=form_error('re_amount');?>
</div>    

 <div class="modal-footer">
     <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    <button class="btn btn-primary" type="submit" name="add">Recharge</button>

    </div>

</form>
    </div>
    </div>
    </div>    
        
      
        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <form action="#" method="post" >
     <div class="col-md-6" style="float:left">
   <label for="" style="margin-left:50%;margin-top:10px;font-weight:bold">Search :</label>
        <input type="text" name="search_text" class="form-control col-md-4" style="float:right;margin:0px 3px" id="search_text" placeholder="Trans / Date">
    </div>  
        </form>
    </div>      
    <div class="card-body">

     <div id="result"></div>
</div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>


<script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"<?php echo base_url(); ?>User/fetch_search",
   method:"POST",
   data:{query:query},
   success:function(data){
    $('#result').html(data);
   }
  })
 }

 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>