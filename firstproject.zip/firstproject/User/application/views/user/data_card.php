<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="page-body">
<!-- Container-fluid starts-->
<div class="container-fluid">
<div class="page-header">
<div class="row">
<div class="col-lg-6">
<div class="page-header-left">
<h3>Data Card</h3>
</div>

</div>
<div class="col-lg-6">
<?php
if($this->session->flashdata('success_message'))
{
echo '
<div class="alert alert-success" role="alert">
'.$this->session->flashdata("success_message").'
</div>
';
}
?>   
<?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 


</div>
 <center>
<div class="col-md-12" style="float:left">
   
<a href="recharge_table" class="btn btn-primary" >Mobile</a>

    <a href="dth" class="btn btn-primary" >DTH</a>
    <a href="data_card" class="btn btn-primary"  style="background-color:#0093BF !important">Data Card</a>
    <a href="gas_bill" class="btn btn-primary" >Gas Bill</a>
    <a href="water_bill" class="btn btn-primary" >Water Bill</a>
    <a href="electricity" class="btn btn-primary"  data->Electricity Bill</a>
      <a href="post_paid" class="btn btn-primary">Post Paid Bill</a>
      
</div>

    </center>
</div>
</div>
</div>   
<div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <??> Recharge</h5>
<button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>                                               
<form class="form-horizontal auth-form" method="post" action="#" onSubmit = "return checkPassword(this)">

<div class="form-group">
<select name="operator" id="" class="form-control"  value="<?=set_value('user_type')?>" required>
<option value="">Select Operator</option>
<?php
foreach($opt_code as $row)
{
?>
<option value="<?php echo $row->operator_code;
?>"><?php echo $row->operator_name;
?></option>
<?php } ?>
</select>
<?=form_error('operator');?>
</div>
<div class="form-group">
<input  name="mobile_no" type="text" class="form-control" min="0" max="10"  placeholder="Mobile Number" id="exampleInputEmail1" <?=set_value('mobile')?> autocomplete="off" required>
<?=form_error('mobile_no');?>
</div>
<div class="form-group">
<input  name="re_amount" type="text" class="form-control" placeholder="Amount" id="exampleInputpassword" value="<?=set_value('re_amount')?>" required>
<?=form_error('re_amount');?>
</div>    

<div class="modal-footer">
<button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
<button class="btn btn-primary" type="submit" name="add">Recharge</button>

</div>

</form>
</div>
</div>
</div> 

<?php
error_reporting(E_ALL ^ E_WARNING); 
    
$conn = mysqli_connect('localhost','root','','midbrzul_uniqculture');
?>  
<?php

if(isset($_POST['add']))
{
    $user_role = $_SESSION['login_id'];
    $fetch_user = mysqli_query($conn,"select * from user where id='$user_role'");
    
    $user = mysqli_fetch_assoc($fetch_user);
    $user_email = $user['email'];
    $operator = mysqli_query($conn,"select * from stop_operator where member_name='$user_email'");
    
    $member = mysqli_fetch_assoc($operator);
    $operator_name = $member['operator_name'];
$user_role_name = $user['user_type'];
$mobile = $_POST['mobile_no'];
$operators = $_POST['operator'];
$amount = $_POST['re_amount'];

$uniqueorderid = substr(number_format(time() * rand(),0,'',''),0,10);

$ch = curl_init();
$timeout = 60;

$select_api = mysqli_query($conn,"select * from recharge_api where status='Active'");
$row = mysqli_fetch_assoc($select_api);

//        echo $row['status'];
    $api_name = $row['api_name'];
    $second_api = mysqli_query($conn,"select * from api_setting where api_name='$api_name'");
    $api = mysqli_fetch_assoc($second_api);
    $pass = $api['password'];
    $select_amd = mysqli_query($conn,"select * from admin ");
    $amd = mysqli_fetch_assoc($select_amd);
   $admin = $amd['password'];
    $status = $row['status'];
    $select_opt = mysqli_query($conn,"select * from operator where status ='$status'");
    $stts = mysqli_fetch_assoc($select_opt);
    $api_name = $stts['api_name'];
    
    $select_amnt = mysqli_query($conn,"select * from amount_api where api_name ='$api_name'");
   echo  $amount_stop_op = $stop_operator['amount'];
    if($operator_name!== $operator){
    if($pass == $admin)
    {
        if( $amount_stop_op !== $amount){
if($stts['status']=="Active" && $stts['api_name'] == "Pay1express" ){
 
    $myHTTurl = "https://api.pay1express.com/POEAPI/RechargeAPI.aspx?MobileNo=9595847575&APIKey=2JOc1wa85mpcpUJqRjVeMoMRikMwgyaC3D&REQTYPE=RECH&REFNO=$uniqueorderid&SERCODE=$operator&CUSTNO=$uniqueorderid&REFMOBILENO=$mobile&AMT=$amount&STV=[IsSTV]&RESPTYPE=JSON";
}else if($stts['status'] == "Active" && $stts['api_name'] == "Ambika" && $amount_stop_op !== $amount){
$myHTTurl = "https://ambikaecom.net/API/TransactionAPI?UserID=10431&Token=fef118a2f5758de1130282fde17365b1&SPKey=$operators&Account=$mobile&Amount=$amount&APIRequestID=$uniqueorderid&OutletID=Janheet%20Recharge%20Solution&Format=JSON";
// $myHTTurl = "https://mrobotics.in/api/recharge_get?api_token=589be6bc-3aa1-4f0a-bb9c-2fcb6b51991d&mobile_no=$mobile&amount=$amount&company_id=5&OpCode=5&order_id=$uniqueorderid&is_stv=true";
    }
        else{
            echo "<span style='color:red'>Operator and Api Deactive !</span>";
        }
        }else{
            echo "Faile Operator Amount";
        }

curl_setopt ($ch,CURLOPT_URL, $myHTTurl);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt( $ch, CURLOPT_TIMEOUT,$timeout);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT,$timeout);
$file_contents = curl_exec($ch);
$curl_error= curl_errno($ch);
curl_close($ch);

   echo  $file_contents;

$content = json_decode($file_contents, true);
//    print_r($content);
//  echo $std_id = $content['AGENTID'];

//    $maindata = explode(",",$file_contents);
$countdatas = count($content);
if($countdatas > 2)
{
$order_id = $content[ORDERID];
$txnstatus = $content[STATUS];
$txnstatus = $content[STATUSMSG];
$trnid = $content[BAL];
//        $operator = $content[];
$agent= $content[AGENTID];
$amount = $content[AMOUNT];
$mywebsiteorderid = $content[5];
$errorcode = $content[MSG];
$operatorid = $content[OPID];
$myapibalance = $content[BAL];
$myapiprofit = $content[TRNID];
$txntime = $content[DT];

}
else{
$txnstatus = $maindata[STATUS];
$errorcode = $maindata[MSG];
}
if($curl_error =='28')
{
$txnstatus = "PENDING";
}
if($txnstatus == 'SUCCESS')
{
echo "Your Recharge Success";
    $success_status = "Success";
    $success_a = $amount;
    $success_hits = "1";
}
if($txnstatus == 'PENDING')
{
echo "Your Recharge Pending";
        $success_status = "Success";
     $success_hits = "1";
        $success_a = $amount;
}
if($txnstatus == 'FAILED')
{
echo "Your Recharge Failed";
        $failed_status = "Failed";
    $failed_a = $amount;
     $failed_hit = "1";
}
//dispaly the result to customer 
//echo "<br>";
//  echo "joloapi order ID: $trnid";
//    
//   echo "Recharge Status : $myapiprofit";
//    
//  echo "Number : $service";
//
//  echo "Amount : $amount";
//    
//   echo "My order id : $mywebsiteorderid";

//   echo "Operator Txn ID : $operatorid";
if($txnstatus == "PENDING" OR $txnstatus == "FAILED")
{
$operator_id = $operatorid;
}else{

$operator_id = $operatorid;
}
$date = date(ymdhms);
$sub_star = substr($date,5);
$transaction_id = "TR$sub_star";
        $session = $_SESSION['login_id'];
//   echo "Error No. : $errorcode";

if($txnstatus == "SUCCESS" OR $txnstatus == "PENDING" OR  $txnstatus=="FAILED"){
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');
$ins = mysqli_query($conn,"INSERT INTO `recharge`(`user_role`,`order_id`,user_id, `trans_id`, `operator_id`, `service`, `website_order`, `error_code`, `myapibalance`, `myapiprofit`, `operator`, `mobile_no`, `commision`, `date`, `total_hits`, `success_hits`, `success_amount`, `failed_amount`, `failed_hits`, `success_status`, `failed_status`) 
VALUES ('$user_role_name','$joloapiorderid', '$session', '$transaction_id','$operator_id','$amount','','$errorcode','$myapibalance','$myapiprofit','$operators','$mobile','','$date','1','$success_hits','$success_a','$failed_a','$failed_hit','$success_status','$failed_status')");
  
    if($ins){
echo "<script>

swal({
  title: 'Good job!',
  text: '$txnstatus',
  icon: 'success',
  button: 'Ok',
}).then(function() {
window.location = 'recharge_table';
});

</script>";
    }else{
        echo "<script>
swal({
  title: 'Failed !',
  text: '$txnstatus',
  icon: 'Warning',
  button: 'Ok',
})

</script>
";
    }
}
else{
echo "
<script>
swal({
  title: 'Failed !',
  text: Your Recharge $txnstatus',
  icon: 'Warning',
  button: 'Ok',
})

</script>
";


}
}else{
       echo "<div class='alert alert-danger'>
<strong>Recharge api Not Active !</strong>
</div>";
    }
    }
    else{
   echo "<div class='alert alert-danger'>
<strong>Your Operator Stop !</strong>
</div>";
    }
    
}
    
    

?>
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>  
<div class="container-fluid">
<div class="card">

<div class="card-header-right" style="padding:10px;">

<div class="col-md-4" style="float:left">
<ul class="list-unstyled card-option">
<!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
<!--                                <li><i class="view-html fa fa-code"></i></li>-->
<li><i class="icofont icofont-maximize full-card"></i></li>
<li><i class="icofont icofont-minus minimize-card"></i></li>
<li><i class="icofont icofont-refresh reload-card"></i></li>
<li><i class="icofont icofont-error close-card"></i></li>
</ul>
</div> 
  <div class="col-md-2" style="float:right">
      <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Data Card</a>
  </div>

</div>      
<div class="card-body">

<table class="" id="basic-1">
<thead>
<tr>
<th>Sr.No.</th>
<th>Transaction Id</th>
<th>Operator Code</th>  
<th>Mobile No. </th>                        
<th>Amount </th>
<th>Status</th>
</tr>
</thead>
<tbody>  
<?php 

$i = 1;

foreach($user as $row)
{


?>
<tr>
<td><?=$i++;?></td>
<td><?php echo $row->trans_id;?> </td>
<td> <?php echo $row->operator;?>  </td>                          
<td><?php echo $row->mobile_no; ?></td> 
<td><?php echo $row->service ?></td> 
<td><?php echo  $row->success_status ."". $row->failed_status ?></td> 

</tr>
<?php
}

?> 
</tbody>
</table>


</div>
</div>
<!-- Container-fluid Ends-->
</div>
</div>