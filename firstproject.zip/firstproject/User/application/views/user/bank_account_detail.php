<style>
    .bank_details{
        float: left;
    }
</style>
        <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Package Setting</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>   
        <?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 
    </div>
    </div>
    </div>
    </div>   
    <div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    
    </div>    
        
      
        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
   
    </div>      
    <div class="card-body">
    <?php
    foreach($bank_details as $row)
    {
    ?>
<div class="col-md-12" style="border:2px solid #00BAF2;padding:20px">
        <H3> *<?php echo $row->bank_name?> </H3>
    <div class="col-md-6 bank_details " style="padding:10px">
        <Span style="font-weight:bold">Bank Name</Span>
    </div><div class="col-md-6 bank_details" style="padding:10px">
        <Span><?php echo $row->bank_name ?></Span>
    </div> <div class="col-md-6 bank_details " style="padding:10px">
        <Span style="font-weight:bold">Account Number</Span>
    </div><div class="col-md-6 bank_details" style="padding:10px">
    <Span><?php 
        echo $row->account_number
        ?></Span>
    </div> <div class="col-md-6 bank_details " style="padding:10px">
        <Span style="font-weight:bold">Ifsc Code</Span>
    </div><div class="col-md-6 bank_details" style="padding:10px">
        <Span><?php
            echo $row->ifsc_code
            ?></Span>
    </div> <div class="col-md-6 bank_details " style="padding:10px">
        <Span style="font-weight:bold">Branch Name</Span>
    </div><div class="col-md-6 bank_details" style="padding:10px">
        <Span><?php
            echo $row->branch_name
            ?></Span>
    </div>
       <div class="col-md-6 bank_details " style="padding:10px">
        <Span style="font-weight:bold">Holder Name</Span>
    </div><div class="col-md-6 bank_details" style="padding:10px">
        <Span><?php
            echo $row->holder_name
            ?></Span>
    </div>
    
     <div style="clear:both"></div>
</div>
   <?php } ?>
    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>

