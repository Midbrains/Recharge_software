    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Package Setting</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>   
        <?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 
    </div>
    </div>
    </div>
    </div>   

      
        
      
        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <br>
    <br>
    <div class="col-md-12" style="float:left">
  
                                                
 <form class="form-horizontal auth-form" method="post" action="<?= base_url('user/update_user_profile');?>">
<?php
     foreach($user as $row)
         
     ?>

<div class="form-group col-md-6" style="float:left">
<label for="">Username</label>
<input  name="username" type="text" class="form-control" min="0" max="10"  placeholder="username" id="" value="<?=ucwords($row->username)?>" autocomplete="off" required>
<?=form_error('mobile_no');?>
</div>
<div class="form-group col-md-6" style="float:left">
<label for="">Email</label>
<input  name="email" type="email" class="form-control" placeholder="email" id="" value="<?=ucwords($row->email)?>" required readonly>
<?=form_error('re_amount');?>
</div> <div class="form-group col-md-6" style="float:left">
<label for="">User Type</label>
<input  name="user_type" type="text" class="form-control" placeholder="User Type" id="" value="<?=ucwords($row->user_type)?>" required readonly>
<?=form_error('re_amount');?>
</div> <div class="form-group col-md-6" style="float:left">
<label for="">Mobile</label>
<input  name="mobile" type="text" class="form-control" placeholder="mobile" id="" value="<?=ucwords($row->mobile)?>" required>
<?=form_error('re_amount');?>
</div>  

 <div class="modal-footer">
 
    <button class="btn btn-primary" type="submit" name="user_profile">Update</button>

    </div>

</form>
   
    </div>
    </div>      
    <div class="card-body">
<!--<form action="<?//= base_url('user/package_status').$row->package_id;?>" enctype="multipart/form-data" method="post">-->
   
<!--        </form>-->
    
    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>

