    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Create Retailer</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>   
        <?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?> 
    </div>
    </div>
    </div>
    </div>   
    <div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Create Retailer</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
 <form class="form-horizontal auth-form" method="post" action="<?= base_url('user/recharge');?>" onSubmit = "return checkPassword(this)">
 
<div class="form-group">

</div>
<div class="form-group">
<input  name="username" type="text" class="form-control"  placeholder="Username" <?=set_value('username')?> autocomplete="off" required>
<?=form_error('username');?>
</div>
<div class="form-group">
<input  name="email" type="text" class="form-control" placeholder="Email" value="<?=set_value('email')?>" required>
<?=form_error('email');?>
</div>    
 <div class="form-group">
<input  name="mobile" type="text" class="form-control" placeholder="Mobile Number" value="<?=set_value('mobile')?>" required>
<?=form_error('mobile');?>
</div>    
 <div class="form-group">
<select  name="user_type" type="text" class="form-control" placeholder="User Type" value="<?=set_value('user_type')?>" required>
    <option value="">Select User Type</option>
    <option value="retailer">Retailer</option>
     </select>
<?=form_error('user_type');?>
</div>    
 <div class="form-group">
<input  name="new_password" type="password" class="form-control" placeholder="New Password" value="<?=set_value('new_password')?>" required>
<?=form_error('new_password');?>
</div>
   <div class="form-group">
<input  name="c_password" type="password" class="form-control" placeholder="Confirm Password" value="<?=set_value('c_password')?>" required>
<?=form_error('c_password');?>
</div>    

 <div class="modal-footer">
     <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    <button class="btn btn-primary" type="submit" name="add">Create</button>

    </div>

</form>
    </div>
    </div>
    </div>    
        
      
        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">
    <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Add</a>
    </div>  
    </div>      
    <div class="card-body">
<!--<form action="<?//= base_url('user/package_status').$row->package_id;?>" enctype="multipart/form-data" method="post">-->
    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Username</th>  
    <th>Email</th>                        
    <th>Mobile </th>
    <th>Reg Date</th>
    <th>User Type</th>
    </tr>
    </thead>
    <tbody>  
    <?php 
     foreach($session as $users)
    if($users->user_type=="retailer"){
    
    if($user){
    $i = 1;
 
    foreach($user as $row)
    {
      
    
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?php echo $row->username;?>  </td>                          
    <td><?php echo $row->email; ?></td> 
    <td><?php echo $row->mobile ?></td> 
    <td><?php echo  $row->reg_date ?></td> 
    <td><?php echo  $row->user_type ?></td> 

    </tr>
    <?php
    }
    }
    }
    ?> 
     
    </tbody>
    </table>
<!--        </form>-->
    
    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>
<script>

// Function to check Whether both passwords
// is same or not.
function checkPassword(form) {
password1 = form.new_password.value;
password2 = form.c_password.value;

// If password not entered
if (password1 == '')
alert ("Please enter Password");

// If confirm password not entered
else if (password2 == '')
alert ("Please enter confirm password");

//  If Not same return False.
else if (password1 != password2) {
alert ("\nPassword did not match: Please try again...")
return false;
}

else{
// alert("Your Password is updated successfull!")
return true;
}
}
</script>
