<?php

class user extends CI_Controller{
    
    
    public function index()
    {
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
        
            
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve)->get('request_balance')->result();
      
         $this->load->view('header',$data);
    $session = $_SESSION['login_id'];
//        $data['user'] = $this->db->where('id',$session)->get('user')->result();
//      
//        
//        $data['rech'] = $this->db->select('SUM(id)')
//        ->from('recharge')
//        ->get()->result();
//        
       
        $this->load->view('dashboard', $data);
        $this->load->view('footer');
    }
    
    public function recharge_table()
    {
           
        if($this->session->userdata('login_id'))
		{
            
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/user_recharge',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
	
       
        
       
    }
    
    public function user_regitration()
    {
//        $this->load->view('header');
        $this->load->view('user_reg');
//        $this->load->view('footer');
    }
      public function insert_reg()
    {
        $data = array();
        if(isset($_POST['registration']))
        {
            $data['username'] = $_POST['username'];
            $data['email'] = $_POST['email'];
            $data['mobile'] = $_POST['mobile_no'];
            $data['user_type'] = $_POST['user_type'];
            $data['password'] = md5($_POST['new_password']);
            $data['reg_date'] = date('Y/m/d');
            $data['reg_by'] = "Web";
            $data['status'] = "Active";

            $this->session->set_flashdata('success_message','Record Insert Successfully !');
//            alert('insert Successfully !');

            $this->db->insert('user',$data);


        }
        redirect('login');
    }
    
    public function user_logout()
	{
	  $data = $this->session->all_userdata();
	  foreach($data as $row => $rows_value)
	  {
	   $this->session->unset_userdata($row);
	  }
	  redirect('Login');
	}
    
      public function recharge()
    {
//        $data = array();
//        $data['operator'] = $_POST['operator'];
//        $data['mobile_no'] = $_POST['mobile_no'];
//        $data['re_amount'] = $_POST['re_amount'];
        
        $op = $_POST['operator'];
        $mo_no = $_POST['mobile_no'];
        $re_a = $_POST['re_amount'];
        $data['status'] = "Active";
       $uniqueorderid = substr(number_format(time() * rand(),0,'',''),0,10);
//        $q = $this->db->insert('recharge', $data);
           $recharge = "https://ambikaecom.net/API/TransactionAPI?UserID=10431&Token=fef118a2f5758de1130282fde17365b1&SPKey=$op&Account= $mo_no&Amount=   $re_a&APIRequestID=$uniqueorderid&OutletID=Janheet%20Recharge%20Solution&Format=JSON";
      
    
        if($recharge)
        {  
        $this->session->set_flashdata('success_message','Your Recharge Success !');
            redirect('user_api/operator_get');
        }
          else{
             $this->session->set_flashdata('message','Your Recharge Failed !');
            redirect('user_api/operator_get');
        }
    }
    
    // Distributor Section Start From here 
    
    public function get_retailer()
    {
   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
        
            
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
      
         $this->load->view('header',$data);
         $session = $_SESSION['login_id'];
        
          $data['session']=$this->db->where('id',$session)
            ->get('user')->result();
        
        $data['data_user'] = $this->db->where('user_id',$session)->get('user')->result();
        
        $data['user']=$this->db->where('user_type','retailer')
            ->get('user')->result();
        
        $data['dist']=$this->db->where('user_type','distributor')
            ->get('user')->result();
        
         $data['master']=$this->db->where('user_type','master')
            ->get('user')->result();
        
         $data['super']=$this->db->where('user_type','super')
            ->get('user')->result();
        
        $this->load->view('distributor/get_retailer',$data);
        $this->load->view('footer');
        
    }
    
    public function create_retailer()
    {
       
        $data = array();
        if(isset($_POST['add'])){
            $data['user_id'] = $_SESSION['login_id'];
        $data['username'] = $_POST['username'];
        $data['email'] = $_POST['email'];
        $data['user_type'] = $_POST['user_type'];
        $data['mobile'] = $_POST['mobile'];
        $data['password'] = md5($_POST['new_password']);
         date_default_timezone_set("Asia/Calcutta"); 
       $data['reg_date']= date('Y-m-d');
        $data['reg_by'] = "Web";
        $data['status'] = "Active";
    
        
        $q = $this->db->insert('user',$data);
        if($q)
        {
             
        $this->session->set_flashdata('success_message','Record Add Successfully !'); 
        }else{
           $this->session->set_flashdata('message','Record Failed  !');    
        }

    }
                
     redirect('User/get_retailer');
    }
    
    public function payment_req()
    {
     
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
            
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
        
         $this->load->view('header',$data);
        $this->load->view('distributor/payment_req');
        $this->load->view('footer');
        
    }
    
    public function user_profile()
        
    {
      
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
            
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
        
         $this->load->view('header',$data);
        $session = $_SESSION['login_id'];
        $data['user'] = $this->db->where('id',$session)->get('user')->result();
        
        $this->load->view('user/profile',$data);
        
        $this->load->view('footer');
    }
    
    public function update_user_profile()
    {
        $data = array();
        if(isset($_POST['user_profile']))
        {
            $session = $_SESSION['login_id'];
            $data['username'] = $_POST['username'];
            
            $data['email'] = $_POST['email'];
            
            $data['mobile'] = $_POST['mobile'];
            
            $data['user_type']=
                $_POST['user_type'];
            
            $this->session->set_flashdata('success_message','Update User Profile !');
            
            $this->db->where('id',$session)->update('user',$data);
            
            
        }redirect('user/user_profile');
    }
    
    public function money()
    {
      
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
            
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
        
         $this->load->view('header',$data);
         $data['bank'] = $this->db->get('add_bank')->result();
        $data['user'] = $this->db->where('id',$session)->get('user')->result();
        $this->load->view('wallet/wallet',$data);
        $this->load->view('footer');
        
    }
    
    public function request_balance()
    {
      $data = array();
        if(isset($_POST['payment_req']))
        {
            $data['user_id'] = $_SESSION['login_id'];
            $data['bank_name'] = $_POST['bank_name'];
            $data['phone'] = $_POST['mobile_no']; 
            $data['deposit_account'] = $_POST['account_no'];
//            $data['deposit_account']=$_POST['d_account'];

            $data['payment_mode'] = $_POST['pay_mode'];

            $data['transaction_id'] = $_POST['trans_id'];

            $data['req_amount']= $_POST['req_amount'];

      date_default_timezone_set('Asia/Calcutta');
   $data['req_date'] = date("Y-m-d");
          $data['status'] = "Pending";
          $data['user_type'] = $_POST['user_type']; $data['user_name'] = $_POST['username'];
           
            $q = $this->db->insert('request_balance',$data);

            if($q)
            {
               $this->session->set_flashdata('success_message','Request Sent Successfull !');
            }
            redirect('user/money');
        }

    }
    
    public function complain()
    {
         
       $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
        
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
        
         $this->load->view('header',$data);
    $session = $_SESSION['login_id'];
        $data['user'] = $this->db->get('user')->result();
      $data['comp'] = $this->db->where('user_id',$session)->get('complain')->result();
        $this->load->view('complain/complain', $data);
        $this->load->view('footer');
    }
    
    public function complain_enquiry()
    {
        $data = array();
        if(isset($_POST['add_complain']))
        {
           $data['username'] = $_POST['user_name'];
            
            $data['complain'] = $_POST['complain'];
            
            $data['status']="Send";
            
            $data['user_id'] = $_SESSION['login_id'];
            
            $q = $this->db->insert('complain',$data);
            
            if($q)
            {
                $this->session->set_flashdata('success_message','Complain send Successfully !');
                
            }
        }
        redirect('user/complain');
        
    }
   
     public function dth()
    {
           
        if($this->session->userdata('login_id'))
		{   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/dth',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
	
       
        
       
    }
    
    
    
     public function data_card()
    {
           
        if($this->session->userdata('login_id'))
		{   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/data_card',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
	
    }
    
    
     public function gas_bill()
    {
           
        if($this->session->userdata('login_id'))
		{   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/gas_bill',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
  
    }
    
    
     public function water_bill()
    {
           
        if($this->session->userdata('login_id'))
		{   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/water_bill',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
   
    }
    
    
    
     public function electricity()
    {
           
        if($this->session->userdata('login_id'))
		{   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/electricity_bill',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
    
    }
    
    
     public function post_paid()
    {
           
        if($this->session->userdata('login_id'))
		{   
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['user'] = $this->db->where('user_id',$session)-> get('recharge')->result();
        $data['opt_code'] = $this->db->where('status','Active')->get('operator')->result();
        
			  $this->load->view('user/post_paid',$data);   
       
      
        $this->load->view('footer');
        }else{
           	redirect('Login');
        }
    }
    
    
    public function recharge_report()
    {
        $this->load->view('header');
        $this->load->view('user/report_recharge');
        $this->load->view('footer');
    }
    
    public function bank_details()
    {
           $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $this->db->get('add_bank')->result();
        $data['bank_details'] = $this->db->get('add_bank')->result();
        $this->load->view('user/bank_account_detail', $data);
        $this->load->view('footer');
    }
    
    public function balance_request_report()
    {
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['report'] = $this->db->get('request_balance')->result();
        $this->load->view('user/balance_request_report', $data);
        $this->load->view('footer');
    }
    
    public function recharge_search()
    {
        
         $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data); date_default_timezone_set('Asia/Calcutta'); 
        $date = date("Y-m-d"); 
        $data['rech'] = $this->db->where('user_id',$session)->
            where('date',$date)->get('recharge')->result();
        $this->load->view('user/recharge_search',$data);
        $this->load->view('footer');
    }

    
    public function account_details()
    {
     $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['ladger']= $this->db->where('user_id',$session)->get('ladger')->result();
        
        $this->load->view('user/account_details',$data);
        $this->load->view('footer');
        
    } 
    
    public function ledger_report()
    {
     $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
        $data['ladger']= $this->db->where('user_id',$session)->get('ladger')->result();
        
        $this->load->view('user/ledger_report',$data);
        $this->load->view('footer');
        
    }
    
    public function company_details()
    {
        
       $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
      $data['company'] = $this->db->get('company_toll_free')->result();
        $this->load->view('user/operator_details',$data);
        $this->load->view('footer');
    }
    
    
    
      public function costomer_details()
    {
        
          $session = $_SESSION['login_id'];
        $data['users'] = $this->db->where('id',$session)->get('user')->result();
      
                
      $approve = "Approved";
        $data['wallets'] = $this->db->select_sum('req_amount')->where('user_id',$session,'status',$approve )->get('request_balance')->result();
            
         $this->load->view('header',$data);
      $data['costomer'] = $this->db->get('costomer')->result();
        $this->load->view('user/costomer-details',$data);
        $this->load->view('footer');
    }
    
//    public function recharge_search()
//    {
//        if(isset($_POST['submit_btn'])){
//         $trans_id =   $this->input->post('transaction');
//          $date =  $this->input->post('date');
//            
//        $this->db->where('trans_id',$trans_id, 'date', $date)
//    }
//    }
    
    
    
 function fetch()
 {
  $output = '';
  $query = '';
  $this->load->model('user_login');
  if($this->input->post('query'))
  {
   $query = $this->input->post('query');
  }
  $data = $this->user_login->fetch_data($query);
  $output .= '
  <div class="table-responsive" >
     <table class="table table-bordered table-striped" id="basic-1">
      <tr>
       <th>Transaction Id</th>
       <th>Date Time</th>
       <th>Description</th>
       <th>Debit</th>
       <th>Credit</th>
       <th>Current Balance</th>
       <th>Remark</th>
      </tr>
  ';
  if($data->num_rows() > 0)
  {
   foreach($data->result() as $row)
   {
    $output .= '
      <tr>
       <td>'.$row->transaction_id.'</td>
       <td>'.$row->datetime.'</td>
       <td>'.$row->description.'</td>
       <td>'.$row->debit.'</td>
       <td>'.$row->credit.'</td>
        <td>'.$row->current_bal.'</td>
         <td>'.$row->remark.'</td>
      </tr>
    ';
   }
  }
  else
  {
   $output .= '<tr>
       <td colspan="7" style="text-align:center">No Data Found</td>
      </tr>';
  }
  $output .= '</table>';
  echo $output;
 }
   
    
 function fetch_search()
 {
  $output = '';
  $query = '';
  $this->load->model('user_login');
  if($this->input->post('query'))
  {
   $query = $this->input->post('query');
  }
  $data = $this->user_login->recharge_fetch_data($query);
  $output .= '
  <div class="table-responsive" >
     <table class="table table-bordered table-striped" id="basic-1">
      <tr>
       <th>Sr.No.</th>
    <th>Transaction Id</th>  
    <th>Operator Id</th>
    <th>Operator Name </th> 
    <th>Api Name</th>                
    <th>Mobile No. </th>
    <th>Amount</th>
    <th>Crosing</th>
    <th>Req Date</th>
    <th>Mode</th>
    <th>Status</th>
 
      </tr>
  ';
  if($data->num_rows() > 0)
  {
      $i = 1;
   foreach($data->result() as $row)
   {
    $output .= '
      <tr>
      <td>'.$i++.'</td>
       <td>'.$row->trans_id.'</td>
       <td>'.$row->operator_id.'</td>
       <td>'.$row->operator.'</td>
       <td>'.$row->api_name.'</td>
       <td>'.$row->mobile_no.'</td>
        <td>'.$row->service.'</td>
         <td>'.$row->closing.'</td>
         <td>'.$row->created_at.'</td>
         <td>'.$row->mode.'</td>
         <td>'.$row->success_status.''.$row->failed_status.'</td>
      </tr>
    ';
   }
  }
  else
  {
   $output .= '<tr>
       <td colspan="7" style="text-align:center">No Data Found</td>
      </tr>';
  }
  $output .= '</table>';
  echo $output;
 }
}


?>