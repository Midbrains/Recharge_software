<?php
class Category_m extends CI_Model 
{

  function all_category($id)
  {
   $this->db->where('parent_id', $id);
   $query = $this->db->get('category');
   return $query->result();
   }
}
?>