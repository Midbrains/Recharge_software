<?php
class user_login extends CI_Model
{
 function can_login($email, $password)
 {
    $this->db->where('email', $email);
    $query = $this->db->get('admin');
    if($query->num_rows() > 0)
    {
      foreach($query->result() as $row)
      {
        $store_password = $row->password;
        //$user_password = md5($password);
        if($password == $store_password)
        {
          $this->session->set_userdata('login_id', $row->id);
          $this->session->set_userdata('login_name', $row->name);
        }
        else
        {
          return 'Your Password is Wrong.';
        }
      }
    }
    else
    {
    return 'Your email is not exits.';
    }
  }






     function user_login_model($email, $password)
 {
    $this->db->where('email', $email);
    $query = $this->db->get('user');
    if($query->num_rows() > 0)
    {
      foreach($query->result() as $row)
      {
        $store_password = $row->password;
        //$user_password = md5($password);
        if($password == $store_password)
        {
          $this->session->set_userdata('login_id', $row->id);
          $this->session->set_userdata('login_name', $row->name);
        }
        else
        {
          return 'Your Password is Wrong.';
        }
      }
    }
    else
    {
    return 'Your email is not exits.';
    }
  }

    public function oprator_gets()
    {
        $q  = $this->db->get('operator');
        return $q->result();
    }
    

    public function get_package()
    {
        $q = $this->db->get('recharge_package');
        return $q->result();
    }
    public function report_recharge()
    {
        $q = $this->db->get('recharge');
        return $q->result();
    }

    public function insert_operator($member_name, $operator_name)
    {
      $data = array();
      $data['member_name'] = $member_name;
      $data['operator_name'] = $operator_name;
      $data['status'] = "Active";
      $id =  $this->db->insert('stop_operator',$data);
      if($id)
      {
        $this->session->set_flashdata('success_message','Your Data is Inserted into database !');

        return redirect('user/stop_operator');
      }
    }

    public function delete_operator($operator_id)
    {
      $data = array();
      $data['id']=$operator_id;
      $id = $this->db->where('id',$operator_id)
      ->delete('stop_operator',$data);
      if($id)
      {
        $this->session->set_flashdata('success_message','Your Record Deleted Successfully !');
        return redirect('user/stop_operator');
      }
    }

    
    function fetch_data($query)
 {
  $this->db->select("*");
  $this->db->from("ladger");
  if($query != '')
  {
   $this->db->like('transaction_id', $query);
   $this->db->or_like('datetime', $query);
  }
  $this->db->order_by('id', 'DESC');
  return $this->db->get();
 }
    
    
    
    
    function recharge_fetch_data($query)
 {
  $this->db->select("*");
  $this->db->from("recharge");
  if($query != '')
  {
   $this->db->like('trans_id', $query);
   $this->db->or_like('date', $query);
  }
  $this->db->order_by('id', 'DESC');
  return $this->db->get();
 }
    
  
}

?>
