<?php
class Dashboard_m extends CI_Model
{
//  function get_question($pageno)
//  {
//     $this->db->where('pageno', $pageno);
//     $query = $this->db->get('questions');
//     $data = $query->result();
//     //echo "<pre>";print_r($data);die;
//     $newarray = array();
//     if(!empty($data)){
//       foreach($data as $row){        
//         $row->option = $this->get_option($row->id); 
//         array_push($newarray,$row);
//       }
//     }  
//       return $newarray;
//   }

//   function get_questionAnswer($pageno)
//   {
//    $this->db->where('pageno', $pageno);
//    $query = $this->db->get('questions');
//    $data = $query->result();
//    $newarray = array();
//    if(!empty($data)){
//      foreach($data as $row){        
//        $row->option = $this->get_option($row->id); 
//        $row->answer = $this->get_answer($row->id); 
//        array_push($newarray,$row);
//      }
//    }  
//      return $newarray;
//    } 

//   function get_option($qid)
//   {
//    $this->db->where('ref_question_id', $qid);
//    $query = $this->db->get('options');
//    return $query->result();
//    }

//    function get_answer($qid)
//    {
//     $this->db->where('ref_question_id', $qid);
//     $query = $this->db->get('options');
//     return $query->result();
//     }
}

?>