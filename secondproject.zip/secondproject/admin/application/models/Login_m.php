<?php
class Login_m extends CI_Model
{
 function can_login($email, $password)
 {
    $this->db->where('email', $email);
    $query = $this->db->get('admin');
    if($query->num_rows() > 0)
    {
      foreach($query->result() as $row)
      {
        $store_password = $row->password;
        //$user_password = md5($password);
        if($password == $store_password)
        {
          $this->session->set_userdata('login_id', $row->id);
          $this->session->set_userdata('login_name', $row->name);
        }
        else
        {
          return 'Your Password is Wrong.';
        }
      }
    }
    else
    {
    return 'Your email is not exits.';
    }
  }



function user_can_login($user_type, $email, $password)
 {
    $this->db->where('username', $email);
    $query = $this->db->get('user');
    if($query->num_rows() > 0)
    {
      foreach($query->result() as $row)
      {
        $store_password = $row->password;
          $user_type1 = $row->user_type;
//        $user_password = md5($password);
        if(md5($password) == $store_password and $user_type == $user_type1)
        {
          $this->session->set_userdata('login_id', $row->id);
          $this->session->set_userdata('login_name', $row->username);
        }
        else 
        {
          return 'Your Password and User Type is Wrong.';
        }
      }
    }
    else
    {
    return 'Your email is not exits.';
    }
  }
}

?>