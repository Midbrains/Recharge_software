<?php
class user_login extends CI_Model
{
 function can_login($email, $password)
 {
    $this->db->where('email', $email);
    $query = $this->db->get('admin');
    if($query->num_rows() > 0)
    {
      foreach($query->result() as $row)
      {
        $store_password = $row->password;
        //$user_password = md5($password);
        if($password == $store_password)
        {
          $this->session->set_userdata('login_id', $row->id);
          $this->session->set_userdata('login_name', $row->name);
        }
        else
        {
          return 'Your Password is Wrong.';
        }
      }
    }
    else
    {
    return 'Your email is not exits.';
    }
  }






     function user_login_model($email, $password)
 {
    $this->db->where('email', $email);
    $query = $this->db->get('user');
    if($query->num_rows() > 0)
    {
      foreach($query->result() as $row)
      {
        $store_password = $row->password;
        //$user_password = md5($password);
        if($password == $store_password)
        {
          $this->session->set_userdata('login_id', $row->id);
          $this->session->set_userdata('login_name', $row->name);
        }
        else
        {
          return 'Your Password is Wrong.';
        }
      }
    }
    else
    {
    return 'Your email is not exits.';
    }
  }

    public function oprator_gets()
    {
        $q  = $this->db->get('operator');
        return $q->result();
    }


    public function get_package()
    {
        $q = $this->db->get('recharge_package');
        return $q->result();
    }
    public function report_recharge()
    {
        $q = $this->db->get('recharge');
        return $q->result();
    }



    public function delete_operator($operator_id)
    {
      $data = array();
      $data['id']=$operator_id;
      $id = $this->db->where('id',$operator_id)
      ->delete('stop_operator',$data);
      if($id)
      {
        $this->session->set_flashdata('success_message','Your Record Deleted Successfully !');
        return redirect('user/stop_operator');
      }
    }

  public  function fetch_state($country_id)
   {
    $this->db->where('bank_name', $country_id);
    $query = $this->db->get('add_bank');
      $output = "<label>Account No.</label>";
    foreach($query->result() as $row)
    {
     $output .= '<input type="text" value="'.$row->account_number.'" class="form-control">';
    }
    return $output;
   }


}

?>
