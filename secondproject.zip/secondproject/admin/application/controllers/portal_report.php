<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class portal_report extends CI_Controller {

    public function user_list()
    {
        $this->load->view('header');
        $data['user'] = $this->db->where('user_type','user_api')
            ->get('user')->result();
        $this->load->view('user/user_list.php',$data);
        $this->load->view('footer');
    }
    public function super()
    {
        $this->load->view('header');
        $data['user'] = $this->db->where('user_type','super')
            ->get('user')->result();
        $this->load->view('user/super',$data);
        $this->load->view('footer');
    }
    
     public function master()
    {
        $this->load->view('header');
        $data['user'] = $this->db->where('user_type','master')
            ->get('user')->result();
        $this->load->view('user/master',$data);
        $this->load->view('footer');
    }

       public function retailer()
    {
        $this->load->view('header');
        $data['user'] = $this->db->where('user_type','retailer')
            ->get('user')->result();
        $this->load->view('user/retailer',$data);
        $this->load->view('footer');
    }
    
       public function distributor()
    {
        $this->load->view('header');
        $data['user'] = $this->db->where('user_type','distributor')
            ->get('user')->result();
        $this->load->view('user/distributor',$data);
        $this->load->view('footer');
    }
    
    public function book_day()
    {
         date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d');
        $this->load->view('header');
        $data['user']= $this->db->where('date',$date)
            
            ->get('recharge')->result();
         $data['data']= $this->db->where('date',$date)
             ->select('SUM(total_hits) as t_hits')
             ->select('SUM(success_hits) as s_hits') 
             ->select('SUM(success_amount) as s_amount') 
             ->select('SUM(failed_amount) as failed_a')
             ->select('SUM(failed_hits) as failed_hit')
             
             ->select('SUM(commision) as commision')
             
           ->get('recharge')->result();
        
        
        $this->load->view('user/day_book',$data);
        $this->load->view('footer');
    }  
    
    public function final_limit()
    {
        $this->load->view('header');
     $data['mark']=$this->db->where('user_role','distributor')->select_sum('service')->get('recharge')->result();
        
        $data['mark2']=$this->db->where('user_role','super')->select_sum('service')->get('recharge')->result();
        $data['mark3']=$this->db->where('user_role','master')->select_sum('service')->get('recharge')->result();
        $data['mark4']=$this->db->where('user_role','Retailer')->select_sum('service')->get('recharge')->result();

        $this->load->view('user/final_limit',$data);
        $this->load->view('footer');
    }
    
    public function all_transfer()
    {
        $this->load->view('header');
        $data['api']=$this->db->get('recharge_api')->result();
        $data['req_bal'] = $this->db->get('request_balance')->result();
        
        $this->load->view('user/all_transfer',$data);
        $this->load->view('footer');
    }
    
    
    
}
