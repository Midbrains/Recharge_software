<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('login_id'))
		{
			redirect('Login');
        }
        //$this->load->model('Category_m');
    }

	public function index()
	{
        $data['user'] = $this->db->get(' recharge_api')->result();
        $this->load->view('header');
        $this->load->view('user/user',$data);
        $this->load->view('footer');
    }


    public function shopkeeper()
	{

        $data['user'] = $this->db->get('api_setting')->result();
        $data['api'] = $this->db->get(' recharge_api')->result();

        $this->load->view('header');
        $this->load->view('user/shopkeeper',$data);
        $this->load->view('footer');
    }
       public function insert_api_setting()
    {
        $data = array();
        if(isset($_POST['add']))
        {
            $data['api_name'] = $_POST['api_name'];
            $data['username'] = $_POST['username'];
            $data['password'] = $_POST['password'];
            $data['json_data'] = json_encode($data);
            $this->session->set_flashdata('success_message', "Api Inserted Successfully !");
            $this->db->insert('api_setting', $data);
        }
        redirect('user/shopkeeper');
    }

    public function edit_api($api_id)
    {
        $data = array();
        if(isset($_POST['update_api'])){
            $data['api_name'] = $_POST['api_name'];
            $data['username'] = $_POST['username'];
            $data['password'] = $_POST['password'];

            $this->session->set_flashdata('success_message', 'Update Api Setting !');

            $this->db->where('api_id', $api_id);
                $this->db->update('api_setting',$data);
        }
        redirect('user/shopkeeper');
    }
    public function transfer()
    {
        $this->load->view('header');
        $data['user'] = $this->db->get('operator')->result();
           $data['users'] = $this->db->get(' recharge_api')->result();
         $data['pack'] = $this->db
             ->get('recharge_package')
             ->result();
        $this->load->view('user/transfer_api',$data);
        $this->load->view('footer');
    }
    public function operator()
    {
        $this->load->view('header');
        $data['user']= $this->db->get('recharge_service')->result();
        $data['oprtr']= $this->db->get('operator')->result();
        $this->load->view('user/operator-setting',$data);
        $this->load->view('footer');
    }

    public function operator_insert()
    {
        $data = array();
        if(isset($_POST['update']))
        {
            $data['operator_name'] = $_POST['oprtr_name'];
            $data['api_name'] = $_POST['api_name'];
            $data['operator_code'] = $_POST['oprtr_code'];
            $data['service_name']= $_POST['service_name'];
            $data['status'] = "Active";
            $this->session->set_flashdata('success_message','Operator Inserted Successfully !');
            $this->db->insert('operator',$data);

        }
        redirect('user/operator');

    }
     public function status_operator_update($id)
    {
        $data = array();
        if(isset($_POST['active_button'])){
        $data['status'] = $_POST['active_status'];
         $this->session->set_flashdata('success_message','Status Updated !');
         $this->db->where('id',$id)
             ->update('operator', $data);

    }redirect('user/operator');
     }
    public function update_operator($id)
    {
        $data = array();
     if(isset($_POST['update_operator']))
     {
         $data['operator_name'] = $_POST['operator_name'];
         $data['api_name'] = $_POST['api_name'];
         $data['operator_code'] = $_POST['operator_code'];
         $data['service_name'] = $_POST['service_name'];

         $this->session->set_flashdata('success_message', 'Update Operator !');

         $this->db->where('id',$id)
             ->update('operator', $data);
     }
        redirect('user/operator');
    }

    public function package_recharge()
    {
        $this->load->view('header');
         $data['user'] = $this->db->get('recharge_package')->result();
        $this->load->view('user/package_setting', $data);
        $this->load->view('footer');
    }
    public function insert_package()
    {
        $data = array();
        if(isset($_POST['add']))
        {
            $data['package_name'] =$_POST['pack_name'];
            $data['package_description'] = $_POST['package_desc'];
            $data['package_amount'] = $_POST['package_amount'];
            $data['package_status'] = $_POST['status']; $data['package_commision_type'] = $_POST['package_commision'];
            $this->session->set_flashdata('success_message','Package Inserted Successfully !');
            $this->db->insert('recharge_package',$data);


        }
        redirect('user/package_recharge');
    }

    public function update_package($package_id)
    {
        $data = array();
        if(isset($_POST['update']))
        {
            $data['package_name'] = $_POST['package_name'];
            $data['package_description'] = $_POST['package_desc'];
            $data['package_commision_type'] = $_POST['package_commision'];
            $data['package_amount'] = $_POST['package_amount'];

            $this->session->set_flashdata('success_message','Updated Packages !');
            $this->db->where('package_id',$package_id)
                ->update('recharge_package',$data);
        }
        redirect('user/package_recharge');
    }

    public function package_status($package_id)
    {
        $data = array();
        $active = array(); if(isset($_POST['package_active'])){
            $data['package_status']= $_POST['status1'];
            $active['package_status']= $_POST['Deactive'];
            $this->session->set_flashdata('success_message', "Your Status Change Successfull!");
            $this->db->update('recharge_package', $active);
            $this->db->where('package_id', $package_id);
            $this->db->update('recharge_package', $data);
        }
       redirect('user/package_recharge');
    }
    public function edit_operator($id)
    {
        $data = array();
        if(isset($_POST['update_row_operator']))
        {
            $data['amount_not_allowed']= $_POST['amount_not_allowed'];

            $this->session->set_flashdata('success_message', 'Your amount Updated !');
            $this->db->where('id',$id)
                ->update('operator', $data);
        }
        redirect('user/operator_recharge_amount');
    }

    public function edit_user($id)
    {
        $data = array();
        if(isset($_POST['update'])){
        $data['api_name'] = $_POST['name']; $data['api_url'] = $_POST['api_url'];
       $this->session->set_flashdata('success_message',"Sms Api update successfully.");

            $this->db->where('id', $id);
            $this->db->update(' recharge_api', $data);
    }
         redirect('user');
    }

   

      public function response_status($id)
    {
        $data = array();
       
        if(isset($_POST['response_button'])){
//            $data['response_log']= $_POST['response1'];
//            $active['response_log']= $_POST['rsponse2'];
            $this->session->set_flashdata('success_message', "Delete Successfull!");
//            $this->db->where('id',$id);
      
            $this->db->where('id', $id);
            $this->db->delete(' recharge_api');
        }
       redirect('user');
    }

      public function response_package_log($package_id)
    {
        $data = array();
        $active = array();
        if(isset($_POST['package_active'])){
              $active['response_log']= $_POST['response11'];
            $data['response_log']= $_POST['response12'];

            $this->session->set_flashdata('success_message', "Your Status Change Successfull!");
//            $this->db->where('package_id',$package_id);
            $this->db->update('recharge_package', $active);
            $this->db->where('package_id', $package_id);
            $this->db->update('recharge_package', $data);
        }
       redirect('user/package_recharge');
    }


    public function insert_api()
    {
        $data = array();
        if(isset($_POST['add']))
        {
$data['api_name'] = $_POST['api_name'];
$data['api_url'] = $_POST['api_url'];
$data['status'] = $_POST['status'];
$data['response_log'] = $_POST['response_log'];
$this->session->set_flashdata('success_message', "Location Insert Successfully");
$this->db->insert(' recharge_api', $data);

        }
        redirect('user');
    }

    public function operator_code(){
        $this->load->view('header');

        $data['user'] = $this->db->get('operator')->result();

        $data['api'] = $this->db->get(' recharge_api')->result();

        $data['service'] = $this->db->get('recharge_service')->result();
        $this->load->view('user/operator_code',$data);
         $this->load->view('footer');
    }

    public function operator_code_update($id)
    {
        $data = array();
        if(isset($_POST['operator_button']))
        {
            $data['operator_code'] = $_POST['operator_code'];

            $this->session->set_flashdata('success_message','Update Operator Code !');

            $this->db->where('id',$id)
                ->update('operator',$data);
        }
        redirect('user/operator_code');
    }

    public function flat_commision()
    {
        $this->load->view('header');

        $data['user'] = $this->db->where('commision_role',  'White Label')
            ->get('white_label')->result();
        $data['master'] = $this->db->where('commision_role',  'Master Dealer')
            ->get('white_label')->result();
        $data['distributor'] = $this->db->where('commision_role',  'Distributor')
            ->get('white_label')->result();
        $data['retailer'] = $this->db->where('commision_role',  'Retailer')
            ->get('white_label')->result();
        $this->load->view('user/flat_commision',$data);
            $this->load->view('footer');
    }

    public function White_label()
    {
        $data = array();
        if(isset($_POST['white_button']))
        {
            $data['from1'] = $_POST['white_form1'];
            $data['to1'] = $_POST['white_form2'];
            $data['provide1'] = $_POST['white_form3'];
            $data['from2'] = $_POST['white_form4'];
            $data['to2'] = $_POST['white_form5'];
            $data['provide2'] = $_POST['white_form6'];
            $data['from3'] = $_POST['white_form7'];
            $data['to3'] = $_POST['white_form8'];
            $data['provide3'] = $_POST['white_form9'];
            $data['from4'] = $_POST['white_form10'];
            $data['to4'] = $_POST['white_form11'];
            $data['provide4']=$_POST['white_form12'];
            $data['to5'] = $_POST['white_form13'];
            $data['from5']=$_POST['white_form14'];
            $data['provide5']=$_POST['white_form15'];
            $data['to6']=$_POST['white_form16'];
            $data['from6']=$_POST['white_form17'];
            $data['provide6']=$_POST['white_form18'];
            $data['commision_role']=$_POST['commision_role'];

            if(empty($data['commision_role']=$_POST['commision_role'])){
                   $this->session->set_flashdata('success_message','Flat Commision Is Inserted Successfully !');
       $this->db->insert('white_label',$data);
            }else{
                   $this->session->set_flashdata('success_message','Flat Commision Is Updated Successfully !');
   $this->db->where('commision_role',$data['commision_role']=$_POST['commision_role']);
                $this->db->update('white_label',$data);
            }
        }
        redirect('user/flat_commision');
    }
     public function operator_commision()
     {
         $this->load->view('header');
         $data['user'] = $this->db->get('operator')->result();
         $this->load->view('user/operator_commision',$data);
         $this->load->view('footer');
     }

    public function commision_update($id){

        $data = array();
        if(isset($_POST['update'])){

            $data['api_commision'] = $_POST['api_commision'];
            $data['sd_commision'] = $_POST['sd_commision'];
            $data['md_commision']=$_POST['md_commision'];
            $data['dis_commision'] = $_POST['dis_commision'];
            $data['rt_commision'] = $_POST['rt_commision'];
            $data['commision_type']=$_POST['commision_type'];


            $query = $this->db->where('id',$id)
                ->update('operator',$data);
          $this->session->set_flashdata('success_message',' Commision Operetor Is Updated !');
        }
        redirect('user/operator_commision');

    }

    public function amount_api()
    {
        $this->load->view('header');
        $data['user'] = $this->db->get('amount_api')->result();
         $data['api'] = $this->db->get(' recharge_api')->result();
          $data['opt'] = $this->db->get('operator')->result();
        $this->load->view('user/amount_api' ,$data);
        $this->load->view('footer');
    }

    public function insert_amount_api()
    {
        $data = array();
        if(isset($_POST['add_amount_api']))
        {
            $data['api_name'] = $_POST['api_name'];
            $data['operator_name'] = $_POST['operator_name'];
            $data['amount'] = $_POST['amount'];
            date_default_timezone_set('Asia/Calcutta');

            $data['add_date'] =  date("Y-m-d");
            $data['status'] = "Active";
            $this->session->set_flashdata('success Message', 'Your Record Is Inserted Successfully !');

            $query = $this->db->insert('amount_api',$data);
        }
       redirect('user/amount_api');
    }

    public function delete_amount_api($id)
    {
       $data = array();
        if(isset($_POST['delete_button']))
        {
            $data['id'] = $_POST['delete'];
            $this->session->set_flashdata('success_message','Deleted Record Successfully !');

            $this->db->where('id',$id);
                $this->db->delete('amount_api',$data);
        }
        redirect('user/amount_api');
    }
    public function delete_api($api_id)
    {
       $data = array();
        if(isset($_POST['delete']))
        {
            $data['api_id'] = $_POST['api_id'];
            $this->session->set_flashdata('success_message','Deleted Record Successfully !');

            $this->db->where('api_id',$api_id);
                $this->db->delete('api_setting',$data);
        }
        redirect('user/shopkeeper');
    }
    public function payment(){

        $this->load->view('header');
        $data['user'] = $this->db->where('payment_status','Active')->get('payment_gateway',0,1)->result();

        $this->load->view('user/payment_geteway', $data);

        $this->load->view('footer');
    }

    public function update_payment_gateway()
    {
        $data = array();
        if(isset($_POST['payment_charge']))
        {
            $data['payment_charge'] = $_POST['payment_charges'];
            $data['charge_type']=$_POST['charges_type'];

             if(empty($data['payment_status']=$_POST['payment_status'])){
                   $this->session->set_flashdata('success_message','Payment Charge Is Inserted Successfully !');
       $this->db->insert('payment_gateway',$data);
            }else{
                   $this->session->set_flashdata('success_message','Payment Charge Is Updated Successfully !');
   $this->db->where('payment_status',$data['payment_status']=$_POST['payment_status']);
                $this->db->update('payment_gateway',$data);
            }
        }
        redirect('user/payment');
    }

    public function admin_transfer()
    {
        $this->load->view('header');
          $data['api']=$this->db->get('recharge_api')->result();
        $data['req_bal'] = $this->db->where('user_type','Admin')->get('request_balance')->result();
        
        $this->load->view('user/admin_transfer',$data);
        $this->load->view('footer');
    }
    public function all_flat_commision()
    {
        $this->load->view('header');
        $this->load->view('user/all_flat_commision');
        $this->load->view('footer');
    }

    public function registration_charge()

    {
        $this->load->view('header');
        $this->load->view('user/registration_charge');
        $this->load->view('footer');

    }

    public function api_recharge_amount()

    {
        $this->load->view('header');
        $this->load->view('user/api_recharge_amount');
        $this->load->view('footer');

    }

    public function operator_recharge_amount()
    {
        $this->load->view('header');
        $data['user']=$this->db->get('operator')->result();

        $this->load->view('user/operator_recharge_amount',$data);
        $this->load->view('footer');
    }

    public function stop_operator()
    {
        $this->load->view('header');
        $data['user'] = $this->db->get('stop_operator')->result();
        $data['dist'] = $this->db->where('user_type', 'distributor')
            ->get('user')->result();
        $data['opt'] = $this->db->get('operator')->result();

        $this->load->view('user/stop_operator',$data);
        $this->load->view('footer');

    }

    public function insert_operator()
    {

            $data = array();
            if(isset($_POST['add']))
            {
                $data['member_name'] = $_POST['distributor'];
                $data['operator_name']=$_POST['operator'];
                $data['status'] = "Active";
                $this->session->set_flashdata('success_message','Insert Your Records !');

                $this->db->insert('stop_operator',$data);

            }
        redirect('user/stop_operator');

    }


    public function delete_operator()
    {
      $operator_id = $this->input->post('delete');
      $this->load->model('user_login');
      $q = $this->user_login->delete_operator($operator_id);


    }
    public function set_member_limit()
    {
      $this->load->view('header');
         $data['users'] = $this->db->get('rech_member_reg')->result();
      $this->load->view('user/set_member_limit',$data);
      $this->load->view('footer');
    }

    public function recharge_amount_limit()
    {
      $this->load->view('header');
        $data['users'] = $this->db->get('rech_member_reg')->result();
      $this->load->view('user/recharge_amount_limit',$data);
      $this->load->view('footer');
    }

    public function transfer_api()
    {
        $data = array();
        $api = array();
        if(isset($_POST['update'])){
            $data['user_id'] = $_SESSION['login_id'];
        $data['operator_code'] = $_POST['operator'];

        $data['api_name'] = $_POST['Api'];

        $data['package_name'] = $_POST['package'];

          $data['transfer_role'] = "Admin";
            
            $data['status'] = "Active";
            
            $api['status'] = "Deactive";

            
        $this->session->set_flashdata('success_message','Your API transfer Successfully !');

 $this->db->where('status','active');

$this->db->update(' recharge_api',$api);

$this->db->where('api_name',$_POST['Api'],'status','Deactive');

$this->db->update(' recharge_api',$data);

    }
        redirect('user/transfer');
    }


    /* Member Registration start Here */

    public function member_registration()
    {

       $this->load->view('header');
        $data['user'] = $this->db->get('rech_member_reg')->result();
      $this->load->view('member_reg/member_reg',$data);
      $this->load->view('footer');


    }

    public function insert_member_registration()
    {
         $adhar_img = $_FILES['aadhar_pan_img']['name'];
        if($adhar_img != ''){
        $addhar = @end(explode('.',$adhar_img));
            $addhartest = strtolower($addhar);
               $new_images = time().'.'.$addhartest;
        $member_img ='uplaods/'.$new_images;

             move_uploaded_file($_FILES['aadhar_pan_img']['tmp_name'],$member_img);

        }

           $data = array();
        $data['service_type'] = trim($_POST['service_type']);
        $data['name'] = trim($_POST['name']);
        $data['username'] = trim($_POST['username']);
        $data['mobile_no'] = trim($_POST['mobile']);
        $data['parent_user'] = trim($_POST['p_user']);
        $data['commision_type']=trim($_POST['commision']);
        $data['commision_package']=trim($_POST['commision_packge']);
        $data['email']=trim($_POST['email']);
        $data['company_name'] = trim($_POST['c_name']);
        $data['pin'] = trim($_POST['pin']);
        $data['aadhar_pan_no']=trim($_POST['addhar_pan']);
        date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
$date = date('Y-m-d');
        $data['reg_date'] = $date;

        $data['member_id'] = mt_rand(100000,999999);

       $data['aadhar_pan_img']=$new_images;


        $this->session->set_flashdata('success_message','Your Record Save Success !');

        $this->db->insert('rech_member_reg',$data);

         redirect('user/member_registration');
    }





    public function delete_member($id)
    {
        if(isset($_POST['delete'])){
$q = $this->db->where('id',$id)->delete('rech_member_reg');

if($q)
{
     $this->session->set_flashdata('success_message','Deleted Successfully !');
}
            else{
                echo "Failed";
            }
    }
        redirect('user/member_registration');
    }

    public function member_edit($id)
    {
        $data = array();
        if(isset($_POST['update_member']))
        {
            $data['service_type'] = $_POST['service_type'];
            $data['name'] = $_POST['name'];
            $data['username'] = $_POST['username'];
            $data['mobile_no'] = $_POST['mobile'];
            $data['parent_user'] = $_POST['p_user'];
            $data['commision_type'] = $_POST['commision'];
            $data['commision_packge'] = $_POST['commision_packge'];
            $data['email'] = $_POST['email'];

            $data['company_name'] = $_POST['c_name'];

            $data['pin'] = $_POST['pin'];

            $data['aadhar_pan_no'] = $_POST['addhar_pan'];

            $upd = $this->db->where('id',$id)->update('rech_member_reg',$data);

            if($upd)
            {
                $this->session->set_flashdata('success_message','Update Your Member Records!');
            }
        }
        redirect('user/member_registration');
    }
    /* End Member Registration Here   */

    public function add_bank()
    {
        $this->load->view('header');
        $data['bank'] =$this->db->get('add_bank')->result();
        $this->load->view('balence/add_bank',$data);
        $this->load->view('footer');
    }
    public function add_bank_name()
    {
        $data = array();
        if(isset($_POST['add_bank']))
        {
            $data['bank_name'] = $_POST['bank_name'];
            $data['account_number'] = $_POST['account_no'];
            $data['ifsc_code'] = $_POST['ifsc'];
            $data['branch_name'] = $_POST['branch_name'];
            $data['holder_name'] = $_POST['holder_name'];



            $q = $this->db->insert('add_bank',$data);
            if($q)
            {
               $this->session->set_flashdata('success_message','Record Added !');
            }

        }
        redirect('user/add_bank');
    }
    public function bank_edit($id)
    {
        $data = array();
        if(isset($_POST['bank_edit']))
        {
            $data['bank_name'] = $_POST['bank_name'];
            $data['account_number'] = $_POST['account_number'];

            $q = $this->db->where('id',$id);
                $this->db->update('add_bank',$data);

                $this->session->set_flashdata('success_message','Update bank Name');

        }
        redirect('user/add_bank');
    }

    public function del($id)
    {
        $data = array();
        if(isset($_POST['del']))
        {

            $q = $this->db->where('id',$id);
                $this->db->delete('add_bank',$data);

                $this->session->set_flashdata('success_message','Delete bank Name');

        }
        redirect('user/add_bank');
    }

    public function request_balance()
    {
      $data = array();
        if(isset($_POST['payment_req']))
        {
            $data['bank_name'] = $_POST['bank_name'];
            $data['deposit_account']=$_POST['d_account'];

            $data['payment_mode'] = $_POST['pay_mode'];

            $data['transaction_id'] = $_POST['trans_id'];

//            $data['holder_name'] = $_POST['holder_name'];
//
//            $data['mobile_no'] = $_POST['mobile_no'];
//
//            $data['cheque'] = $_POST['cheque'];
//
//            $data['card_number'] = $_POST['card_number'];

            $data['req_amount']= $_POST['req_amount'];

      date_default_timezone_set('Asia/Calcutta');
   $data['req_date'] = date("Y-m-d");
            $data['user_name'] = $_POST['admin'];
          $data['status'] = "Pending";
          $data['user_type'] = "Admin";

            $q = $this->db->insert('request_balance',$data);

            if($q)
            {
               $this->session->set_flashdata('success_message','Request Sent Successfull !');
            }
            redirect('user/balance');
        }

    }
     public function delete_request_bal($id)
     {
         if(isset($_POST['del_bank'])){
         $this->db->where('id',$id)->delete('request_balance');
         $this->session->set_flashdata('success_message','Delete Bank Account !');
     }
         redirect('user/balance');
     }


 public function get_data()
 {
      $value = $this->input->post("value");
      $data = $this->user_login->get_data($value);
      $option ="";
      foreach($data as $d)
      {

         $option .= "<input type='text' value='".$d->account_number."'>";
      }
       echo $option;
 }

    public function recharge_report()
    {
        $this->load->view('header');
          $data['user'] = $this->db->get('recharge')->result();
        
        $this->load->view('recharge_report/recharge_report',$data);
        $this->load->view('footer');
    }


    public function balance()
    {
        $session = $_SESSION['login_id'];
        $this->load->view('header');
        $data['bal'] = $this->db->get('request_balance')->result();
        $data['bank'] = $this->db->get('add_bank')->result();
        $data['admin'] = $this->db->where('id',$session)->get('admin')->result();
        $this->load->view('balence/balance_transfer',$data);
        $this->load->view('footer');
    }

     function fetch_state()
     {
      if($this->input->post('country_id'))
      {
       echo $this->user_login->fetch_state($this->input->post('country_id'));
      }
     }



    public function delete_recharge_report($id)
    {
        $data = array();
        if(isset($_POST['delete']))
        {

           $del = $this->db->where('id',$id)->delete('recharge');
            if($del)
            {
            $this->session->set_flashdata('success_message','Delete Recharge Data!');
            }

        }
        redirect('user/recharge_report');
    }
     
    public function update_member_limit()
    {
        $data = array();
        if(isset($_POST['update_limit']))
        {
            $data['id'] = $_POST['id'];
            $data['balance_limit'] = $_POST['balance_limit'];
  
            $this->db->where('id',$_POST['id'])->
               update('rech_member_reg',$data);
             $this->session->set_flashdata('success_message','Update successfull !');
        }
       redirect('user/set_member_limit');
    }
    
    public function update_recharge_limit()
    {
        $data = array();
        if(isset($_POST['update_recharge']))
        {
            $data['id'] = $_POST['id'];
            $data['recharge_limit'] = $_POST['recharge_limit'];
  
            $this->db->where('id',$_POST['id'])->
               update('rech_member_reg',$data);
             $this->session->set_flashdata('success_message','Update successfull !');
        }
       redirect('user/recharge_amount_limit');
    }
   
    public function complain()
    {
        $this->load->view('header');
       $data['users'] = $this->db->get('user')->result();
        
        $data['comp'] = $this->db->get('complain')->result();
        $this->load->view('complain/complain',$data);
        $this->load->view('footer');
    }
    
    public function complains()
    {
        $data = array();
        if(isset($_POST['add_complain']))
        {
            $data['username'] = $_POST['user_name'];
            
            $data['complain'] = $_POST['complain'];
            
            $data['status'] = 'Send';
            
            $this->db->insert('complain',$data);
            
            $this->session->set_flashdata('success_message','Send Complain Successsfully !');
            redirect('user/complain');
        }
    }
    
    public function delete_complain($id)
    {
        $data = array();
        
        if(isset($_POST['active']))
        {
            $data['id'] = $_POST['delete'];
            
            $q = $this->db->where('id',$id)->
                delete('complain');
            
            if($q){
                $this->session->set_flashdata('success_message','Delete Successfully !');
                
                redirect('user/complain');
            }
        }
    }
    
    
    public function balance_request_status($id)
    {
        $data =  array();
        if(isset($_POST['change_status']))
        {
            $data['status'] = $_POST['request_status'];
            
            $this->db->where('id',$id)->update('request_balance',$data);
        }
        $this->session->set_flashdata('success_message','Update Successfully !');
        redirect('user/balance');
    }
    
     
    public function costomer_details()
    {
        $this->load->view('header');
        $data['cost'] = $this->db->get('costomer')->result();
        $this->load->view('user/costomer-details',$data);
        $this->load->view('footer');
    }
    
    
    public function add_costomer()
    {
       $data = array(); if(isset($_POST['add_costomer'])){
            $data['costomer_name'] = $_POST['costomer'];
           $data['costomer_number'] = $_POST['costomer_number'];
           
           $q = $this->db->insert('costomer',$data);
           
           if($q)
           {
               $this->session->set_flashdata('success_message','Add Successfully Record');
               redirect('user/costomer_details');
           }
               
        }
    }
    
       
    public function delete_costomer_details($id)
    {
    $data = array();
     if(isset($_POST['del'])){
       $q =  $this->db->where('id',$id)->delete('company_toll_free');
       
         if($q)
         {
             $this->session->set_flashdata('success_message','Deleted Successfully !');
             
             redirect('user/costomer_care');
         }
     }
    }
    
    
    public function costomer_care()
    {
        $this->load->view('header');
        $data['operator'] = $this->db->get('company_toll_free')->result();
        $this->load->view('user/costomer-care',$data);
        $this->load->view('footer');
        
    }
    
     public function add_company_toll()
    {
       $data = array(); if(isset($_POST['add_company_toll'])){
            $data['company_operator_name'] = $_POST['operator_name'];
           $data['company_operator_number'] = $_POST['operator_toll_free'];
           
           $q = $this->db->insert('company_toll_free',$data);
           
           if($q)
           {
               $this->session->set_flashdata('success_message','Add Successfully Record');
               redirect('user/costomer_care');
           }
               
        }
    }
    
    public function delete_costomer($id)
    {
        $data = array();
        if(isset($_POST['del']))
        {
            $q = $this->db->where('id', $id)->delete('costomer');
            
            if($q)
            {
                $this->session->set_flashdata('success_message','Delete Successfully !');
                
                redirect('user/costomer_details');
            }
        }
    }

    }
