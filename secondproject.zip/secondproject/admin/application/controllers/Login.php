<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_m');
	}

	function index()
	{
        if($this->session->userdata('login_id'))
		{
			redirect('Dashboard');
        }
		$this->load->view('login');
	}

	function validation()
	{
        $result = $this->Login_m->can_login($this->input->post('email'), $this->input->post('password'));
        if($result == '')
        {
            redirect('Dashboard');
        }
        else
        {
            $this->session->set_flashdata('message',$result);
            redirect('Login');
        }
    }

	function user_login_dashboard()
	{
        $result = $this->Login_m->user_can_login($this->input->post('user_type'), $this->input->post('email'), $this->input->post('password'));
        if($result == '')
        {
            redirect('user_api/index1');
        }
        else
        {
            $this->session->set_flashdata('message',$result);
            redirect('user_api/user_login');
        }
    }

	function logout()
	{
	  $data = $this->session->all_userdata();
	  foreach($data as $row => $rows_value)
	  {
	   $this->session->unset_userdata($row);
	  }
	  redirect('Login');
	}
    
    
    function user_logout()
	{
	  $data = $this->session->all_userdata();
	  foreach($data as $row => $rows_value)
	  {
	   $this->session->unset_userdata($row);
	  }
	  redirect('user_api/user_login');
	}
}
?>
