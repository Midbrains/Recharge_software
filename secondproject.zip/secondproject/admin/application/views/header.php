<!DOCTYPE html>
<html lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Bigdeal admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
<meta name="keywords" content="admin template, Bigdeal admin template, dashboard template, flat admin template, responsive admin template, web app">
<meta name="author" content="pixelstrap">

<title>Dashboard</title>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Font Awesome-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/font-awesome.css">

<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/flag-icon.css">

<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/icofont.css">

<!-- Prism css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/prism.css">

<!-- Chartist css -->
<!-- <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/chartist.css"> -->

<!-- vector map css -->
<!-- <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/vector-map.css"> -->

<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/bootstrap.css">

<!-- Datatable css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/datatables.css">

<!-- App css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/admin.css">

<!--<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/jquery-ui.min.css">-->
</head>

<body>

<!-- page-wrapper Start-->
<div class="page-wrapper">

<!-- Page Header Start-->
<div class="page-main-header">
<div class="main-header-left">
<div class="logo-wrapper">
<a href="index.html">
<!--                   <img class="blur-up lazyloaded" src="<?= base_url();?>assets/images/layout-2/logo/logo.png" alt="">-->
</a>
</div>
</div>
<div class="main-header-right row">
<div class="mobile-sidebar">
<div class="media-body text-right switch-sm">
<label class="switch">
<input id="sidebar-toggle" type="checkbox" checked="checked"><span class="switch-state"></span>
</label>
</div>
</div>
<div class="nav-right col">
<ul class="nav-menus">
<li>
<form class="form-inline search-form">
<div class="form-group">
<input class="form-control-plaintext" type="search" placeholder="Search.."><span class="d-sm-none mobile-search"><i data-feather="search"></i></span>
</div>
</form>
</li>

<?php 

     $myHTTurl  ="https://ambikaecom.net/API/Balance?UserID=10431&Token=fef118a2f5758de1130282fde17365b1&Format=xml";
  

    ?>
 <li><a href="" class="btn btn-primary"  data-toggle="modal" data-target="#wallet">₹</a></li>
<li><a class="text-dark" href="#!" onclick="javascript:toggleFullScreen()"><i data-feather="maximize"></i></a></li>
<li class="onhover-dropdown"><i data-feather="bell"></i><span class="badge badge-pill badge-primary pull-right notification-badge">3</span><span class="dot"></span>
<ul class="notification-dropdown onhover-show-div p-0">
<li>
<div class="media">
<div class="notification-icons bg-success mr-3"><i data-feather="thumbs-up"></i></div>
<div class="media-body">
<h6 class="font-success">Someone Likes Your Posts</h6>
<p class="mb-0"> 2 Hours Ago</p>
</div>
</div>
</li>
<li>
<div class="media">
<div class="notification-icons bg-info mr-3"><i data-feather="message-circle"></i></div>
<div class="media-body">
<h6 class="font-info">3 New Comments</h6>
<p class="mb-0"> 1 Hours Ago</p>
</div>
</div>
</li>
<li>
<div class="media">
<div class="notification-icons bg-secondary mr-3"><i data-feather="download"></i></div>
<div class="media-body">
<h6 class="font-secondary">Download Complete</h6>
<p class="mb-0"> 3 Days Ago</p>
</div>
</div>
</li>
<li class="bg-light txt-dark"><a href="#" data-original-title="" title="">All </a> notification</li>
</ul>
</li>
<!-- <li><a href="#"><i class="right_side_toggle" data-feather="message-square"></i><span class="dot"></span></a></li> -->
<li class="onhover-dropdown">
<div class="media align-items-center"><img class="align-self-center pull-right img-50 rounded-circle blur-up lazyloaded" src="<?= base_url();?>assets/images/dashboard/man.png" alt="header-user">
<div class="dotted-animation"><span class="animate-circle"></span><span class="main-circle"></span></div>
</div>
<ul class="profile-dropdown onhover-show-div p-20 profile-dropdown-hover">
<li><a href="#">Profile<span class="pull-right"><i data-feather="user"></i></span></a></li>
<!-- <li><a href="#">Inbox<span class="pull-right"><i data-feather="mail"></i></span></a></li>
<li><a href="#">Taskboard<span class="pull-right"><i data-feather="file-text"></i></span></a></li> -->
<li><a href="#">Settings<span class="pull-right"><i data-feather="settings"></i></span></a></li>
<li><a href="<?php echo base_url('login/logout') ?>">Logout<span class="pull-right"><i data-feather="settings"></i></span></a></li>
</ul>
</li>
</ul>
<div class="d-lg-none mobile-toggle pull-right"><i data-feather="more-horizontal"></i></div>
</div>
</div>
</div>
<!-- Page Header Ends -->

<!-- Page Body Start-->
<div class="page-body-wrapper">

<!-- Page Sidebar Start-->
<div class="page-sidebar">
<div class="sidebar custom-scrollbar">
<!-- <div class="sidebar-user text-center">
<div><img class="img-60 rounded-circle lazyloaded blur-up" src="<?= base_url();?>assets/images/dashboard/man.png" alt="#">
</div>
<h6 class="mt-3 f-14">JOHN</h6>
<p>Ux Designer</p>
</div> -->
<ul class="sidebar-menu">
<li><a class="sidebar-header" href="<?= base_url();?>"><i data-feather="home"></i><span>Dashboard</span></a></li>
<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Portal Setting</span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">

<li><a href="<?= base_url('User/shopkeeper');?>"><i class="fa fa-circle"></i>API </a></li>
<li><a href="<?= base_url('User');?>"><i class="fa fa-circle"></i> API Setting</a></li>
<li><a href="<?= base_url('User/transfer');?>"><i class="fa fa-circle"></i>Transfer Api</a></li>
<li><a href="<?= base_url('User/operator');?>"><i class="fa fa-circle"></i>Operator Setting</a></li>
<li><a href="<?= base_url('User/package_recharge');?>"><i class="fa fa-circle"></i>Package Setting</a></li>
<li><a href="<?= base_url('User/operator_code');?>"><i class="fa fa-circle"></i>Operator Code</a></li>
<li><a href="<?= base_url('User/flat_commision');?>"><i class="fa fa-circle"></i>flat Commision</a></li>
<li><a href="<?= base_url('User/operator_commision');?>"><i class="fa fa-circle"></i>Operator Commision</a></li>
<li><a href="<?= base_url('User/amount_api');?>"><i class="fa fa-circle"></i>Amount Api</a></li>
<!--<li><a href="<?= base_url('user/payment');?>"><i class="fa fa-circle"></i>Payment Geteway</a></li>-->

</ul>
</li>


<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Portal Report </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">
<li><a href="<?= base_url('portal_report/user_list');?>"><i class="fa fa-circle"></i>User List</a></li>
<li><a href="<?= base_url('portal_report/book_day');?>"><i class="fa fa-circle"></i>Day Book</a></li>  <li><a href="<?= base_url('portal_report/final_limit');?>"><i class="fa fa-circle"></i>Final Limit</a></li>

<li><a href="<?= base_url('portal_report/all_transfer');?>"><i class="fa fa-circle"></i>All Transfer</a></li>
<li><a href="<?= base_url('user/admin_transfer');?>"><i class="fa fa-circle"></i>Admin Transfer</a></li>
<li><a href="<?= base_url('user/all_flat_commision');?>"><i class="fa fa-circle"></i>All Flat Commisions</a></li>
    
<!--<li><a href="<?= base_url('user/registration_charge');?>"><i class="fa fa-circle"></i> Registration Charge</a></li>-->
<li><a href="<?= base_url('user/operator_recharge_amount');?>"><i class="fa fa-circle"></i> Operator Recharge Amount</a></li>
</ul>
</li>



<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Member Setting </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">
<!--<li><a href="<?= base_url('user/stop_operator');?>"><i class="fa fa-circle"></i>Stop Operator</a></li>-->
<li><a href="<?= base_url('user/set_member_limit');?>"><i class="fa fa-circle"></i>Set Member Limit</a></li>
<li><a href="<?= base_url('user/recharge_amount_limit');?>"><i class="fa fa-circle"></i>Recharge Amount Limit</a></li>

</ul>
</li>

<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Recharge Report </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">

<li>
<a href="<?= base_url('user/recharge_report');?>"><i class="fa fa-circle"></i>Recharge Report</a>
</li>
</ul>
</li>

<!--
<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Utility</span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">


</ul>
</li>
-->

<!--
<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Messages </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">


</ul>
</li>
-->
<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Member Registration </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">

<li><a href="<?= base_url('user/member_registration');?>"><i class="fa fa-circle"></i>Add Member</a></li>
</ul>
</li>
<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Balance </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">

<li><a href="<?= base_url('user/add_bank');?>"><i class="fa fa-circle"></i>Add Bank</a></li>
<li><a href="<?= base_url('user/balance');?>"><i class="fa fa-circle"></i>Request Balance</a></li>

</ul>
</li>
<!--
<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Manage Recharge </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">


</ul>
</li>
-->

<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Complain </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">
<li><a href="<?= base_url('user/complain');?>"><i class="fa fa-circle"></i>Complain Request</a></li>
</ul>
</li>

<li><a class="sidebar-header" href="#"><i data-feather="users"></i><span>Costomer </span><i class="fa fa-angle-right pull-right"></i></a>
<ul class="sidebar-submenu">
<li><a href="<?= base_url('user/costomer_details');?>"><i class="fa fa-circle"></i>Costomer Details</a></li>
<li><a href="<?= base_url('user/costomer_care');?>"><i class="fa fa-circle"></i>Operator Care Toll Free Number</a></li>
</ul>
</li>







</ul>
</div>
</div>
<!-- Page Sidebar Ends-->
  <div class="modal fade" id="wallet" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document"  >
    <div class="modal-content">
    <div class="modal-header" style="border-bottom:none !important">
    
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                           
 
<div class="form-group">

<h3 style="text-align:center;margin-top:-7%"> <span style="font-size:1.3em">Balance :</span> ₹ 1200.00</h3>
</div>
  


    </div>
    </div>
    </div>
<!-- Right sidebar Start-->
<div class="right-sidebar" id="right_side_bar">
<div>
<div class="container p-0">
<div class="modal-header p-l-20 p-r-20">
<div class="col-sm-8 p-0">
<h6 class="modal-title font-weight-bold">FRIEND LIST</h6>
</div>
<div class="col-sm-4 text-right p-0"><i class="mr-2" data-feather="settings"></i></div>
</div>
</div>
<div class="friend-list-search mt-0">
<input type="text" placeholder="search friend"><i class="fa fa-search"></i>
</div>
<div class="p-l-30 p-r-30">
<div class="chat-box">
<div class="people-list friend-list">
<ul class="list">
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/user.png" alt="">
<div class="status-circle online"></div>
<div class="about">
<div class="name">Vincent Porter</div>
<div class="status"> Online</div>
</div>
</li>
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/user1.jpg" alt="">
<div class="status-circle away"></div>
<div class="about">
<div class="name">Ain Chavez</div>
<div class="status"> 28 minutes ago</div>
</div>
</li>
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/user2.jpg" alt="">
<div class="status-circle online"></div>
<div class="about">
<div class="name">Kori Thomas</div>
<div class="status"> Online</div>
</div>
</li>
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/user3.jpg" alt="">
<div class="status-circle online"></div>
<div class="about">
<div class="name">Erica Hughes</div>
<div class="status"> Online</div>
</div>
</li>
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/man.png" alt="">
<div class="status-circle offline"></div>
<div class="about">
<div class="name">Ginger Johnston</div>
<div class="status"> 2 minutes ago</div>
</div>
</li>
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/user5.jpg" alt="">
<div class="status-circle away"></div>
<div class="about">
<div class="name">Prasanth Anand</div>
<div class="status"> 2 hour ago</div>
</div>
</li>
<li class="clearfix"><img class="rounded-circle user-image" src="<?= base_url();?>assets/images/dashboard/designer.jpg" alt="">
<div class="status-circle online"></div>
<div class="about">
<div class="name">Hileri Jecno</div>
<div class="status"> Online</div>
</div>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<!-- Right sidebar Ends-->
