
    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Category List
    <!-- <small>Admin panel</small> -->
    </h3>
    </div>
    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>
    <div class=" pull-right">
    <button type="button" class="btn btn-secondary" data-toggle="modal" data-original-title="test" data-target="#exampleModal">Add Member Registration</button>
    
    

       
    
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel"></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>

    <form class="needs-validation" action="<?= base_url('user/insert_member_registration');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">

    <div class="form-group mb-0">
    <label for="validationCustom02" class="mb-1">Select user Type :</label>
    <select name="service_type" class="form-control" id="validationCustom02" type="file" required  >
    <option value="">Select User Type</option>
    <option value="retailer">Retailer</option>
    <option value="distributor">Distributor</option>
    <option value="super distributor">Super Distributor</option>
    <option value="reseller">Reseller</option>
    <option value="api user">API User</option>
    
        </select>
    </div>
    
    <div class="form-group mb-0">
    <label for="validationCustom02" class="mb-1">Name :</label>
    <input name="name" class="form-control" id="" type="text" required placeholder="Enter Name">
    </div>
    
    
    
    <div class="form-group" id="username1" style="display:none">
    <label for="validationCustom01" class="mb-1">Username :</label>
    <input name="username" class="form-control" placeholder="Enter Username" id="" type="text" >
    </div>
    
     
    
    
    
    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Mobile :</label>
    <input name="mobile" class="form-control" id="" placeholder="Enter Mobile" type="text" required maxlength="10">
    </div>
    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Parent User :</label>
    <input name="p_user" class="form-control" placeholder="Enter Parent User" id="" type="text" required>
    </div>  
     
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Commision type :</label>
    <select name="commision" class="form-control" id="" required>
    <option value="">Select Commision Type</option>
       <option value="Flat_commission">Flat Commision</option>
       <option value="operator_wise">Operator Wise</option>
        </select>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Commision Package :</label>
    <select name="commision_packge" class="form-control" id="" required>
    <option value="">Select Commision Package</option><option value="34">Select Commision Package</option>
       
        </select>
   
    </div>
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Email:</label>
    <input  name="email" class="form-control" id="" type="text" required placeholder="Enter Email">
   
    </div>
      <div class="form-group">
    <label for="validationCustom01" class="mb-1">Company Name:</label>
    <input  name="c_name" class="form-control" id="" type="text" required placeholder="Enter Company Name">
   
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Pin Code :</label>
      
           <input type="text"  class="form-control" value="" name="pin" placeholder="Enter Pin ">
     
   
    </div>
    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Aadhar/Pan Number :</label>
       <input type="text" name="addhar_pan" id="pin" class="form-control" placeholder="Enter Addhar/Pan Number" maxlength="16">
           
   
    </div>
    
    <div class="form-group mb-0">
    <label for="validationCustom02" class="mb-1"> Aadhar/Pan Image :</label>
    <input name="aadhar_pan_img" class="form-control" id="validationCustom02" type="file" required>
    </div>
    
    </div>

    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit">Save</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <!-- Container-fluid Ends-->

    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="card">                   
    <div class="card-body vendor-table">
    <table class="display" id="basic-1">
    <thead>
    <tr>
    <th>Member Id </th>
    <th>Parent User</th>
    <th>Username</th>
    <th>Mobile No</th>
    <th>Email</th>
    <th>Commision Type</th>
    <!-- <th>Status</th>                                -->
    <th>Action</th>
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
    foreach($user as $row){
    ?>
    <tr>
                                
    <td><?= $row->member_id ?></td> 
    <td><?= $row->parent_user ?></td>
       <td><?= $row->username ?></td>
    <td><?= $row->mobile_no ?></td> 
    <td><?= $row->email ?></td> 
    <td><?= $row->commision_type ?></td> 
  
    <td>

    <a data-toggle="modal" data-target="#edit<?= $row->id?>"> <i class="fa fa-edit mr-2 font-success"></i></a>
    
    <a data-toggle="modal" data-target="#delete<?= $row->id?>"> <i class="fa fa-trash mr-2 font-danger"></i></a>
 

    <div class="modal fade" id="delete<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are You sure To delete ?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/delete_member/').$row->id;?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
                                        
    </div>
    <div class="modal-footer">
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    <button class="btn btn-primary" type="submit" name="delete">Delete</button>
    
    </div>
    </form>
    </div>
    </div>
    </div>
     
    
    <div class="modal fade" id="edit<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Member <?=ucwords($row->username)?></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/member_edit');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">

    <div class="form-group mb-0">
    <label for="validationCustom02" class="mb-1">Fill Below Form :</label>
    <select name="service_type" class="form-control" id="validationCustom02" type="file" required >
    <option value="<?=ucwords($row->service_type)?>"><?=ucwords($row->service_type)?></option>
    <option value="retailer">Retailer</option>
    <option value="distributor">Distributor</option>
    <option value="super distributor">Super Distributor</option>
    <option value="reseller">Reseller</option>
    <option value="api user">API User</option>
    
        </select>
    </div>
    
    <div class="form-group mb-0">
    <label for="validationCustom02" class="mb-1">Name :</label>
    <input name="name" class="form-control" id="" type="text" required placeholder="Enter Name" value="<?=ucwords($row->name)?>">
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Username :</label>
    <input name="username" class="form-control" placeholder="Enter Username" id="" type="text" required value="<?=ucwords($row->username)?>">
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Mobile :</label>
    <input name="mobile" class="form-control" id="" placeholder="Enter Mobile" type="text" required maxlength="12" value="<?=ucwords($row->mobile_no)?>">
    </div>
    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Parent User :</label>
    <input name="p_user" class="form-control" placeholder="Enter Parent User" id="" type="text" required value="<?=ucwords($row->parent_user)?>">
    </div>  
 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Commision type :</label>
    <select name="commision" class="form-control" id="" required>
    <option value="<?=ucwords($row->commision_type)?>"><?=ucwords($row->commision_type)?></option>
    <option value="">Select Commision Type</option>
       <option value="Flat_commission">Flat Commision</option>
       <option value="operator_wise">Operator Wise</option>
        </select>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Commision Package :</label>
    <select name="commision_packge" class="form-control" id="" required>
    <option value="<?=ucwords($row->commision_package)?>"><?=ucwords($row->commision_package)?></option>
    <option value="">Select Commision Package</option><option value="34">Select Commision Package</option>
       
        </select>
   
    </div>
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Email:</label>
    <input  name="email" class="form-control" id="" type="text" required placeholder="Enter Email" value="<?=ucwords($row->email)?>">
   
    </div>
      <div class="form-group">
    <label for="validationCustom01" class="mb-1">Company Name:</label>
    <input  name="c_name" class="form-control" id="" type="text" required placeholder="Enter Company Name" value="<?=ucwords($row->company_name)?>">
   
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Pin Code :</label>
       <select name="pin" id="pin" class="form-control">
          <option value="<?=ucwords($row->pin)?>"><?=ucwords($row->pin)?></option>
           <option value="">Select Pin Code</option>
           <option value="221454">221454</option>
       </select>
   
    </div>
    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Aadhar/Pan Number :</label>
       <input type="text" name="addhar_pan" id="pin" class="form-control" placeholder="Enter Addhar/Pan Number" maxlength="16" value="<?=ucwords($row->aadhar_pan_no)?>">
           
   
    </div>
    
   
    
    </div>

    </div>
    <div class="modal-footer">
   
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-primary" type="submit" name="update_member">Update</button>
    </div>
    </form>
    </div>
    </div>
    </div>
    
    
    </td>
    </tr>
    <?php
    }
    }
    ?>                         

    </tbody>
    </table>
    </div>
    </div>
    </div>
    </div>