
		
        <!-- footer start-->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 footer-copyright">
                        <p class="mb-0">Copyright 2019 © Midbrains All rights reserved.</p>
                    </div>
                    <div class="col-md-6">
                        <p class="pull-right mb-0">Hand crafted & made with<i class="fa fa-heart"></i></p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer end-->
    </div>

</div>

<!-- latest jquery-->
<script src="<?= base_url();?>assets/js/jquery-3.3.1.min.js"></script>

<!-- Bootstrap js-->
<script src="<?= base_url();?>assets/js/popper.min.js"></script>
<script src="<?= base_url();?>assets/js/bootstrap.js"></script>

<!-- feather icon js-->
<script src="<?= base_url();?>assets/js/icons/feather-icon/feather.min.js"></script>
<script src="<?= base_url();?>assets/js/icons/feather-icon/feather-icon.js"></script>

<!-- Sidebar jquery-->
<script src="<?= base_url();?>assets/js/sidebar-menu.js"></script>

<!--chartist js-->
<script src="<?= base_url();?>assets/js/chart/chartist/chartist.js"></script>


<!-- lazyload js-->
<script src="<?= base_url();?>assets/js/lazysizes.min.js"></script>

<!--copycode js-->
<script src="<?= base_url();?>assets/js/prism/prism.min.js"></script>
<script src="<?= base_url();?>assets/js/clipboard/clipboard.min.js"></script>
<script src="<?= base_url();?>assets/js/custom-card/custom-card.js"></script>

<!--counter js-->
<script src="<?= base_url();?>assets/js/counter/jquery.waypoints.min.js"></script>
<script src="<?= base_url();?>assets/js/counter/jquery.counterup.min.js"></script>
<script src="<?= base_url();?>assets/js/counter/counter-custom.js"></script>

<!-- Datatables js-->
<script src="<?= base_url();?>assets/js/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url();?>assets/js/datatables/custom-basic.js"></script>

<!--Customizer admin-->
<script src="<?= base_url();?>assets/js/admin-customizer.js"></script>

<!--map js-->
<!-- <script src="<?= base_url();?>assets/js/vector-map/jquery-jvectormap-2.0.2.min.js"></script>
<script src="<?= base_url();?>assets/js/vector-map/map/jquery-jvectormap-world-mill-en.js"></script> -->

<!--apex chart js-->
<!-- <script src="<?= base_url();?>assets/js/chart/apex-chart/apex-chart.js"></script>
<script src="<?= base_url();?>assets/js/chart/apex-chart/stock-prices.js"></script> -->

<!--chartjs js-->
<!-- <script src="<?= base_url();?>assets/js/chart/flot-chart/excanvas.js"></script>
<script src="<?= base_url();?>assets/js/chart/flot-chart/jquery.flot.js"></script>
<script src="<?= base_url();?>assets/js/chart/flot-chart/jquery.flot.time.js"></script>
<script src="<?= base_url();?>assets/js/chart/flot-chart/jquery.flot.categories.js"></script>
<script src="<?= base_url();?>assets/js/chart/flot-chart/jquery.flot.stack.js"></script>
<script src="<?= base_url();?>assets/js/chart/flot-chart/jquery.flot.pie.js"></script> -->
<!--dashboard custom js-->
<script src="<?= base_url();?>assets/js/dashboard/default.js"></script>

<!--right sidebar js-->
<!-- <script src="<?= base_url();?>assets/js/chat-menu.js"></script> -->

<!--height equal js-->


<!-- lazyload js-->
<script src="<?= base_url();?>assets/js/lazysizes.min.js"></script>

<!--script admin-->
<script src="<?= base_url();?>assets/js/admin-script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
  $('.datatable').DataTable();
$(".delete").click(function(){
    Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
    var id = $(this).data("id");
    var name = $(this).data("name");
    $.ajax({
        url: "<?= base_url('Category/delete');?>", 
        type: "post",
        data: {id:id,name:name}, 
        success: function(result) { 
            Swal.fire(
            'Deleted!',
            'Your file has been deleted.',
            'success'
            )
            window.location.reload();
        }
    });   
  }
})
});

</script>
</body>
</html>
