<!DOCTYPE html>
<html lang="en">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Bigdeal admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
<meta name="keywords" content="admin template, Bigdeal admin template, dashboard template, flat admin template, responsive admin template, web app">
<meta name="author" content="pixelstrap">
<link rel="icon" href="<?= base_url();?>assets/images/favicon/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="<?= base_url();?>assets/images/favicon/favicon.ico" type="image/x-icon">
<title>Bigdeal - Premium Admin Template</title>

<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Font Awesome-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/font-awesome.css">

<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/themify.css">

<!-- slick icon-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/slick.css">
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/slick-theme.css">

<!-- jsgrid css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/jsgrid.css">

<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/bootstrap.css">

<!-- App css-->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/admin.css">

</head>
<body>
 <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?> 
<!-- page-wrapper Start-->
<div class="page-wrapper">
<div class="authentication-box">
<div class="container">
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6 p-0 card-right">              
<div class="card tab2-card">
<div class="card-body">                       
<ul class="nav nav-tabs nav-material" id="top-tab" role="tablist">
<li class="nav-item">
<a class="nav-link active" id="top-profile-tab" data-toggle="tab" href="#top-profile" role="tab" aria-controls="top-profile" aria-selected="true"><span class="icon-user mr-2"></span>Registration Form</a>
</li>
<!-- <li class="nav-item">
<a class="nav-link" id="contact-top-tab" data-toggle="tab" href="#top-contact" role="tab" aria-controls="top-contact" aria-selected="false"><span class="icon-unlock mr-2"></span>Register</a>
</li> -->
</ul>
<?php
if($this->session->flashdata('message'))
{
echo '
<div class="alert alert-danger" role="alert">
'.$this->session->flashdata("message").'
</div>
';
}
?>   
<div class="tab-content" id="top-tabContent">                            
<div class="tab-pane fade show active" id="top-profile" role="tabpanel" aria-labelledby="top-profile-tab">
<form class="form-horizontal auth-form" method="post" action="<?= base_url('user_api/insert_reg');?>" onSubmit = "return checkPassword(this)">
<div class="form-group">
<input  name="username" type="text" class="form-control" placeholder="Username" id="username" value="<?=set_value('username')?>" autocomplete="off">
<?=form_error('username');?>
</div>
<div class="form-group">
<input  name="email" type="text" class="form-control" placeholder="Email" id="exampleInputEmail1" value="<?=set_value('email')?>" autocomplete="off">
<?=form_error('username');?>
</div>
<div class="form-group">
<input  name="mobile_no" type="number" class="form-control" placeholder="Mobile Number" id="exampleInputEmail1" <?=set_value('mobile')?> maxlength="10" autocomplete="off">
<?=form_error('mobile');?>
</div>
<div class="form-group">
<select name="user_type" id="" class="form-control"  value="<?=set_value('user_type')?>">
<option value="">Select User Type</option>
<option value="api_user">Api User</option>  
<option value="super">Super Dealer</option>
<option value="master">Master Dealer</option> 
<option value="distributor">Distributor</option>
<option value="Retailer">Retailer</option>
</select>
<?=form_error('user_type');?>
</div>
<div class="form-group">

<select name="package_name" id="" class="form-control" value="<?=set_value('package_name')?>">
<option value="">Select Packages</option>
<?php
foreach($user as $row)
{

?>
<option value="<?=$row->package_name ?>"><?=$row->package_name ?></option>
<?php } ?>
</select>
<?=form_error('package_name');?>
</div>
<div class="form-group">
<input  name="new_password" type="password" class="form-control" placeholder="New Password" id="exampleInputpassword" value="<?=set_value('password')?>">
<?=form_error('password');?>
</div>    
<div class="form-group">
<input  name="c_password" type="password" class="form-control" placeholder="Confirm Password" id="exampleInputpassword" value="<?=set_value('password')?>">

</div>
<div class="form-button">
<button class="btn btn-primary" type="submit" name="registration">Submit</button>
<a href="<?=base_url()?>.user_api/user_login">Login</a>

</div>

</form>
</div> 
</div>
</div>
</div>
</div>
<div class="col-md-3"></div>
</div>
<!-- <a href="index.html" class="btn btn-primary back-btn"><i data-feather="arrow-left"></i>back</a> -->
</div>
</div>
</div>
<script>

// Function to check Whether both passwords
// is same or not.
function checkPassword(form) {
password1 = form.new_password.value;
password2 = form.c_password.value;

// If password not entered
if (password1 == '')
alert ("Please enter Password");

// If confirm password not entered
else if (password2 == '')
alert ("Please enter confirm password");

//  If Not same return False.
else if (password1 != password2) {
alert ("\nPassword did not match: Please try again...")
return false;
}

else{
// alert("Your Password is updated successfull!")
return true;
}
}
</script>
<!-- latest jquery-->
<script src="<?= base_url();?>assets/js/jquery-3.3.1.min.js"></script>

<!-- Bootstrap js-->
<script src="<?= base_url();?>assets/js/popper.min.js"></script>
<script src="<?= base_url();?>assets/js/bootstrap.js"></script>

<!-- feather icon js-->
<script src="<?= base_url();?>assets/js/icons/feather-icon/feather.min.js"></script>
<script src="<?= base_url();?>assets/js/icons/feather-icon/feather-icon.js"></script>

<!-- Sidebar jquery-->
<script src="<?= base_url();?>assets/js/sidebar-menu.js"></script>
<script src="<?= base_url();?>assets/js/slick.js"></script>

<!-- Jsgrid js-->
<script src="<?= base_url();?>assets/js/jsgrid/jsgrid.min.js"></script>
<script src="<?= base_url();?>assets/js/jsgrid/griddata-invoice.js"></script>
<script src="<?= base_url();?>assets/js/jsgrid/jsgrid-invoice.js"></script>

<!-- lazyload js-->
<script src="<?= base_url();?>assets/js/lazysizes.min.js"></script>

<!--right sidebar js-->
<script src="<?= base_url();?>assets/js/chat-menu.js"></script>

<!--script admin-->
<script src="<?= base_url();?>assets/js/admin-script.js"></script>
<script>
$('.single-item').slick({
arrows: false,
dots: true
}
);
</script>
</body>
</html>
