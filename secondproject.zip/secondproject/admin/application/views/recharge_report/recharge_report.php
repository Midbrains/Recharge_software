    
    <script src="<?= base_url();?>assets/js/equal-height.js"></script><script src="<?= base_url();?>assets/js/jquery-ui.min.js"></script>

<script src="<?=base_url()?>assets/js/jquery-3.5.1.min.js"></script>
    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Recharge Report</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
       
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">

    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>
        
<!--    <div class="col-md-2" style="float:left"></div>-->

  
   
   
    </div>      
        
    <div class="card-body">
<div  class="table-responsive">

<table  class="table table-bordered table-striped">
  <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Transaction Id</th>  
    <th>Operator Id</th>
    <th>Operator Name </th> 
    <th>Api Name</th>                       
    <th>Mobile No. </th>
    <th>Amount</th>
    <th>Crosing</th>
    <th>Req Date</th>
    <th>Mode</th>
    <th>Status</th>
    <th>Action</th>
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
    $i = 1;
 
    foreach($user as $row)
    {
      
    
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?php echo $row->trans_id;?>  </td> 
    <td><?php echo $row->operator_id?></td>   
    <td><?php echo  $row->operator ?></td>   
    <td><?php echo $row->api_name?></td>           
    <td><?php echo $row->mobile_no; ?></td> 
    <td><?php echo $row->service ?></td> 
    <td><?php echo $row->closing?></td>
    <td><?php echo  $row->created_at ?></td> 
        <td><?php echo  $row->mode ?></td> 

    
    <td><?php echo  $row->success_status ."". $row->failed_status ?></td> 
    <td>
    <select name="chng_status" id="">
        <option value="">Select</option>
        <option value="failed">Failed</option>
        <option value="success">Success</option>
    </select>
    <a data-toggle="modal" data-target="#status_<?= $row->id?>"> <i class="fa fa-eye btn tooltips " style="background-color:#E1B69C;color:white"></i></a>


<!--       It's End Response Log-->

        <div class="modal fade" id="status_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
   
    <form class="needs-validation" action="<?= base_url('user/delete_operator/').$row->id;?>" enctype="multipart/form-data" method="post">

    <table class="table responsive">
       <tr>
        <th>Response </th>
        </tr>
        <tr>
            <td>
                <?php 
                echo $row->api_response
                ?>
            </td>
        </tr>
    </table>

    <div class="modal-footer" style="border:none">
<button class="btn btn-primary" type="button" data-dismiss="modal" >OK</button>
    </div>
    </form>
    </div>
    </div>
        </div>
         </td>

    </tr>
    <?php
    }
    }
    ?> 
</table>
        </div>
</div>
    </div>