
<script>
$(document).ready(function(){
 $('#country').change(function(){
  var country_id = $('#country').val();
     
   $.ajax({
    url:"<?php echo base_url(); ?>user/fetch_state",
    method:"POST",
    data:{country_id:country_id},
    success:function(data)
    {
     $('#state').html(data);
     $('#city').html('<option value="">Select City</option>');
    }
   });
  
 });

});
</script>
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
        <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Request balance</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>
    </div>
    </div>
    </div>
    </div>

    <div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel"> Request balance</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('User/request_balance/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Bank Name:</label>
    <select name="bank_name" class="form-control" type="text" required id="country">
    <option value="">Select Bank Name </option>
    <?php
        foreach($bank as $row)
        {

        ?>
    <option value="<?php echo ucwords($row->bank_name) ?>">
      <?=ucwords($row->bank_name) ?></option>
    <?php } ?>

        </select>
    </div>
    <div class="form-group" id="state">
    <input type="text" class="form-control" name="d_account" placeholder="Account no.">
    </div>

    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Payment Mode</label>
    <select name="pay_mode" class="form-control" required onchange="payment_mode()" id="pay_mode">
    <option value="">:: Payment Mode ::</option>
       <option value="neft">NEFT</option>
       <option value="rtgs">RTGS</option>
       <option value="tpt">Third Party Transfer</option>
       <option value="cheque">Cheque</option>
       <option value="imps">IMPS</option><option value="exchange">EC-Exchange</option>
       <option value="cash-deposit">Cash Deposit</option>
       <option value="GCC">GCC (Green Channel Card)</option>
        </select>

    </div>
    <div class="form-group " style="display:none" id="transaction">
    <label for="validationCustom01" class="mb-1">Transaction Id</label>
    <input name="trans_id" class="form-control" type="text" value="" >

    </div>

     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Requested Amount</label>
    <input name="req_amount" class="form-control" type="text" value="" required>

    </div>
    <?php 
        foreach($admin as $row)
        ?>
    <div class="form-group">
   
    <input name="admin" class="form-control" type="hidden" value="<?php echo $row->name;?>" required>

    </div>


    </div>
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="payment_req">Add</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>

    <script>
//        function payment_mode()
//        {
//           pay_mode = document.getElementById('pay_mode').value;
//           if(pay_mode == "neft") {document.getElementById('transaction').style.display = "block";
//            document.getElementById('account_holder').style.display = "block";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "none";
//        }
//            if(pay_mode == "rtgs") {document.getElementById('transaction').style.display = "block";
//            document.getElementById('account_holder').style.display = "block";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "none";
//        }
//
//            if(pay_mode == "tpt") {document.getElementById('transaction').style.display = "block";
//            document.getElementById('account_holder').style.display = "block";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "none";
//        }
//            if(pay_mode == "cheque") {document.getElementById('transaction').style.display = "block";
//            document.getElementById('account_holder').style.display = "block";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "block";
//            document.getElementById('card').style.display = "none";
//        }
//
//            if(pay_mode == "imps") {
//                document.getElementById('transaction').style.display = "block";
//            document.getElementById('account_holder').style.display = "block";
//            document.getElementById('mobile').style.display = "block";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "none";
//        }
//            if(pay_mode == "exchange") {
//                document.getElementById('transaction').style.display = "none";
//            document.getElementById('account_holder').style.display = "none";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "none";
//        }
//            if(pay_mode == "cash-deposit") {
//                document.getElementById('transaction').style.display = "none";
//            document.getElementById('account_holder').style.display = "none";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "none";
//        }
//            if(pay_mode == "GCC") {
//                document.getElementById('transaction').style.display = "block";
//            document.getElementById('account_holder').style.display = "block";
//            document.getElementById('mobile').style.display = "none";     document.getElementById('cheque').style.display = "none";
//            document.getElementById('card').style.display = "block";
//        }
//        }
        </script>

    </div>
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">
<!--    <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Add</a>-->
    </div>
    </div>
    <div class="card-body">
<!--<form action="<//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post">-->
    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr No.</th>
    <th>Bank Name</th>
    <th>Payment Mode</th>
    <th>Account Number</th>
    <th>Balance </th>                 
    <th>Status </th>                 
     <th>Action</th>

    </tr>
    </thead>
    <tbody>
    <?php
    if($bal){
    $i = 1;
    foreach($bal as $row){
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?= $row->bank_name?>  </td>
    <td style="text-transform: uppercase;"><?= $row->payment_mode ?></td>
     <td style="text-transform: uppercase;"><?= $row->deposit_account ?></td>
        <td style="text-transform: uppercase;"><?= $row->req_amount ?></td>
        <td>
        <?php
            if($row->status == "Success"){
            ?>
        <span style="background-color:#11D89C;padding:10px;color:white"><?= $row->status ?></span>
        <?php }else if($row->status == "Pending"){ ?>
         <span style="background-color:#EBF8A4;padding:10px;color:black"><?= $row->status ?></span>
         <?php } else if($row->status == "Approved"){ ?>
            <span style="background-color:#00BAF2;padding:10px;color:white"><?= $row->status ?></span>
            <?php 
                                                    }
             else  if($row->status == "Cancel") { ?>
             <span style="background-color:#FF0000;padding:10px;color:white"><?= $row->status ?></span>
             <?php } ?>
        </td>
    <td>
    <div>
    <a data-toggle="modal" data-target="#delete<?= $row->id?>"> <i class="fa fa-trash btn btn-xs btn-red tooltips " style="background-color:red;color:white"></i></a>
    
      <a data-toggle="modal" data-target="#editcat_<?= $row->id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:#00BAF2;color:white"></i></a>



    <div class="modal fade" id="delete<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are You sure to delete?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/delete_request_bal/').$row->id;?>" enctype="multipart/form-data" method="post">

    <div class="modal-footer">

    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-primary" type="submit" name="del_bank">Delete</button>
    </div>
    </form>
    </div>
    </div>
    </div>
       
       
       <div class="modal fade" id="editcat_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Balance Request</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/balance_request_status/').$row->id;?>" enctype="multipart/form-data" method="post">
    <div class="col-md-3"></div>
      <div class="col-md-12">
 <select name="request_status" id="" class="form-control">
       <option value="">Select Balance Request</option>
       <option value="Approved">Approved</option>
       <option value="Cancel">Cancel</option>
   </select>
    </div>
     <div class="col-md-3"></div>
    <div class="modal-footer">
  
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-primary" type="submit" name="change_status">Change</button>
    </div>
    </form>
    </div>
    </div>
    </div>
        </div>
        </td>
        </tr>

    <?php
    }
    }
    ?>
        </tbody>
        </table>



<!--        </form>-->




    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>
