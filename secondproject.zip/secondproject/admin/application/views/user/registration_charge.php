    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Registration Charge</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
       
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">

    </div>  
     
    <div class="col-md-3" style="float:left">
  
    <input type="text"  name="start_date" class="form-control" autocomplete="off" id="datepicker-8">
    </div>  
    <div class="col-md-3" style="float:left">
       
        <input type="text" name="end_date" class="form-control"  id="datepicker-13">
    </div>
      <div class="col-md-2" style="float:left">
        <input type="submit" name="search" value="Search" class="btn btn-success" >
    </div>
    <div style="clear:both"></div>
    </div>      
    <div class="card-body">
<!--<form action="<//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post"><-->

    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Transfer By</th>
    <th>Transfer To</th>                               
    <th>Mobile Number</th>                               
    <th>Date</th>                               
    <th>Bank</th>                               
    <th>Account</th>                               
    <th>Ref No.</th>                             
    <th>Amount</th>                             
    </tr>
    </thead>
    <tbody>  
    <?php 
//    if($user){
//    $i = 1;
//    foreach($user as $row){
    ?>
    <tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
       
        </tr>
        </tbody>
                                                                                                                       
    <?php
//    }
//    }
    ?> 
    
    </table>


    </div>
    </div>