    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Flat Commision</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
     
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    
    </div>      
   <div class="card-body">
 
<!--      White Label Percentage-->
       <h4>White Label Percentage</h4>
       <br>
       <form action="<?php echo base_url('user/White_label') ?>" method="post" enctype="multipart/form-data" >
          <?php 
       if($user)
       {
           foreach($user as $row)
           {
               
       
       ?>
         <div class="col-md-12">
<!--         First Step-->
          <div class="col-md-4" style="float:left">
           <label for="">From ₹ </label>
    
           <input type="text" name="white_form1" class="form-control"  value="<?=$row->from1?>" required>
           </div>
    
           <div class="col-md-4" style="float:left">
           <label for="">To ₹ </label>
    
           <input type="text" name="white_form2" class="form-control" value="<?=$row->to1?>" required>
           </div>
        
           <div class="col-md-4" style="float:left">
           <label for="">Provide % :</label>
    
           <input type="text" name="white_form3" class="form-control" value="<?=$row->provide1;?>" required>
           </div>
<!--           Second Step-->
           
           <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form4" class="form-control" value="<?=$row->from2;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form5" class="form-control" value="<?=$row->to2;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form6" class="form-control" value="<?=$row->provide2;?>" required>
           </div>
<!--           Third Step-->
            
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form7" class="form-control" value="<?=$row->from3;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form8" class="form-control" value="<?=$row->to3;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form9" class="form-control" value="<?=$row->provide3;?>" required>
           </div>
<!--           Fourth Step -->
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form10" class="form-control" value="<?=$row->from4;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form11" class="form-control" value="<?=$row->to4;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form12" class="form-control" value="<?=$row->provide4?>" required>
           </div>
           
<!--           Five Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form13" class="form-control" value="<?=$row->from5;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form14" class="form-control" value="<?=$row->to5;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form15" class="form-control" value="<?=$row->provide5;?>" required>
           </div>
<!--           Six Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form16" class="form-control" value="<?=$row->from6?>"  required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form17" class="form-control" value="<?=$row->to6;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form18" class="form-control" value="<?=$row->provide6;?>" required>
           </div>
           
           
           
             <div class="col-md-4" style="float:left;margin-top:10px">
        
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px" >
        
    
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
        <input type="hidden" name="commision_role" value="White Label" required>
<!--           <input type="Submit"  >-->
           <button 
name="white_button" class="btn btn-primary">Submit</button>
           </div>
<!--           End All Step-->
           
           </div>
           <?php } } ?>
       </form>
       
       
       
<!--     Master Dealer Percentage
  -->
        
         <h4 style="margin-top:400px">Master Dealer Percentage
</h4>
       <br>
       <form action="<?php echo base_url('user/White_label') ?>" method="post" enctype="multipart/form-data" >
         <?php 
       if($master)
       {
           foreach($master as $row)
           {
               
       
       ?>
         <div class="col-md-12">
<!--         First Step-->
          <div class="col-md-4" style="float:left">
           <label for="">From ₹ </label>
    
           <input type="text" name="white_form1" class="form-control"  value="<?=$row->from1?>" required>
           </div>
    
           <div class="col-md-4" style="float:left">
           <label for="">To ₹ </label>
    
           <input type="text" name="white_form2" class="form-control" value="<?=$row->to1?>" required>
           </div>
        
           <div class="col-md-4" style="float:left">
           <label for="">Provide % :</label>
    
           <input type="text" name="white_form3" class="form-control" value="<?=$row->provide1;?>" required>
           </div>
<!--           Second Step-->
           
           <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form4" class="form-control" value="<?=$row->from2;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form5" class="form-control" value="<?=$row->to2;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form6" class="form-control" value="<?=$row->provide2;?>" required>
           </div>
<!--           Third Step-->
            
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form7" class="form-control" value="<?=$row->from3;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form8" class="form-control" value="<?=$row->to3;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form9" class="form-control" value="<?=$row->provide3;?>" required>
           </div>
<!--           Fourth Step -->
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form10" class="form-control" value="<?=$row->from4;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form11" class="form-control" value="<?=$row->to4;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form12" class="form-control" value="<?=$row->provide4?>" required>
           </div>
           
<!--           Five Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form13" class="form-control" value="<?=$row->from5;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form14" class="form-control" value="<?=$row->to5;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form15" class="form-control" value="<?=$row->provide5;?> " required>
           </div>
<!--           Six Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form16" class="form-control" value="<?=$row->from6?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form17" class="form-control" value="<?=$row->to6;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form18" class="form-control" value="<?=$row->provide6;?>" required>
           </div>
           
           
           
             <div class="col-md-4" style="float:left;margin-top:10px">
        
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
        <input type="hidden" name="commision_role" value="Master Dealer" required>
<!--           <input type="Submit"  >-->
           <button 
name="white_button" class="btn btn-primary">Submit</button>
           </div>
<!--           End All Step-->
           
           </div>
           <?php } } ?>
       </form>
       
<!--       Distributor Percentage
-->
        
         <h4 style="margin-top:400px">Distributor Percentage

</h4>
       <br>
       <form action="<?php echo base_url('user/White_label')?>" method="post" enctype="multipart/form-data" >
          <?php 
       if($distributor)
       {
           foreach($distributor as $row)
           {
               
       
       ?>
         <div class="col-md-12">
<!--         First Step-->
          <div class="col-md-4" style="float:left">
           <label for="">From ₹ </label>
    
           <input type="text" name="white_form1" class="form-control"  value="<?=$row->from1?>" required>
           </div>
    
           <div class="col-md-4" style="float:left">
           <label for="">To ₹ </label>
    
           <input type="text" name="white_form2" class="form-control" value="<?=$row->to1?>" required>
           </div>
        
           <div class="col-md-4" style="float:left">
           <label for="">Provide % :</label>
    
           <input type="text" name="white_form3" class="form-control" value="<?=$row->provide1;?>" required>
           </div>
<!--           Second Step-->
           
           <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form4" class="form-control" value="<?=$row->from2;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form5" class="form-control" value="<?=$row->to2;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form6" class="form-control" value="<?=$row->provide2;?>" required>
           </div>
<!--           Third Step-->
            
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form7" class="form-control" value="<?=$row->from3;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form8" class="form-control" value="<?=$row->to3;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form9" class="form-control" value="<?=$row->provide3;?>" required>
           </div>
<!--           Fourth Step -->
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form10" class="form-control" value="<?=$row->from4;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form11" class="form-control" value="<?=$row->to4;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form12" class="form-control" value="<?=$row->provide4?>" required>
           </div>
           
<!--           Five Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form13" class="form-control" value="<?=$row->from5;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form14" class="form-control" value="<?=$row->to5;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form15" class="form-control" value="<?=$row->provide5;?>" required>
           </div>
<!--           Six Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form16" class="form-control" value="<?=$row->from6?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form17" class="form-control" value="<?=$row->to6;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form18" class="form-control" value="<?=$row->provide6;?>" required>
           </div>
           
           
           
             <div class="col-md-4" style="float:left;margin-top:10px">
        
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
        <input type="hidden" name="commision_role" value="Distributor" required>
<!--           <input type="Submit"  >-->
           <button 
name="white_button" class="btn btn-primary">Submit</button>
           </div>
<!--           End All Step-->
           
           </div>
           <?php } } ?>
       </form>
       
<!--       Retailer Percentage
-->
        <h4 style="margin-top:400px">Retailer Percentage

</h4>
       <br>
       <form action="<?php echo base_url('user/White_label')?>" method="post" enctype="multipart/form-data" >
           <?php 
       if($retailer)
       {
           foreach($retailer as $row)
           {
               
       
       ?>
         <div class="col-md-12">
<!--         First Step-->
          <div class="col-md-4" style="float:left">
           <label for="">From ₹ </label>
    
           <input type="text" name="white_form1" class="form-control"  value="<?=$row->from1?>" required>
           </div>
    
           <div class="col-md-4" style="float:left">
           <label for="">To ₹ </label>
    
           <input type="text" name="white_form2" class="form-control" value="<?=$row->to1?>" required>
           </div>
        
           <div class="col-md-4" style="float:left">
           <label for="">Provide % :</label>
    
           <input type="text" name="white_form3" class="form-control" value="<?=$row->provide1;?>" required>
           </div>
<!--           Second Step-->
           
           <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form4" class="form-control" value="<?=$row->from2;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form5" class="form-control" value="<?=$row->to2;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form6" class="form-control" value="<?=$row->provide2;?>" required>
           </div>
<!--           Third Step-->
            
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form7" class="form-control" value="<?=$row->from3;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form8" class="form-control" value="<?=$row->to3;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form9" class="form-control" value="<?=$row->provide3;?>" required>
           </div>
<!--           Fourth Step -->
             <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form10" class="form-control" value="<?=$row->from4;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form11" class="form-control" value="<?=$row->to4;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form12" class="form-control" value="<?=$row->provide4?>" required>
           </div>
           
<!--           Five Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form13" class="form-control" value="<?=$row->from5;?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form14" class="form-control" value="<?=$row->to5;?>"  required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form15" class="form-control" value="<?=$row->provide5;?>" required>
           </div>
<!--           Six Step-->
            <div class="col-md-4" style="float:left;margin-top:10px">
           <input type="text" name="white_form16" class="form-control" value="<?=$row->from6?>" required>
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           <input type="text" name="white_form17" class="form-control" value="<?=$row->to6;?>" required>
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
    
           <input type="text" name="white_form18" class="form-control" value="<?=$row->provide6;?>" required>
           </div>
           
           
           
             <div class="col-md-4" style="float:left;margin-top:10px">
        
           </div>
    
           <div class="col-md-4" style="float:left;margin-top:10px">
        
    
           </div>
        
           <div class="col-md-4" style="float:left;margin-top:10px">
     
        <input type="hidden" name="commision_role" value="Retailer" required>
<!--           <input type="Submit"  >-->
           <button 
name="white_button" class="btn btn-primary">Submit</button>
           </div>
<!--           End All Step-->
           
           </div>
           <?php } } ?>
       </form>
       
       <?php 
//           }
//       }
       ?>
   </div>
    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>