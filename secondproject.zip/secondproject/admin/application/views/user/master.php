    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Master Dealer</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
       
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">

    </div>  
    </div>      
    <div class="card-body">
<!--<form action="<//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post"><-->
  <center>
   <a href="<?=base_url()?>.portal_report/user_list" class="btn btn-danger" name="user" style="padding:3px;width:100px">API User</a>  
    <a href="<?=base_url()?>.portal_report/super" class="btn btn-danger" name="user" style="padding:3px;width:130px" >Super Dealer</a> 
      <a href="<?=base_url()?>.portal_report/master" class="btn btn-danger" name="user" style="padding:3px;width:130px">master Dealer</a> 
        <a href="<?=base_url()?>.portal_report/distributor" class="btn btn-danger" name="user" style="padding:3px;width:130px">Distributor </a>
      <a href="<?=base_url()?>.portal_report/retailer" class="btn btn-danger" name="user" style="padding:3px;width:100px">Retailer</a></center>
    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Agent Name</th>
    <th>Mobile Number</th>                               
    <th>User Type</th>                                                   
    <th>Reg. Date</th>                               
    <th>Reg. By</th>                               
    <th>Status</th>                             
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
    $i = 1;
    foreach($user as $row){
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?= $row->username?>  </td>           
    <td><?= $row->mobile ?></td> 
    <td><?= $row->user_type ?></td>  
    <td><?= $row->reg_date ?></td> 
    <td><?= $row->reg_by ?></td> 
        <td>
        <?php 
            if($row->status=="Active"){
            ?>
          <span sstyle="color:white;" class="bg-success p-2"> <?= $row->status ?></span>
          <?php } else if($row->status=="Deactive") { ?>
            <span style="color:white;" class="bg-success p-2"> <?= $row->status ?></span>
            <?php } ?>
          </td> 

                                                                                                                       
    <?php
    }
    }
    ?> 
    
    </table>


    </div>
    </div>