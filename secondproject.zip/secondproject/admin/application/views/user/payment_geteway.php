    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Payment Getway</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
    <div>
    
    <div class="modal-content">
    <div class="modal-header">

    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/update_payment_gateway/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                           <?php 
        foreach($user as $row)
        {
      
        ?>                                         
    <div class="form-group col-md-6" style="float:left;">
    <label for="validationCustom01" class="mb-1">Payment Gateway Charge:</label>
    
    <input name="payment_charges" class="form-control" type="text"  required placeholder="Payment Gateway Charge" value="<?=$row->payment_charge?>">
    </div> 
    
    <div class="form-group col-md-6" style="float:left">
    <label for="validationCustom01" class="mb-1">Charges Type: </label>
    
    <select name="charges_type" class="form-control" type="text" value="<?=$row->charge_type?>" required placeholder="Charges Type">
        <option value="">--Select Type--</option>
        <option value="Percent">Percent %</option>
        <option value="Rupees">Rupees ₹</option>
    </select>
   
    </div>
      <?php } ?>
       
        <div style="clear:both"></div>
        <span style="color:red"> All Fields Required</span>
    </div>                                                   
    </div>
    
    <div class="modal-footer">
    <span>Click on SUBMIT, to save payment gateway charge</span>
    <input type="hidden" value="Active" name="payment_status" >
    <button class="btn btn-primary" type="submit" name="payment_charge">Submit</button>

    </div>
    </form>
    </div>
    </div>
    </div>        
    
  