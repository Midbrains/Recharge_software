    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h6 style="font-size:16px;font-weight:bold" >Final Limit</h6>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   

    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">

    </div>  
    </div>  

    <div class="card-body" style="background-color:#894550">

    <div class="col-md-12" style="background-color:#894550">
    <div class="col-md-6" style="float:left">
    <div style="width:100px;height:100px;background-color:rgba(255, 255, 255, 0.2) !important;border-radius:100px;margin-top:100px;margin-left:130px"></div>
    <span style="color:white;margin-left:150px">
    Retailer
    </span>
    </div>  
    <div class="col-md-6" style="float:left">

    <span style="color:white"> 0 ₹ </span> 
    <br>
    <span style="color:white">Api User market balance</span>
    <hr style="background-color:rgba(255, 255, 255, 0.2) !important">

    <?php
    foreach($mark as $row)

    ?>
    <span style="color:white"> <?php echo $row->service?> ₹ </span> 
    <br>
    <span style="color:white">Super dealer market balance</span>
    <hr style="background-color:rgba(255, 255, 255, 0.2) !important">
    <?php
    foreach($mark2 as $row1)

    ?>


    <span style="color:white"> <?php echo $row1->service ?> ₹ </span> 
    <br>
    <span style="color:white">Master dealer market balance</span>
    <hr style="background-color:rgba(255, 255, 255, 0.2) !important">


  <?php
    foreach($mark3 as $row2)

    ?>


    <span style="color:white"> <?php echo $row2->service?> ₹ </span> 
    <br>
    <span style="color:white">Distributor market balance</span>
    <hr style="background-color:rgba(255, 255, 255, 0.2) !important">         
 <?php
    foreach($mark4 as $row3)

    ?>
    <span style="color:white"> <?php echo $row3->service?> ₹ </span> 
    <br>
    <span style="color:white">Retailer market balance</span>
    <hr style="background-color:rgba(255, 255, 255, 0.2) !important">


    </div> 
    <div style="clear:both"></div>
    </div>

    </div>
    <div class="card-body">

    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left">
    <span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Total Market Balance
    </span>
    </div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Operator User Balance
    </span></div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Flat User Balance
    </span></div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Flat Commission
    </span></div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Overall Limit
    </span></div>
    <div class="col-md-1" >


    </div>

    <div style="clear:both"></div>
    <hr>
    <div class="col-md-1">


    </div>
    <div class="col-md-2" style="text-align:center;float:left;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Total Recharge Amount
    </span></div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left">
    <span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Operator User Rc. Amt.
    </span>
    </div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Flat User Rc. Amt.
    </span></div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Flat Commission %
    </span></div>
    <div class="col-md-2" style="text-align:center;border-right:1px solid black !important;float:left"><span>30838 ₹</span><br>
    <span style="font-size:0.9em;">Amount Difference
    </span></div>


    <div style="clear:both"></div>
    </div>
    </div>