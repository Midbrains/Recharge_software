    <style>
.dropbtn {
  background-color: #707788;
  color: white;
/*  padding: 16px;*/
  font-size: 13px;
  border: none;
  cursor: pointer;
    width: 80px;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 120px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 8px 16px;
    font-size: 12px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #707788;
}
</style>
    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Operator Setting</h3>

    </div>
    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>
    </div>
    </div>
    </div>
    </div>
    <div class="container-fluid">
    <div class="card">
    <div class="card-header-right" style="padding:10px;">
    <div class="col-md-8"></div>
    <div class="col-md-4">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->

    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>
    </div>
    <div class="card-body">
   <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editapi" style="float:right">Add</a>

       <div class="modal fade" id="editapi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel"> Transfer API</h5>

    </div>
    <form class="needs-validation" action="<?= base_url('user/operator_insert/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">
    <div class="form-group">
    <label for="validationCustom01" class="mb-1"> Api Name</label>

  <select type="text" name="api_name" id="" class="form-control">
    <option value="">Select Api</option>
       <option value="Ambika">Ambika</option>
       <option value="Pay1express">Pay1express</option>
       <option value="Mrobotics">Mrobotics</option>
        </select>

    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1"> Operator Name :</label>

  <input type="text" name="oprtr_name" id="" class="form-control">

    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Operator Code :</label>
    <input type="text" name="oprtr_code" id="" class="form-control" required>


    </div>
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Services Name :</label>

    <select name="service_name" id="" class="form-control">
       <?php
            foreach($user as $row)
            {

            ?>
        <option value="<?=$row->recharge_service;
           ?>"><?=$row->recharge_service;
           ?></option>
           <?php } ?>
    </select>

    </div>
    </div>
    </div>
    <div class="modal-footer">


     <button class="btn btn-secondary" type="button" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i></button>
    <button class="btn btn-primary" type="submit" name="update"><i class="fa fa-check"></i></button>
    </div>
    </form>
    </div>
    </div>
    </div>

    </div>
<!--    <form action="<?//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post">-->
    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Operator Name</th>
    <th>Operator Code</th>
    <th>Service Name</th>

    <th>Status</th>
    <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php
    if($oprtr){
    $i = 1;
    foreach($oprtr as $row){
    ?>

    <tr>
    <td><?=$i++;?></td>
    <td> <?= $row->operator_name ." (".$row->api_name.")"?>  </td>
    <td><?= $row->operator_code ?></td>
    <td><?= $row->service_name ?></td>
   
    <td>
   <?php
    if( $row->status =="Active"){
        ?>
        <span style="color:white;" class="bg-success p-2"><?=$row->status?></span>
        <?php } else if($row->status =="Cancel") {
        ?>
            <span style="color:white;" class="bg-danger p-2"><?=$row->status?></span>
            <?php
    } else { ?>
     <span style="color:white;" class="bg-warning p-2"><?=$row->status?></span>
    <?php  } ?>
    </td>

    <td>
    <div>
    <a data-toggle="modal" data-target="#editcat_<?= $row->id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:#00baf2;color:white"></i></a>
     <div class="dropdown">
  <button class="dropbtn">Action <i class="fa fa-arrow-down"></i></button>
  <div class="dropdown-content">
  <a href="#" name="Active" value="Cancel" data-toggle="modal" data-target="#active_<?= $row->id?>">Active</a>
  <a href="" name="Cancel" value="Cancel" data-toggle="modal" data-target="#cancel_<?= $row->id?>">Cancel</a>
  <a href="" name="Operator Down" value="Down" data-toggle="modal" data-target="#down_<?= $row->id?>">Operator Down</a>
  </div>
</div>
    
        <div class="modal fade" id="active_<?= $row->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are you sure to Active ?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/status_operator_update/').$row->id;?>" enctype="multipart/form-data" method="post">
<?= $row->id?>

    <input name="active_status" class="form-control" type="hidden" value="Active" require>


    <div class="modal-footer">

    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-secondary" type="submit" name="active_button">Ok</button>
    </div>
    </form>
    </div>
    </div>
  </div>


 <div class="modal fade" id="cancel_<?= $row->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are you sure to Cancel ?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/status_operator_update/').$row->id;?>" enctype="multipart/form-data" method="post">


    <input name="active_status" class="form-control" type="hidden" value="Cancel" require>


    <div class="modal-footer">

    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-secondary" type="submit" name="active_button">Ok</button>
    </div>
    </form>
    </div>
    </div>
  </div>


    <div class="modal fade" id="down_<?= $row->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are you sure to Down Operator ?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/status_operator_update/').$row->id;?>" enctype="multipart/form-data" method="post">


    <input name="active_status" class="form-control" type="hidden" value="Down" require>


    <div class="modal-footer">

    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <button class="btn btn-secondary" type="submit" name="active_button">Ok</button>
    </div>
    </form>
    </div>
    </div>
  </div>

    <div class="modal fade" id="editcat_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <?= $row->operator_name?></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/update_operator/').$row->id;?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Api Name :</label>
   
    <select name="api_name" class="form-control" required>
    <option value="">Select Api</option>
       <option value="Ambika">Ambika</option>
       <option value="Pay1express">Pay1express</option>
       <option value="Mrobotics">Mrobotics</option>
        </select>
    </div>
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Operator Name :</label>
    <input name="operator_name" class="form-control" type="text" value="<?= $row->operator_name?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Operator Code :</label>
    <input name="operator_code" class="form-control" type="text" value="<?= $row->operator_code ?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Service Name :</label>

    <select name="service_name" id="" class="form-control" required>
       <option value="">Service Name</option>
          <?php
            foreach($user as $row)
            {

            ?>
        <option value="<?=$row->recharge_service;
           ?>"><?=$row->recharge_service;
           ?></option>
           <?php } ?>
    </select>
    </div>
    </div>
    </div>
    <div class="modal-footer">


     <button class="btn btn-secondary" type="button" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i></button>
    <button class="btn btn-primary" type="submit" name="update_operator"><i class="fa fa-check"></i></button>
    </div>
    </form>
    </div>
    </div>
    </div>


    </td>
    </tr>
    <?php
    }
    }
    ?>
    </tbody>
    </table>
<!--        </form>-->

    </div>
    <!-- Container-fluid Ends-->

    </div>
