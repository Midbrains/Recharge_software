    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Operator Code</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>
        
<!--    <div class="col-md-2" style="float:left"></div>-->
   
    <div class="col-md-3" style="float:left">
    <select  name="api_name" class="form-control" >
        <option value="">Select API Name</option>
        <?php 
        foreach($api as $row)
        {
        
        ?>
        <option value="<?=$row->api_name?>"><?=$row->api_name?></option>
        <?php } ?>
    </select>
    </div>  
    <div class="col-md-3" style="float:left">
        <select name="service_name" class="form-control">
            <option value="">Select Service Name</option>
            <?php 
        foreach($service as $row)
        {
        
        ?>
            <option value="<?=$row->recharge_service?>"><?=$row->recharge_service?></option>
            <?php }?>
        </select>
    </div>
      <div class="col-md-2" style="float:left">
        <input type="submit" name="search" value="Search" class="btn btn-success" >
    </div>
   
    </div>      
    <div class="card-body" >


   <table id="basic-1" class="table">
      <thead>
       <tr>
           <th>Sr No.</th>
           <th>Operator Name</th>
           <th>Operator Code</th>
           <th>Actions</th>
       </tr>
       </thead>
       <?php
       if($user){
           $i=1;
           foreach($user as $row){
               
       
       ?>
       <tbody>
                <tr>
          <td><?=$i++;?></td>
           <td><?=$row->operator_name;?> </td>
           <td><?=$row->operator_code;?> </td>
           <td>
            <a data-toggle="modal" data-target="#editcat_<?= $row->id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:green;color:white"></i></a>
             
              <div class="modal fade" id="editcat_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit Operator</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/operator_code_update/').$row->id;?>" enctype="multipart/form-data" method="post">
    <?php 
        
//        if($row->response_log == "Response"){
//        
        ?>
   
    <div class="form-group">
    <label for="validationCustom01" class="mt-1 ml-3 " style="font-weight:bold">Operator Code :</label>
    <input name="operator_code" class="form-control" type="text" value="<?= $row->operator_code ?>" require style="width:90%; margin-left:20px">
    </div> 
   

    <div class="modal-footer">
   
    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <input type="submit" class="btn btn-secondary" name="operator_button" value="Ok">
    </div>
    </form>
    </div>
    </div>
 
        </div>  
             </td>
       </tr>
       <?php     }
       } ?>
       </tbody>
   </table>
     
    </div>
    
    </div>
    </div>
</div>
       <!-- Container-fluid Ends-->
