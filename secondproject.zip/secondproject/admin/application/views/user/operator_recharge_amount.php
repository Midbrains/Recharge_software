    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Operator Recharge Amount</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
       
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">

    </div>  
     
    <div class="col-md-3" style="float:left">
  
    <input type="text"  name="start_date" class="form-control" autocomplete="off" id="datepicker-8">
    </div>  
    <div class="col-md-3" style="float:left">
       
        <input type="text" name="end_date" class="form-control"  id="datepicker-13">
    </div>
      <div class="col-md-2" style="float:left">
        <input type="submit" name="search" value="Search" class="btn btn-success" >
    </div>
    <div style="clear:both"></div>
    </div>      
    <div class="card-body">
<!--<form action="<//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post"><-->

    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Operator Name</th>
    <th>Recharge Amount</th>          
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
    $i = 1;
    foreach($user as $row){
    ?>
    <tr>
<td><?php echo $i++;?></td>
<td><?php echo $row->operator_name  ?></td>
 <td>
        <?php
        if(empty($row->amount_not_allowed))
        {
        ?>
<a data-toggle="modal" data-target="#pop_<?=$row->id?>" class="btn btn" style="color:red" >Empty</a>
   <?php } else {
     ?>
    <a data-toggle="modal" data-target="#pop_<?=$row->id?>" class="btn btn" style="color:#88bbc8"><?=$row->amount_not_allowed?></a>
    <?php
        } ?>

           <div class="modal fade" id="pop_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Enter Amount Ex: 10.20.30</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/edit_operator/').$row->id;?>" enctype="multipart/form-data" method="post">
<label for="amountnotallowed" class="mb-1">Amount Not Allowed :</label>


    <input name="amount_not_allowed" class="form-control" type="text" value="<?=$row->amount_not_allowed?>" >


    <div class="modal-footer">

    <button class="btn btn-default btn-sm editable-cancel" type="button" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
     <button class="btn btn-secondary" type="submit" name="update_row_operator"><i class="fa fa-check" aria-hidden="true"></i></button>
    </div>
    </form>
    </div>
    </div>

    </div>
    </td>


       
        </tr> 
         <?php
    }
    }
    ?> 
        </tbody>
                                                                                                                       
  
    
    </table>


    </div>
    </div>