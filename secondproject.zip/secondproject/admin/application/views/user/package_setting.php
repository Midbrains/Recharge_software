    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Package Setting</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
    <div class="modal fade" id="editcat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <??> SMS API</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/insert_package/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Name:</label>
    <input name="pack_name" class="form-control" type="text" value="" require placeholder="Package Name">
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Description:</label>
    <input name="package_desc" class="form-control" type="text" value="" require placeholder="Package Description">
    
    </div>
        <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Commision Type :</label>
   
    <select name="package_commision" id="" class="form-control">
        <option value="Flat Commision">Flat Commision</option>
        <option value="operator wise Commision">Operator Wise Commision</option>
    </select>
    
    </div>
      <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Amount:</label>
    <input name="package_amount" class="form-control" type="text" value="" require placeholder="Package Amount">
    <input name="status" class="form-control" type="hidden" value="Active" require>
    </div> 
    </div>                                                   
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="add">Add</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>        
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"></div>
    <div class="col-md-2" style="float:left">
    <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editcat">Add</a>
    </div>  
    </div>      
    <div class="card-body">
<!--<form action="<?//= base_url('user/package_status').$row->package_id;?>" enctype="multipart/form-data" method="post">-->
    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Package Name</th>
    <th>Package Description </th>    
    <th>Package Amount </th>                        
    <th>Package Commision Type </th>
    <th>Package Status</th>
    <th>Action</th>
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
    $i = 1;
    foreach($user as $row){
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?= $row->package_name?>  </td>                          
    <td><?= $row->package_description ?></td> 
    <td><?= $row->package_amount ?></td> 
    <td><?= $row->package_commision_type ?></td> 
    <td><?= $row->package_status ?></td> 

    <td style="width:170px">
    <div>
    <a data-toggle="modal" data-target="#editcat_<?= $row->package_id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:#00baf2;color:white"></i></a> 
 
    <?php
        
        if($row->package_status == "Active")
        {
        ?>
        
    <a data-toggle="modal" data-target="#status_<?= $row->package_id?>">
    <i class="fa fa-times btn btn-xs btn-red tooltips " style="background-color:green;color:white"></i>
    </a> 
   <?php } else if($row->package_status == "Deactive"){ ?>
   <a data-toggle="modal" data-target="#status_<?= $row->package_id?>">
    <i class="fa fa-times btn btn-xs btn-red tooltips " style="background-color:red;color:white"></i> 
        </a>
    <?php } ?>


    <?php
        if($row->response_log=="Response"){
        ?>
       <a class="btn btn-xs btn-red tooltips " data-toggle="modal" data-target="#response_<?= $row->package_id?>" style="background-color:green;color:white">
    Default
        </a>
        <?php
    }else if($row->response_log == "Non-Response")
    {
        ?>
        <a class="btn btn-xs btn-red tooltips " data-toggle="modal" data-target="#response_<?= $row->package_id?>" style="background-color:red;color:white">
    Set as Default
        </a>
   <?php } ?>
    <div class="modal fade" id="editcat_<?= $row->package_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <?= $row->package_name?></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/update_package/').$row->package_id;?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Name :</label>
    <input name="package_name" class="form-control" type="text" value="<?= $row->package_name?>" require>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Description :</label>
    <input name="package_desc" class="form-control" type="text" value="<?= $row->package_description ?>" require>
    </div>
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Commision Type :</label>
   
     <select name="package_commision" id="" class="form-control" required>
       <option value="<?= $row->package_commision_type ?>"><?= $row->package_commision_type ?></option>
        <option value="Flat Commision">Flat Commision</option>
        <option value="operator wise Commision">Operator Wise Commision</option>
    </select>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Package Amount :</label>
    <input name="package_amount" class="form-control" type="text" value="<?= $row->package_amount ?>" require>
    </div> 
    </div>                                                   
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="update">Update</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>    
    
        <div class="modal fade" id="response_<?= $row->package_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are you sure to Active this api?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/response_package_log/').$row->package_id;?>" enctype="multipart/form-data" method="post">
    <?php 
        
//        if($row->response_log == "Response"){
//        
        ?>
    
    <input name="response12" class="form-control" type="hidden" value="Non-Response" require>
   
    <input name="response11" class="form-control" type="hidden" value="Response" require>
   <?php //} ?>
    <div class="modal-footer">
   
    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <input type="submit" class="btn btn-secondary" name="package_active" value="Ok">
    </div>
    </form>
    </div>
    </div>
 
        </div>   
       
       
        <div class="modal fade" id="status_<?= $row->package_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Are you sure to Active this api?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/package_status/').$row->package_id;?>" enctype="multipart/form-data" method="post">
    <input name="status1" class="form-control" type="hidden" value="Active" require>
    <input name="Deactive" class="form-control" type="hidden" value="Deactive" require>
   
    <div class="modal-footer">
   
    <button class="btn btn-white" type="button" data-dismiss="modal">Close</button>
     <input type="submit" class="btn btn-secondary" type="submit" name="package_active" value="Ok">
    </div>
    </form>
    </div>
    </div>
 
        </div>                                       </div>                                        
    </td>
    </tr>
    <?php
    }
    }
    ?> 
    </tbody>
    </table>
<!--        </form>-->
    
    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>