<div class="page-body">
<!-- Container-fluid starts-->
<div class="container-fluid">
<div class="page-header">
<div class="row">
<div class="col-lg-6">
<div class="page-header-left">
<h3>Set Member Limit</h3>
</div>

</div>
<div class="col-lg-6">
<?php
if($this->session->flashdata('success_message'))
{
echo '
<div class="alert alert-success" role="alert">
'.$this->session->flashdata("success_message").'
</div>
';
}
?>
</div>
</div>
</div>
</div>

<div class="container-fluid">
<div class="card">

<div class="card-header-right" style="padding:10px;">

<div class="col-md-4" style="float:left">
<ul class="list-unstyled card-option">
<!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
<!--                                <li><i class="view-html fa fa-code"></i></li>-->
<li><i class="icofont icofont-maximize full-card"></i></li>
<li><i class="icofont icofont-minus minimize-card"></i></li>
<li><i class="icofont icofont-refresh reload-card"></i></li>
<li><i class="icofont icofont-error close-card"></i></li>
</ul>
</div>

</div>
<div class="card-body">
<!--<form action="<//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post">-->
<table class="" id="basic-1">
<thead>
<tr>
<th>Sr.No.</th>
<th>Agent Name</th>
<th>Parent Name</th>
<th>Mobile No.</th>

<th>Package</th>
<th>Reg. Date</th>
<th>Balance Limit</th>
<th>Action</th>
</tr>
</thead>
<tbody>

<?php 
    $i=1;
    foreach($users as $row ) {
    ?>
<tr>
<td><?php echo $i++;?></td>
<td><?php echo $row->name?></td>
<td><?php echo $row->parent_user?></td>
<td><?php echo $row->mobile_no?></td>

<td><?php echo $row->commision_package?></td>
<td><?php echo $row->reg_date?></td>
<td><?php echo $row->balance_limit?></td>
 <td>
    
    <a data-toggle="modal" data-target="#editcat_<?=$row->id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:#00baf2;color:white"></i></a> 
 

    <div class="modal fade" id="editcat_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <?= $row->name?></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/update_member_limit')?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                       
    
   
    <div class="form-group">
    <label for="validationCustom01" class="mb-1"> Balance Limit:</label>
    <input name="id" class="form-control" type="hidden" value="<?=$row->id?>" required>
    
    <input name="balance_limit" class="form-control" type="text" value="<?=$row->balance_limit?>" required>
    </div> 
    </div>                                                   
    </div>
    <div class="modal-footer">
  
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
      <button class="btn btn-primary" type="submit" name="update_limit">Update</button>
    </div>
    </form>
    </div>
    </div>
    </div>    
                                                                            
    </td>


</tr>
<?php } ?>
</tbody>
</table>




</div>
<!-- Container-fluid Ends-->

</div>
