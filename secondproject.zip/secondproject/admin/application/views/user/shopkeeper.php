    <style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
/*  padding: 16px;*/
  font-size: 13px;
  border: none;
  cursor: pointer;
    width: 105px;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 120px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 8px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}
</style>
    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Api Setting</h3>

    </div>
    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>          
    <div class="container-fluid">
    <div class="card">   
    <div class="card-header-right" style="padding:10px;">
    <div class="col-md-8"></div>
    <div class="col-md-4">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>      
    </div>                  
    <div class="card-body">
   <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editapi" style="float:right">Add</a>
   
       <div class="modal fade" id="editapi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">API Setting</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/insert_api_setting/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Api Name:</label>

    <select name="api_name" class="form-control" id="" required>
        <option value="">Select Api Name</option>
        <?php
        foreach($api as $row)
        {
            
        ?>
        <option value="<?php echo $row->api_name ?>"><?php echo $row->api_name ?></option>
        <?php } ?>
    </select>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Username:</label>
    <input name="username" class="form-control" type="text" value="" required>
   
    </div> 
     <div class="form-group">
    <label for="validationCustom01" class="mb-1">Password:</label>
    <input name="password" class="form-control" type="text" value="" required>
   
    </div> 
    </div>                                                   
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="add">Add</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>   
   
    <table id="basic-1" class="table responsive">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Api Name</th>
    <th>Username</th>
    <th>Password</th>                          
<!--    <th>Balance</th>-->
    <th>Action</th>
    </tr>
    </thead>
    <tbody>  
    <?php 
    if($user){
        $i=1;
    foreach($user as $row){
    ?>
    <tr>
    <td><?=$i++;?></td>
    <td> <?= $row->api_name ?>  </td>  
      
       <td><?= $row->username ?></td>
       <td><?= $row->password ?></td>
 
<!--    <td><?= $row->json_data ?></td> -->
 
 
    <td>
    <div>
    <a data-toggle="modal" data-target="#editcat_<?= $row->api_id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:red;color:white"></i></a> 
<!--
    <div class="dropdown">
  <button class="dropbtn">Dropdown <i class="fa fa-arrow-down"></i></button>
  <div class="dropdown-content">
  <a href="#">Link 1</a>
  <a href="#">Link 2</a>
  <a href="#">Link 3</a>
  </div>
</div>
-->
    <a data-toggle="modal" data-target="#delete_<?=$row->api_id?>" data-name="" style="color:white"><i class="fa fa-times btn btn-xs btn-success tooltips "></i></a>
    </div>    
    <div class="modal fade" id="editcat_<?= $row->api_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <?= $row->api_name?></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?= base_url('user/edit_api/').$row->api_id;?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Api Name :</label>
    <input name="api_name" class="form-control" type="text" value="<?= $row->api_name?>" require>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">UserName :</label>
    <input name="username" class="form-control" type="text" value="<?= $row->username?>" require>
    </div> 
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Password:</label>
    <input name="password" class="form-control" type="text" value="<?= $row->password?>" require>
    </div> 
   
    </div>                                                   
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="update_api">Update</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div>                                         
        <div class="modal fade" id="delete_<?=$row->api_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Delete <?= $row->api_name?></h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>                                               
    <form class="needs-validation" action="<?=base_url('user/delete_api/').$row->api_id;?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
     
    <div class="form-group">
  
    <input name="api_id" class="form-control" type="text" value="<?= $row->api_id?>" required>
    </div> 
   
    </div>                                                   
    </div>
    <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="delete">Delete</button>
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
    </div>
    </form>
    </div>
    </div>
    </div> 
    </td>
    </tr>
    <?php
    }
    }
    ?> 
    </tbody>
    </table>
    </div>
    </div>
    </div>
    <!-- Container-fluid Ends-->

    </div>
      