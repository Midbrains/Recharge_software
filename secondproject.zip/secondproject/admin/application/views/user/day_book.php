    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h6 style="font-size:16px" >Day Book <span class="bg-danger p-1 rounded">Operator Commission Users Detail</span></h6>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>   
       
    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>    
    <div class="col-md-6" style="float:left"> </div>
    <div class="col-md-2" style="float:left">

    </div>  
    </div>     
   
    <div class="card-body">
<!--<form action="<//= base_url('user/update_status').$row->id;?>" enctype="multipart/form-data" method="post"><-->
<!--
     <div class="pl-2 pr-2 rounded" style="width:25%; float:right;background-color:#f5f5f5; margin-top:-50px;">
       
        <p class="bg-danger p-1 rounded">Flat Commission Users Detail : </p>
        <p class="rounded">Total Transfer: 0  </p>
        <p class="rounded">Total Commission : 0</p>
        <p class="rounded">Recharge Amount : 0</p>
  
    </div> 
-->

    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Operator Name</th>
    <th>Total Hits</th>                               
    <th>Total Amount</th>                               
    <th>Success Hits</th>                               
    <th>Success Amount</th>                                    
    <th>Failed Hits</th>                                    
    <th>Failed Amount</th>                                    
    <th>Commission</th>                             
    </tr>
    </thead>
    <tbody>  
   <?php

    $i = '1';
        foreach($user as $row){
        ?>
    <tr>
    <td><?php echo $i++; ?></td>
    <td><?php echo $row->operator ?></td>
    <td> 
<?php echo $row->total_hits ?></td>           
    <td><?php echo $row->success_amount +$row->failed_amount?></td> 
    <td><?php echo $row->success_hits?></td> 
    <td><?php echo $row->success_amount?></td> 

        <td><?php echo $row->failed_hits?></td>         
         <td><?php echo $row->failed_amount?></td>           
          <td><?php echo $row->commision?></td>   
       

        </tr>
         <?php } ?>
        
        </tbody>
         <?php foreach($data as $row) ?>
          <tr>
       <td></td>
        <td>Total:</td>
        <td> <?php echo $row->t_hits?></td>
        <td><?php echo $row->s_amount + $row->failed_a ?>     </td>
        <td><?php echo $row->s_hits?> </td>
        <td> <?php echo $row->s_amount?></td>
        <td>  <?php echo $row->failed_hit?></td>   
        <td>  <?php echo $row->failed_a?></td>   
        <td>  <?php echo $row->commision?> </td>
     

    </tr>
    </table>


    </div>
    </div>