    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Operator Commision</h3>
    </div>

    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>
    </div>
    </div>
    </div>
    </div>

    <div class="container-fluid">
    <div class="card">

    <div class="card-header-right" style="padding:10px;">

    <div class="col-md-4" style="float:left">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>
    <div class="col-md-6" style="float:left"></div>

    </div>
    <div class="card-body">


    <table class="" id="basic-1">
    <thead>
    <tr>
    <th>Sr.No.</th>
    <th>Operator Name</th>
    <th>API Commision</th>
    <th>SD Commision</th>
    <th>MD Commision</th>
    <th>Dis Commision</th>
    <th>RT Commision</th>
    <th>Commision Type</th>

    <th>Action</th>
    </tr>
    </thead>

    <tbody>
    <?php
    $i = 1;
    foreach($user as $row){
    ?>

    <tr>
    <td><?=$i++;?></td>

    <td> <?= $row->operator_name;?>  </td>
    <td> <?= $row->api_commision ?></td>
    <td> <?= $row->sd_commision ?></td>
    <td> <?= $row->md_commision ?></td>
    <td> <?= $row->dis_commision ?> </td>
    <td> <?= $row->rt_commision ?> </td>
    <td>
       <?=$row->commision_type?>

    </td>
    <td>
            <a data-toggle="modal" data-target="#editcat_<?= $row->id?>"> <i class="fa fa-edit btn btn-xs btn-red tooltips " style="background-color:#00baf2;color:white"></i></a>
             <div class="modal fade" id="editcat_<?= $row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title f-w-600" id="exampleModalLabel">Edit <?= $row->operator_name?> Operator</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
    </div>
    <form class="needs-validation" action="<?= base_url('user/commision_update/').$row->id;?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">API Commision :</label>
    <input name="api_commision" class="form-control" type="text" value="<?= $row->api_commision?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">SD Commision :</label>
    <input name="sd_commision" class="form-control" type="text" value="<?= $row->sd_commision ?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">MD Commision :</label>
    <input name="md_commision" class="form-control" type="text" value="<?= $row->md_commision ?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Dis Commision :</label>
    <input name="dis_commision" class="form-control" type="text" value="<?= $row->dis_commision ?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">RT Commision :</label>
    <input name="rt_commision" class="form-control" type="text" value="<?= $row->rt_commision ?>" require>
    </div>
    <div class="form-group">
    <label for="validationCustom01" class="mb-1">Commision Type:</label>
 
    <select name="commision_type" id="" class="form-control" required>
        <option value="<?= $row->commision_type ?>"><?= $row->commision_type ?></option>
       <option value="Flat Commision">Flat Commision</option>
        <option value="operator wise Commision">Operator Wise Commision</option>
    </select>
    </div>
    </div>
    </div>
    <div class="modal-footer">
     <button class="btn btn-secondary" type="button" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i></button>
    <button class="btn btn-primary" type="submit" name="update"><i class="fa fa-check"></i></button>

    </div>
    </form>
    </div>
    </div>
    </div>

    </td>


        </tr>

        <?php } ?>
        </tbody>
    </table>

    <div>





    </div>
    </div>
    <!-- Container-fluid Ends-->
    </div>
    </div>
