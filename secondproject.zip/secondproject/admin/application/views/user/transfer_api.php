    
    <div class="page-body">
    <!-- Container-fluid starts-->
    <div class="container-fluid">
    <div class="page-header">
    <div class="row">
    <div class="col-lg-6">
    <div class="page-header-left">
    <h3>Transfer Api</h3>

    </div>
    </div>
    <div class="col-lg-6">
    <?php
    if($this->session->flashdata('success_message'))
    {
    echo '
    <div class="alert alert-success" role="alert">
    '.$this->session->flashdata("success_message").'
    </div>
    ';
    }
    ?>                        
    </div>
    </div>
    </div>
    </div>          
    <div class="container-fluid">
    <div class="card">   
    <div class="card-header-right" style="padding:10px;">
    <div class="col-md-8"></div>
    <div class="col-md-4">
    <ul class="list-unstyled card-option">
    <!--                                <li><i class="icofont icofont-simple-left"></i></li>-->
    <!--                                <li><i class="view-html fa fa-code"></i></li>-->
    
    <li><i class="icofont icofont-maximize full-card"></i></li>
    <li><i class="icofont icofont-minus minimize-card"></i></li>
    <li><i class="icofont icofont-refresh reload-card"></i></li>
    <li><i class="icofont icofont-error close-card"></i></li>
    </ul>
    </div>      
    </div>                  
    <div class="card-body">
<!--   <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#editapi" style="float:right">Add</a>-->
   
                                          
    <form class="needs-validation" action="<?= base_url('user/transfer_api/');?>" enctype="multipart/form-data" method="post">
    <div class="modal-body">
    <div class="form">                                                                    
    <div class="form-group col-md-6" style="float:left">
    <label for="validationCustom01" class="mb-1">Select Operator :</label>
    
  <select name="operator" id=""  class="form-control"> 
      <option>Select Operator</option>
      <?php
      if($user){
      foreach($user as $row)
      {
        
      ?>
      <option value="<?=$row->operator_code?>"><?=$row->operator_name . "(" .$row->api_name .")" ?></option>
      <?php } } ?>
  </select>
    </div> 
    <div class="form-group col-md-6" style="float:left">
    <label for="validationCustom01" class="mb-1">Select API :</label>
    <select name="Api" id="" class="form-control">
        <option>Select API</option>
       <?php foreach($users as $row){ ?>
        <option value="<?=$row->api_name?>"><?=$row->api_name?></option>
        <?php } ?>
    </select>
   
    </div>
     <div class="clearfix"></div>
     <div class="form-group col-md-12">
    <label for="validationCustom01" class="mb-1">Select Packages:</label>
    
    <select name="package" id="" class="form-control" >
        <option>Select Packages</option>
       <?php 
            foreach($pack as $row)
            {
              
            ?>
        <option value="<?=$row->package_name;
           ?>"><?=$row->package_name;
           ?></option>
           <?php } ?>
    </select>
   
    </div> 
    </div>                                                   
    </div>
    <div class="modal-footer">
    <button class="btn btn-warning" type="submit" name="update">Update</button>
    
    </div>
    </form>
    </div>
    </div>
    </div>   
   
    <!-- Container-fluid Ends-->

    </div>
      